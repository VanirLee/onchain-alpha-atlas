# Phase V research-visible fixes

- Target-trade execution price is the event anchor; future response uses fixed clock-time matching only.
- Episode dependence is horizon-specific (1m/5m/15m/60m), with cluster-balanced bootstrap confidence intervals.
- R1 signed response, R2 trade size, R3 flow imbalance, and R4 response decay are source-generated.
- Twelve RQ1–RQ12 hypotheses are frozen before forward confirmation; BH-FDR is applied within pre-registered research families.
- Participant labels remain external metadata until per-trade linkage and matched controls exist.
- Leave-one-token-out, early/late stability, wallet persistence pilot, crowding observables, and negative statuses are retained.
- Superseded Phase IV microstructure findings are excluded from the formal report.
