# Audit overview

## 1. Project objective

Point-in-time cross-chain crypto factor research using Binance Web3 read-only data. This project is not an execution system.

## 2. Actual evidence

- Core source: Binance Web3 API. CEX market data is optional validation; wallet holdings/PnL and fallback providers were not used.
- Research collection endpoints: hot-token, price-info, candles. Capability-only probes: advanced-info, top-liquidity, trades.
- Chains: 4 (1, 56, 8453, CT_501).
- Tokens: 112.
- Token-hour/candle observations: 10079 factor rows; raw normalized market observations: 10079.
- Phase V wallets: 3057 unique observed addresses in the normalized trade tape; 1191 have more than one trade, 257 have at least 5 trades, and 67 have at least 20 trades; wallet skill gate remains FAIL because median trades per wallet is 1.0.
- DEX/pool data: 4 top-liquidity pool snapshots were ingested; no executable depth or reserve history is claimed.
- CEX markets: optional benchmark layer; not a Phase IV research prerequisite.
- Factor families: 9 declared families/proxies.
- Individual factors: 30.
- Holding horizons: 1h, 4h, 24h.
- Hypotheses/tests: 90 factor×horizon IC summaries; 20 regression rows; 5 cost points for one backtest factor.
- Sample period: candle event times span approximately 2024-02-16 to 2026-09-16 across token histories; this is not a synchronized 180-day panel.
- IS/OOS: 70%/30% unique feature timestamps in the example time split; OOS is not a full walk-forward deployment study.
- Transaction costs: proxy 5/10/25/50/100 bps; no executable depth/latency/gas.

## 3. Findings

Exploratory top candidates by mean IC were: [{"factor": "momentum_7d", "horizon": 4, "mean_ic": 0.4999999999999999}, {"factor": "momentum_7d", "horizon": 1, "mean_ic": 0.1999999999999999}, {"factor": "momentum_24h", "horizon": 4, "mean_ic": 0.0454934959829404}, {"factor": "amihud_illiquidity", "horizon": 1, "mean_ic": 0.0435640629950066}, {"factor": "volume_surprise", "horizon": 24, "mean_ic": 0.0380170502261059}]. None survived BH-FDR q=0.05 or q=0.10 (`0` q=0.05 discoveries). Time OOS now uses timestamp-level cross-sectional IC with h-hour label purging; chain results are computed by formal source-code functions. Candidate performance remains exploratory and cross-chain generalization is not established. No finding should be treated as a deployable signal.

Findings surviving multiple testing: none.
Findings surviving OOS: no factor is established as surviving; the example OOS is exploratory and not pre-registered.
Findings surviving transaction costs: the mechanical long-only proxy remains positive at the tested bps levels in the generated table, but this is not executable evidence and carries severe coverage/survivorship limitations.
Findings that failed: universe neutrality, delisted-token coverage, complete historical liquidity/market-cap controls, wallet/smart-money/event studies, complete chain-held-out performance, and full execution-cost modeling.

## 4. Limitations and unresolved issues

- Current hot-token ranking creates selection and survivorship bias.
- Participant endpoints were re-probed in Phase V; 10/11 selected read-only endpoints were accessible, while unsupported results remain explicit.
- Historical candle rows do not carry all liquidity/market-cap fields; neutralization is partial.
- Fama-MacBeth, bootstrap, clustered SE, DSR, CSCV/PBO, and Reality Check were not used.
- No CEX microstructure or CeFi-DeFi basis panel was run.

## 5. Evidence grade

**PRELIMINARY**. The pipeline and raw/API evidence are real and reproducible, but the current research sample and bias profile do not support moderate or strong alpha evidence.

## Phase III data-first backbone

- Local inventory: see `phase3/artifacts/LOCAL_DATA_CATALOG.parquet`; existing local CEX history was reused read-only.
- New public CEX pilot: 5m Spot/UM market data plus mark/index/premium/funding/OI; no authenticated or write endpoint.
- Web3 trades: real token-trade rows are retained in `phase3/data/gold/trades/fact_wallet_trade.parquet`; `userAddress` is present and participant expansion is documented in Phase V.
- Identity: `DEX_ONLY`, `CEX_ONLY`, and `DEX_CEX_PAIRED` are kept separate. Symbol-only matching is excluded; paired count is zero in this run.
- Cross-venue panel is intentionally empty and marked `INSUFFICIENT_CROSS_VENUE_PAIRING`; R1-R4 are BLOCKED_BY_DATA rather than fabricated.

## Phase IV on-chain-native research

- The trade schema audit found `userAddress`; wallet research is now observable but the skill gate fails because the tape is short and 61.0% of wallets are single-trade after the bounded historical expansion.
- Trade-derived microstructure, temporal wallet-token edges, first-observed lifecycle, and multi-DEX identity checks run without CEX pairing.
- Pool/reserve/depth and bridge research remain explicitly blocked; no complex ML was trained.

## Phase IV.1 / Phase V semantic and historical expansion

- `volume` is API USD amount and is stored as `usd_value`; queried-token `changedTokenInfo` amount is `token_quantity`; no `volume * price` notional is used.
- Historical depth measured 111 cursor pages and 9100 raw history rows over 20 representative tokens; the largest observed token history is approximately 33.81 days.
- Participant probes: 10/11 endpoints accessible; tracked trades status is INVALID_PARAMS.
- Tag coverage rows: 28; participant snapshot rows: 800; pool snapshot rows: 4.
- Old Phase IV microstructure results are superseded; Phase V uses fixed-clock horizons, independent cooldown episodes, and cluster bootstrap intervals. BH-FDR is not applied without valid independent p-values.
