# Data sample manifest

- `data/samples/market_observations_sample.parquet`: source=market_observations; original_rows=10079; sample_rows=2000; tokens=110; chains=4; method=deterministic random_state=42; capped at 2,000 rows
- `data/samples/factor_panel_sample.parquet`: source=factor_panel; original_rows=10079; sample_rows=2000; tokens=110; chains=4; method=deterministic random_state=42; capped at 2,000 rows
- `data/samples/forward_returns_sample.parquet`: source=labels; original_rows=10079; sample_rows=2000; tokens=110; chains=4; method=deterministic random_state=42; capped at 2,000 rows
- `data/samples/raw_token_sample.jsonl`: source=Bronze hot-token/price-info; original_rows=403; sample_rows=16; tokens=112; chains=4; method=first 200 matching raw records by sorted partition path; secrets absent

No wallet, CEX, DEX quote, or event sample is included because those panels were not part of the actual research run; they are not replaced with synthetic data.
