# Notebooks

Keep exploratory notebooks here. Production calculations belong in `src/onchain_alpha` so they remain testable and reproducible.
