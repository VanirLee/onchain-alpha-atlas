from __future__ import annotations

from pathlib import Path
import json
import pandas as pd


def build_universe(root: Path) -> pd.DataFrame:
    path = root / "data" / "gold" / "universe.parquet"
    if path.exists():
        return pd.read_parquet(path)
    artifact = root / "artifacts" / "universe.json"
    if artifact.exists():
        rows = json.loads(artifact.read_text(encoding="utf-8")).get("tokens", [])
        frame = pd.DataFrame([{k: v for k, v in row.items() if k != "raw"} for row in rows])
        if not frame.empty:
            path.parent.mkdir(parents=True, exist_ok=True)
            frame.to_parquet(path, index=False)
        return frame
    return pd.DataFrame()
