from __future__ import annotations

from datetime import timedelta

import numpy as np
import pandas as pd


def build_forward_labels(observations: pd.DataFrame, horizons: tuple[int, ...] = (1, 4, 24)) -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame(columns=["chain", "token_address", "feature_time"])
    df = observations.copy()
    df["feature_time"] = pd.to_datetime(df["event_time"].fillna(df["observed_at"]), utc=True, errors="coerce")
    df["chain"] = df["chain"].astype(str)
    df["token_address"] = df["token_address"].fillna("").astype(str)
    df["price_num"] = pd.to_numeric(df["price"], errors="coerce")
    df = df.sort_values(["chain", "token_address", "feature_time"]).drop_duplicates(["chain", "token_address", "feature_time"], keep="last")
    out = df[["chain", "token_address", "feature_time", "price_num"]].copy()
    out["entry_time"] = out["feature_time"]
    index = pd.MultiIndex.from_frame(df[["chain", "token_address", "feature_time"]])
    price_lookup = pd.Series(df["price_num"].to_numpy(), index=index)
    for horizon in horizons:
        target_times = out["feature_time"] + timedelta(hours=int(horizon))
        target_index = pd.MultiIndex.from_arrays([out["chain"].astype(str), out["token_address"].astype(str), target_times])
        future_price = price_lookup.reindex(target_index).to_numpy(dtype=float)
        valid_entry = pd.to_numeric(out["price_num"], errors="coerce").to_numpy(dtype=float)
        values = np.where(np.isfinite(future_price) & np.isfinite(valid_entry) & (valid_entry != 0), future_price / valid_entry - 1, np.nan)
        out[f"forward_return_{horizon}h"] = values
        out[f"exit_time_{horizon}h"] = target_times.where(pd.notna(future_price))
    out["label_source"] = "real_api"
    out["is_feature_safe"] = False
    max_horizon = max(horizons) if horizons else 0
    known_col = f"exit_time_{max_horizon}h"
    out["known_at"] = out[known_col].fillna(out["entry_time"]) if known_col in out else out["entry_time"]
    out["leakage_reason"] = "future return label; never used as a feature"
    return out
