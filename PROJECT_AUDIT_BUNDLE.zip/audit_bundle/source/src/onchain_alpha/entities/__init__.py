"""Wallet/entity schemas and PIT state engines."""
