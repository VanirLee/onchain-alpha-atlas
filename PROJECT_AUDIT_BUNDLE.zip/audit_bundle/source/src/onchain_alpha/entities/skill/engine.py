from __future__ import annotations

import numpy as np
import pandas as pd


def build_wallet_skill_history(trades: pd.DataFrame, measurement_times: list[pd.Timestamp] | None = None, *, min_trades: int = 5, prior_mean: float = 0.0, prior_strength: float = 5.0) -> pd.DataFrame:
    """Estimate wallet skill using closed trades strictly before measurement time."""
    cols = ["wallet_id", "measurement_time", "closed_trade_count", "raw_mean_return", "shrunk_skill", "hit_rate", "status"]
    if trades.empty:
        return blocked_wallet_result()
    df = trades.copy()
    for col in ("wallet_id", "exit_time", "available_time", "realized_return"):
        if col not in df:
            return blocked_wallet_result(f"missing {col}")
    for col in ("exit_time", "available_time"):
        df[col] = pd.to_datetime(df[col], utc=True, errors="coerce")
    df["realized_return"] = pd.to_numeric(df["realized_return"], errors="coerce")
    times = measurement_times or sorted(df["exit_time"].dropna().unique())
    rows = []
    for ts in pd.to_datetime(times, utc=True):
        closed = df[(df["exit_time"] < ts) & (df["available_time"] <= ts)].dropna(subset=["realized_return"])
        for wallet, group in closed.groupby("wallet_id"):
            n = len(group); mean = float(group["realized_return"].mean())
            shrunk = (n * mean + prior_strength * prior_mean) / (n + prior_strength)
            rows.append({"wallet_id": wallet, "measurement_time": ts, "closed_trade_count": n, "raw_mean_return": mean, "shrunk_skill": shrunk, "hit_rate": float((group["realized_return"] > 0).mean()), "status": "COMPUTED" if n >= min_trades else "INSUFFICIENT_SAMPLE"})
    return pd.DataFrame(rows, columns=cols)


def blocked_wallet_result(reason: str = "No wallet trade history is available in the real dataset") -> pd.DataFrame:
    return pd.DataFrame([{"wallet_id": pd.NA, "measurement_time": pd.NaT, "closed_trade_count": 0, "raw_mean_return": np.nan, "shrunk_skill": np.nan, "hit_rate": np.nan, "status": "BLOCKED_BY_DATA", "reason": reason}])
