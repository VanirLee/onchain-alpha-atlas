from __future__ import annotations

import hashlib
import json

import numpy as np
import pandas as pd


def _event_id(asset_id: str, event_time: pd.Timestamp, event_type: str) -> str:
    return hashlib.sha256(f"{asset_id}|{event_time.isoformat()}|{event_type}".encode()).hexdigest()[:24]


def detect_volume_shock(market_state: pd.DataFrame, *, z_threshold: float = 2.0, min_history: int = 12, detector_version: str = "volume_shock_v1") -> pd.DataFrame:
    """Detect a volume surprise using only prior clock-time observations."""
    rows = []
    if market_state.empty or "volume" not in market_state:
        return pd.DataFrame()
    df = market_state.copy()
    df["event_time"] = pd.to_datetime(df["event_time"], utc=True, errors="coerce")
    df = df.dropna(subset=["asset_id", "event_time"]).sort_values(["asset_id", "event_time"])
    for asset_id, group in df.groupby("asset_id", sort=False):
        group = group.set_index("event_time")
        volume = pd.to_numeric(group["volume"], errors="coerce")
        prior = volume.shift(1)
        mean = prior.rolling("24h", min_periods=min_history).mean()
        std = prior.rolling("24h", min_periods=min_history).std()
        z = (volume - mean) / (std + 1e-12)
        for ts, score in z.dropna().items():
            if not np.isfinite(score) or score < z_threshold:
                continue
            observed = group.loc[ts].get("observed_time", pd.NaT)
            available = group.loc[ts].get("available_time", observed)
            rows.append({
                "event_id": _event_id(str(asset_id), ts, "volume_shock"), "event_type": "volume_shock", "entity_type": "token", "entity_id": str(asset_id), "asset_id": str(asset_id),
                "chain": str(group.loc[ts].get("chain", "")), "event_time": ts, "observed_time": observed, "available_time": available, "detection_time": available,
                "event_strength": float(score), "direction": "positive", "metadata": json.dumps({"z_threshold": z_threshold, "min_history": min_history}), "detector_version": detector_version, "source": "real_api",
            })
    return pd.DataFrame(rows)


def detect_volume_shock_percentile(market_state: pd.DataFrame, *, percentile: float, min_history: int = 12, detector_version: str = "volume_shock_percentile_v1") -> pd.DataFrame:
    """Detect cross-sectional volume shocks at a pre-specified threshold.

    The threshold is evaluated at each chain/time cross-section. The event's
    volume is compared with the prior clock-time history, and the threshold
    grid is intentionally exposed to the experiment registry.
    """
    if market_state.empty or "volume" not in market_state:
        return pd.DataFrame()
    df = market_state.copy()
    df["event_time"] = pd.to_datetime(df["event_time"], utc=True, errors="coerce")
    df["volume"] = pd.to_numeric(df["volume"], errors="coerce")
    df = df.dropna(subset=["asset_id", "event_time", "volume"]).sort_values(["asset_id", "event_time"])
    rows = []
    for asset_id, group in df.groupby("asset_id", sort=False):
        group = group.set_index("event_time")
        prior = group["volume"].shift(1)
        baseline = prior.rolling("24h", min_periods=min_history).median()
        ratio = group["volume"] / (baseline.abs() + 1e-12)
        for ts, strength in ratio.dropna().items():
            cross = df[(df["chain"].astype(str) == str(group.loc[ts].get("chain", ""))) & (df["event_time"] == ts)]["volume"]
            cutoff = float(np.nanpercentile(cross.to_numpy(dtype=float), percentile)) if len(cross) else np.inf
            if not np.isfinite(strength) or float(group.loc[ts]["volume"]) < cutoff:
                continue
            observed = group.loc[ts].get("observed_time", pd.NaT)
            available = group.loc[ts].get("available_time", observed)
            rows.append({
                "event_id": _event_id(str(asset_id), ts, f"volume_shock_p{percentile}"), "event_type": "volume_shock", "entity_type": "token", "entity_id": str(asset_id), "asset_id": str(asset_id), "chain": str(group.loc[ts].get("chain", "")), "event_time": ts, "observed_time": observed, "available_time": available, "detection_time": available, "event_strength": float(strength), "direction": "positive", "metadata": json.dumps({"percentile": percentile, "min_history": min_history}), "detector_version": detector_version, "source": "real_api",
            })
    return pd.DataFrame(rows)
