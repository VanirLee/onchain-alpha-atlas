from .detectors import detect_volume_shock

__all__ = ["detect_volume_shock"]
