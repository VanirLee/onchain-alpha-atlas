from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from scipy.stats import t as student_t
import statsmodels.api as sm

from ..features import FACTOR_NAMES
from ..stats.multiple_testing import benjamini_hochberg


def summarize_ic(values: list[float], horizon: int) -> dict[str, float | int | None]:
    """Infer whether the mean time-series IC differs from zero.

    The per-timestamp Spearman p-values describe individual cross-sections;
    they are intentionally not averaged.  Factor-level inference is instead
    H0: E[IC_t] = 0 using a one-sample t statistic and a HAC/Newey-West
    intercept regression.  Forward-return overlap is handled with an
    effective HAC lag of ``min(max(1, horizon), n_periods - 1)``.
    """
    if not values:
        return {"n_periods": 0, "mean_ic": None, "median_ic": None, "ic_std": None, "icir": None, "positive_rate": None, "t_stat": None, "naive_p_value": None, "HAC_t_stat": None, "HAC_p_value": None, "HAC_lag": None, "raw_p_value": None}
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    n = len(arr)
    mean = float(np.mean(arr)) if n else None
    std = float(np.std(arr, ddof=1)) if n > 1 else None
    t_stat = float(mean / (std / np.sqrt(n))) if n > 1 and std and np.isfinite(std) else None
    naive_p = float(2 * student_t.sf(abs(t_stat), df=n - 1)) if t_stat is not None else None
    hac_lag = int(min(max(1, int(horizon)), n - 1)) if n > 1 else None
    hac_t = hac_p = None
    if n > 1 and hac_lag is not None:
        try:
            model = sm.OLS(arr, np.ones((n, 1))).fit(cov_type="HAC", cov_kwds={"maxlags": hac_lag, "use_correction": True})
            hac_t = float(model.tvalues[0])
            hac_p = float(model.pvalues[0])
        except (ValueError, np.linalg.LinAlgError):
            hac_t = hac_p = None
    return {
        "n_periods": n,
        "mean_ic": mean,
        "median_ic": float(np.median(arr)) if n else None,
        "ic_std": std,
        "icir": float(mean / std * np.sqrt(n)) if n > 1 and mean is not None and std and np.isfinite(std) else None,
        "positive_rate": float(np.mean(arr > 0)) if n else None,
        "t_stat": t_stat,
        "naive_p_value": naive_p,
        "HAC_t_stat": hac_t,
        "HAC_p_value": hac_p,
        "HAC_lag": hac_lag,
        # Backward-compatible name; it now means the HAC factor-level p-value.
        "raw_p_value": hac_p,
    }


def cross_sectional_ic_series(frame: pd.DataFrame, factor: str, target: str) -> pd.DataFrame:
    """Compute one Spearman IC_t per feature timestamp, never pooled."""
    rows = []
    if frame.empty or factor not in frame or target not in frame:
        return pd.DataFrame(columns=["feature_time", "ic", "p_value", "n"])
    for ts, group in frame.groupby("feature_time", sort=True):
        sub = group[[factor, target]].apply(pd.to_numeric, errors="coerce").dropna()
        if len(sub) < 5 or sub[factor].nunique() < 2 or sub[target].nunique() < 2:
            continue
        result = spearmanr(sub[factor], sub[target])
        rows.append({"feature_time": ts, "ic": float(result.statistic), "p_value": float(result.pvalue), "n": int(len(sub))})
    return pd.DataFrame(rows, columns=["feature_time", "ic", "p_value", "n"])


def rank_ic(panel: pd.DataFrame, labels: pd.DataFrame, horizons: tuple[int, ...] = (1, 4, 24)) -> tuple[pd.DataFrame, pd.DataFrame]:
    if panel.empty or labels.empty:
        return pd.DataFrame(), pd.DataFrame()
    keys = ["chain", "token_address", "feature_time"]
    df = panel.merge(labels, on=keys, how="inner", suffixes=("", "_label"))
    rows, series = [], []
    for horizon in horizons:
        target = f"forward_return_{horizon}h"
        if target not in df:
            continue
        for factor in FACTOR_NAMES:
            vals = []
            if factor not in df:
                continue
            local = cross_sectional_ic_series(df, factor, target)
            vals = local["ic"].tolist() if not local.empty else []
            for record in local.to_dict("records"):
                series.append({"factor": factor, "horizon": horizon, **record})
            stat = summarize_ic(vals, horizon)
            rows.append({"factor": factor, "horizon": horizon, **stat, "status": "computed" if vals else "insufficient evidence"})
    summary = pd.DataFrame(rows)
    if not summary.empty:
        correction = benjamini_hochberg(summary["HAC_p_value"].tolist())
        summary["fdr_adjusted_p_value"] = [x["fdr_adjusted_p_value"] for x in correction]
        summary["significant_q05"] = [x["significant_q05"] for x in correction]
        summary["significant_q10"] = [x["significant_q10"] for x in correction]
    return summary, pd.DataFrame(series)
