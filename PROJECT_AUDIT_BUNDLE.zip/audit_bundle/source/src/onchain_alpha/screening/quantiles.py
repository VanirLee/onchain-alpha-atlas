from __future__ import annotations

import pandas as pd


def quantile_analysis(panel: pd.DataFrame, labels: pd.DataFrame, factor: str = "momentum_1h", horizon: int = 24, q: int = 5) -> pd.DataFrame:
    target = f"forward_return_{horizon}h"
    df = panel.merge(labels, on=["chain", "token_address", "feature_time"], how="inner")[["feature_time", factor, target]].dropna()
    if df.empty:
        return pd.DataFrame(columns=["factor", "horizon", "quantile", "mean_forward_return", "n"])
    df["quantile"] = df.groupby("feature_time")[factor].transform(lambda x: pd.qcut(x.rank(method="first"), q, labels=False, duplicates="drop") + 1 if len(x) >= q else pd.NA)
    result = df.dropna().groupby("quantile")[target].agg(["mean", "count"]).reset_index()
    result.columns = ["quantile", "mean_forward_return", "n"]
    result["factor"], result["horizon"] = factor, horizon
    return result[["factor", "horizon", "quantile", "mean_forward_return", "n"]]
