from __future__ import annotations

import pandas as pd


def cross_sectional_regression(panel: pd.DataFrame, labels: pd.DataFrame, factor: str = "momentum_1h", horizon: int = 24) -> dict[str, object]:
    target = f"forward_return_{horizon}h"
    df = panel.merge(labels, on=["chain", "token_address", "feature_time"], how="inner")
    cols = [factor, "log_market_cap", "log_liquidity", "realized_vol_24h", "token_age_days"]
    if target not in df or factor not in df:
        return {"factor": factor, "horizon": horizon, "status": "insufficient evidence"}
    use = [c for c in cols if c in df]
    df = df[[target, *use]].apply(pd.to_numeric, errors="coerce").dropna()
    if len(df) < max(20, len(use) * 5):
        return {"factor": factor, "horizon": horizon, "status": "insufficient evidence", "n": int(len(df))}
    try:
        import statsmodels.api as sm
        model = sm.OLS(df[target], sm.add_constant(df[use])).fit(cov_type="HAC", cov_kwds={"maxlags": 4})
        return {"factor": factor, "horizon": horizon, "status": "computed", "n": int(len(df)), "coef": float(model.params.get(factor, float("nan"))), "t_value": float(model.tvalues.get(factor, float("nan"))), "p_value": float(model.pvalues.get(factor, float("nan"))), "controls": use, "note": "HAC/Newey-West with maxlags=4; overlapping-label limitations remain."}
    except Exception as exc:
        return {"factor": factor, "horizon": horizon, "status": "error", "error": f"{type(exc).__name__}: {exc}"}
