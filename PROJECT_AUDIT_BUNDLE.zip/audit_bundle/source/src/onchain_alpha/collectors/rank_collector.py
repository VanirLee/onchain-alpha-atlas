from typing import Any


def collect_rank(*_: Any, **__: Any) -> dict[str, Any]:
    return {"status": "supported_via_hot_token", "endpoint": "/api/v1/dex/market/token/hot-token", "note": "Ranked token discovery is collected by token_collector."}
