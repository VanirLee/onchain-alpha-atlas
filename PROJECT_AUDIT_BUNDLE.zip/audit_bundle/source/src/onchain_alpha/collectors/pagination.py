from __future__ import annotations

from collections.abc import Callable, Iterator
from typing import Any


def iter_pages(fetch: Callable[[int], dict[str, Any]], *, max_pages: int = 100) -> Iterator[dict[str, Any]]:
    for page in range(1, max_pages + 1):
        payload = fetch(page)
        yield payload
        meta = payload.get("page", {}) if isinstance(payload, dict) else {}
        if not isinstance(meta, dict) or page >= int(meta.get("totalPage", page)):
            return
