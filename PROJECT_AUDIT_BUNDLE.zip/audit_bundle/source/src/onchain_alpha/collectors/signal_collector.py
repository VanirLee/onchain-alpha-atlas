from typing import Any


def collect_signals(*_: Any, **__: Any) -> dict[str, Any]:
    return {"status": "unsupported", "reason": "No smart-money signal endpoint was confirmed; maxGain-like outcome fields remain excluded."}
