from typing import Any


def collect_events(*_: Any, **__: Any) -> dict[str, Any]:
    return {"status": "unsupported", "reason": "No event/meme endpoint was confirmed during capability discovery."}
