from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..connectors.binance_web3 import ADVANCED, CANDLES, HOT, PRICE, TOP_LIQUIDITY, TRADES, BinanceWeb3Client


OFFICIAL_CATALOG_URL = "https://developers.binance.com/en/docs/catalog"

# The public Binance developer catalog currently exposes product families but
# does not publish paths for the Web3 analytics capabilities below.  Keeping
# these rows in the inventory makes the investigation explicit without
# guessing undocumented URLs and hammering arbitrary endpoints.
REQUESTED_ANALYTICS_CAPABILITIES = [
    "holders ranking", "top traders", "token trades", "address portfolio overview", "address recent PnL",
    "address token PnL", "address DEX trade history", "leaderboard", "tracked trades", "address balances", "transactions by address",
]


def _probe_status(response: Any) -> str:
    if response is None:
        return "NOT_PROBED"
    if response.ok:
        return "ACCESSIBLE_WITH_CURRENT_KEY"
    if response.http_status in {401, 403}:
        return "FAILED_PERMISSION"
    if 400 <= response.http_status < 500:
        return "FAILED_PARAMS"
    return "FAILED_PERMISSION" if response.http_status == 0 else "FAILED_PARAMS"


def _fields(value: Any) -> list[str]:
    if isinstance(value, dict):
        return sorted(value.keys())
    if isinstance(value, list) and value and isinstance(value[0], dict):
        return sorted(value[0].keys())
    if isinstance(value, list) and value and isinstance(value[0], (list, tuple)):
        return ["open", "high", "low", "close", "volume", "time", "tx_count"][:len(value[0])]
    return []


def discover(client: BinanceWeb3Client, root: Path, chains: tuple[str, ...]) -> dict[str, Any]:
    generated = datetime.now(timezone.utc).isoformat()
    report: dict[str, Any] = {"generated_at": generated, "source": "real_api", "read_only": True, "official_catalog_url": OFFICIAL_CATALOG_URL, "endpoints": [], "unsupported_or_unknown": {}}
    sample_token: dict[str, str] | None = None
    for chain in chains:
        params = {"binanceChainId": chain, "rankBy": "6", "rankingTimeFrame": "3", "pageId": "1", "size": "5"}
        response = client.request("GET", HOT, params=params)
        items = response.data.get("items", []) if isinstance(response.data, dict) else []
        if not sample_token and items and isinstance(items[0], dict):
            addr = items[0].get("tokenContractAddress")
            if addr:
                sample_token = {"chain": chain, "token": addr}
        report["endpoints"].append({"endpoint": HOT, "method": "GET", "chain": chain, "status": "supported" if response.ok else "failed", "probe_status": _probe_status(response), "documentation_status": "PROJECT_API_CONTRACT", "http_status": response.http_status, "business_code": response.business_code, "required_params": list(params), "pagination": {"pageId": "observed", "size": "observed"}, "fields": _fields(response.data), "latency_ms": response.latency_ms, "rate_limit_headers": response.headers})
    if sample_token:
        chain, token = sample_token["chain"], sample_token["token"]
        probes = [
            (PRICE, "POST", {"body": [{"binanceChainId": chain, "tokenContractAddress": token}]}, [{"binanceChainId": chain, "tokenContractAddress": token}]),
            (CANDLES, "GET", {"binanceChainId": chain, "tokenContractAddress": token, "bar": "1h", "limit": "5"}, None),
            (ADVANCED, "GET", {"binanceChainId": chain, "tokenContractAddress": token}, None),
            (TOP_LIQUIDITY, "GET", {"binanceChainId": chain, "tokenContractAddress": token}, None),
            (TRADES, "GET", {"binanceChainId": chain, "tokenContractAddress": token, "limit": "5"}, None),
        ]
        for endpoint, method, params, body in probes:
            response = client.request(method, endpoint, params=params if method == "GET" else None, body=body)
            report["endpoints"].append({"endpoint": endpoint, "method": method, "chain": chain, "status": "supported" if response.ok else "failed", "probe_status": _probe_status(response), "documentation_status": "PROJECT_API_CONTRACT", "http_status": response.http_status, "business_code": response.business_code, "required_params": list(params) if isinstance(params, dict) else ["body"], "pagination": "observed" if isinstance(params, dict) and "limit" in params else "unknown", "fields": _fields(response.data), "latency_ms": response.latency_ms, "rate_limit_headers": response.headers})
    report["capability_matrix"] = {
        "market": [x["endpoint"] for x in report["endpoints"] if x["endpoint"] in {PRICE, CANDLES}],
        "liquidity": [TOP_LIQUIDITY],
        "holder": [f"{ADVANCED}: holders, bnHolderCount, top10HoldingPercent, freshWalletHoldingPercent, insiderHoldingPercent"],
        "wallet": ["unknown: no project hint or safe probe"],
        "ranking": [HOT],
        "smart_money": [f"{ADVANCED}: smartMoneyHoldingPercent (crowding/holding proxy only; no forward signal outcome confirmed)"],
        "audit": [ADVANCED],
        "event_meme": ["unknown: no event/meme lifecycle endpoint confirmed"],
        "ohlcv_intervals": ["1h probe attempted"],
    }
    inventory = []
    for item in report["endpoints"]:
        inventory.append({
            "capability": item["endpoint"], "candidate_endpoint": item["endpoint"], "method": item["method"],
            "documentation_status": item.get("documentation_status", "PROJECT_API_CONTRACT"), "status": item["probe_status"],
            "http_status": item["http_status"], "business_code": item["business_code"], "chain": item.get("chain", ""),
            "reason": "Safe read-only probe using current key and documented project API contract." if item["probe_status"] == "ACCESSIBLE_WITH_CURRENT_KEY" else "Read-only probe failed; inspect HTTP/code.",
            "source": OFFICIAL_CATALOG_URL,
        })
    for capability in REQUESTED_ANALYTICS_CAPABILITIES:
        inventory.append({
            "capability": capability, "candidate_endpoint": "", "method": "", "documentation_status": "NOT_FOUND_IN_OFFICIAL_PUBLIC_CATALOG",
            "status": "NOT_PROBED", "http_status": "", "business_code": "", "chain": "",
            "reason": "The official public catalog exposes product families but no Web3 analytics path for this capability; no speculative endpoint was called.",
            "source": OFFICIAL_CATALOG_URL,
        })
    report["endpoint_inventory"] = inventory
    report["client_metrics"] = client.metrics
    path = root / "artifacts" / "api_capabilities.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    # Keep the human report concise but complete enough for review.
    docs = root / "docs" / "api_capabilities.md"
    lines = ["# Binance Web3 API capabilities", "", f"Generated at `{generated}`. All probes were read-only.", "", "Official catalog reference: " + OFFICIAL_CATALOG_URL, "", "| Endpoint | Method | Status | HTTP/code | Fields | Latency ms |", "|---|---:|---|---|---|---:|"]
    for item in report["endpoints"]:
        lines.append(f"| `{item['endpoint']}` | {item['method']} | {item['status']} | {item['http_status']}/{item['business_code']} | `{', '.join(item['fields'])}` | {item['latency_ms']:.1f} |" )
    lines.extend(["", "## Read-only endpoint inventory", "", "Status values: `DOCUMENTED`, `ACCESSIBLE_WITH_CURRENT_KEY`, `FAILED_PERMISSION`, `FAILED_PARAMS`, `NOT_PROBED`. The requested wallet analytics capabilities without an official public path are recorded as `NOT_PROBED`; no guessed URL was called.", "", "| Capability | Candidate endpoint | Documentation | Probe status | HTTP/code | Reason |", "|---|---|---|---|---|---|"])
    for item in inventory:
        lines.append(f"| {item['capability']} | `{item['candidate_endpoint']}` | {item['documentation_status']} | {item['status']} | {item['http_status']}/{item['business_code']} | {item['reason']} |")
    lines.extend(["", "## Confirmed or observed capabilities", "", json.dumps(report["capability_matrix"], ensure_ascii=False, indent=2), "", "## Rate-limit observations", "", json.dumps(report["client_metrics"], ensure_ascii=False, indent=2, default=str), "", "Unknown wallet holdings, signal-outcome, and event/meme lifecycle endpoints are intentionally left as adapter extension points. Holder fields and the smart-money holding/crowding proxy were observed through `advanced-info`; no forward signal-outcome endpoint was confirmed. No unsupported endpoint was invented."])
    docs.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report
