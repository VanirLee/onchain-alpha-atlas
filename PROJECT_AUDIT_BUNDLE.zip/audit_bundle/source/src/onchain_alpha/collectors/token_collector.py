from __future__ import annotations

import json
import math
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from ..connectors.binance_web3 import BinanceWeb3Client
from ..storage import ParquetStore, RawStore, stable_hash

HOT = "/api/v1/dex/market/token/hot-token"
PRICE = "/api/v1/dex/market/price-info"
CANDLES = "/api/v1/dex/market/candles"
ADVANCED = "/api/v1/dex/market/token/advanced-info"
TOP_LIQUIDITY = "/api/v1/dex/market/token/top-liquidity"
TRADES = "/api/v1/dex/market/trades"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _items(data: Any) -> list[dict[str, Any]]:
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]
    if isinstance(data, dict):
        for key in ("items", "rows", "list", "data"):
            if isinstance(data.get(key), list):
                return [x for x in data[key] if isinstance(x, dict)]
    return []


def _candle_items(data: Any, token: str) -> list[dict[str, Any]]:
    rows = _items(data)
    if rows:
        return [{**row, "tokenContractAddress": token} for row in rows]
    if isinstance(data, list):
        result = []
        for row in data:
            if isinstance(row, (list, tuple)) and len(row) >= 6:
                result.append({"open": row[0], "high": row[1], "low": row[2], "close": row[3], "volume": row[4], "time": row[5], "txs": row[6] if len(row) > 6 else None, "tokenContractAddress": token})
        return result
    return []


def _value(row: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in row and row[key] not in (None, ""):
            return row[key]
    return None


def _as_float(value: Any) -> float | None:
    try:
        return None if value in (None, "") else float(value)
    except (TypeError, ValueError):
        return None


def deduplicate_tokens(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: dict[tuple[str, str], dict[str, Any]] = {}
    for item in rows:
        key = (str(item.get("chain", "")), str(item.get("token_address", "")).lower())
        if key[1]:
            unique[key] = item
    return list(unique.values())


def _obs_row(row: dict[str, Any], *, chain: str, source: str, endpoint: str, observed_at: str, event_time: Any = None, request_params: Any = None) -> dict[str, Any]:
    token = _value(row, "tokenContractAddress", "tokenAddress", "address", "token")
    event = event_time or _value(row, "time", "timestamp", "openTime", "eventTime")
    try:
        event_iso = pd.to_datetime(event, unit="ms", utc=True).isoformat() if event is not None and str(event).isdigit() else (str(event) if event else None)
    except Exception:
        event_iso = str(event) if event else None
    return {
        "source": source, "endpoint": endpoint, "chain": str(_value(row, "binanceChainId", "chain") or chain), "entity_type": "token",
        "token_address": token, "wallet_address": None, "event_time": event_iso, "observed_at": observed_at,
        "effective_time": event_iso or observed_at, "ingested_at": _now(), "api_version": "v1",
        "request_params": json.dumps(request_params, ensure_ascii=False, default=str) if request_params is not None else None,
        "request_params_hash": stable_hash(request_params) if request_params is not None else None, "payload_hash": stable_hash(row),
        "known_at": observed_at, "is_feature_safe": True, "leakage_reason": None,
        "symbol": _value(row, "symbol", "tokenSymbol"), "price": _as_float(_value(row, "price", "close", "closePrice")),
        "volume": _as_float(_value(row, "volume", "volume5M", "volume1H", "quoteVolume")),
        "volume_5m": _as_float(_value(row, "volume5M")), "volume_1h": _as_float(_value(row, "volume1H")),
        "buy_volume": _as_float(_value(row, "buyVolume", "buyVolume5M", "buyAmount")), "sell_volume": _as_float(_value(row, "sellVolume", "sellVolume5M", "sellAmount")),
        "liquidity": _as_float(_value(row, "liquidity", "liquidityUsd", "liquidityUSD")), "market_cap": _as_float(_value(row, "marketCap", "marketCapUsd")),
        "holders": _as_float(_value(row, "holders", "holderCount")), "tx_count": _as_float(_value(row, "txs5M", "txs", "tradeCount")),
        "smart_money_flow": _as_float(_value(row, "smartMoneyFlow", "inflowUsd", "smartMoneyInflow")),
        "smart_money_holding_percent": _as_float(_value(row, "smartMoneyHoldingPercent")),
        "top10_holding_percent": _as_float(_value(row, "top10HoldingPercent")),
        "rank": _as_float(_value(row, "rank", "ranking")), "audit_score": _as_float(_value(row, "auditScore", "audit_score")),
        "price_change_5m": _as_float(_value(row, "priceChange5M", "change5M")), "price_change_1h": _as_float(_value(row, "priceChange1H", "change1H")),
        "raw_json": json.dumps(row, ensure_ascii=False, default=str),
    }


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")


def collect_tokens(client: BinanceWeb3Client, root: Path, *, mode: str = "sample", chains: tuple[str, ...] | None = None, sample_tokens: int = 120, candle_limit: int = 96) -> dict[str, Any]:
    chains = chains or ("1", "56", "8453", "CT_501")
    per_chain = min(100, max(5, math.ceil(sample_tokens / len(chains)))) if mode == "sample" else 100
    raw, store = RawStore(root / "data"), ParquetStore(root / "data")
    observed_at = _now()
    universe: list[dict[str, Any]] = []
    audit: list[dict[str, Any]] = []

    for chain in chains:
        params = {"binanceChainId": chain, "rankBy": "6", "rankingTimeFrame": "3", "pageId": "1", "size": str(per_chain)}
        response = client.request("GET", HOT, params=params)
        raw.write(source="binance_web3", endpoint=HOT, chain=chain, payload=response.data, request_params=params, observed_at=response.observed_at, response_meta={"http_status": response.http_status, "business_code": response.business_code, "latency_ms": response.latency_ms, "headers": response.headers})
        audit.append({"endpoint": HOT, "chain": chain, "status": response.http_status, "business_code": response.business_code, "latency_ms": response.latency_ms, "headers": response.headers})
        for rank, item in enumerate(_items(response.data), start=1):
            token = _value(item, "tokenContractAddress", "tokenAddress", "address")
            if token:
                universe.append({"chain": chain, "token_address": token, "symbol": _value(item, "tokenSymbol", "symbol"), "discovery_rank": rank, "discovery_source": "binance_web3:hot-token", "first_seen": response.observed_at, "last_seen": response.observed_at, "raw": item})

    universe = deduplicate_tokens(universe)
    _write_json(root / "artifacts" / "universe.json", {"source": "real_api", "observed_at": observed_at, "tokens": universe})
    universe_rows = [{k: v for k, v in item.items() if k != "raw"} for item in universe]
    store.write("universe", universe_rows)

    market_rows: list[dict[str, Any]] = []
    candle_rows: list[dict[str, Any]] = []
    for chain in chains:
        tokens = [x for x in universe if x["chain"] == chain]
        if not tokens:
            continue
        body = [{"binanceChainId": str(x["chain"]), "tokenContractAddress": x["token_address"]} for x in tokens]
        response = client.request("POST", PRICE, body=body)
        raw.write(source="binance_web3", endpoint=PRICE, chain=chain, payload=response.data, request_params={"count": len(body), "tokens": [x["tokenContractAddress"] for x in body]}, observed_at=response.observed_at, response_meta={"http_status": response.http_status, "business_code": response.business_code, "latency_ms": response.latency_ms, "headers": response.headers})
        audit.append({"endpoint": PRICE, "chain": chain, "status": response.http_status, "business_code": response.business_code, "latency_ms": response.latency_ms, "headers": response.headers, "count": len(body)})
        market_rows.extend(_obs_row(row, chain=chain, source="real_api", endpoint=PRICE, observed_at=response.observed_at, request_params={"binanceChainId": chain, "batch_size": len(body)}) for row in _items(response.data))
        # Historical candles are the highest-value PIT source. The sample limits
        # calls to the discovered sample universe and uses one read-only request per token.
        for token in tokens:
            params = {"binanceChainId": chain, "tokenContractAddress": token["token_address"], "bar": "1h", "limit": str(candle_limit)}
            candle = client.request("GET", CANDLES, params=params)
            raw.write(source="binance_web3", endpoint=CANDLES, chain=chain, payload=candle.data, request_params=params, observed_at=candle.observed_at, response_meta={"http_status": candle.http_status, "business_code": candle.business_code, "latency_ms": candle.latency_ms, "headers": candle.headers})
            audit.append({"endpoint": CANDLES, "chain": chain, "status": candle.http_status, "business_code": candle.business_code, "latency_ms": candle.latency_ms, "headers": candle.headers, "token": token["token_address"]})
            for row in _candle_items(candle.data, token["token_address"]):
                candle_rows.append(_obs_row(row, chain=chain, source="real_api", endpoint=CANDLES, observed_at=candle.observed_at, request_params=params))

    all_rows = market_rows + candle_rows
    if all_rows:
        store.write("market_observations", all_rows)
        pd.DataFrame(all_rows).to_parquet(root / "data" / "silver" / "market_observations.parquet", index=False)
    _write_json(root / "artifacts" / "collection_audit.json", {"source": "real_api", "observed_at": observed_at, "universe_count": len(universe), "market_rows": len(market_rows), "candle_rows": len(candle_rows), "requests": audit, "client_metrics": client.metrics, "read_only": True})
    return {"status": "completed", "source": "real_api", "universe": len(universe), "market_rows": len(market_rows), "candle_rows": len(candle_rows), "requests": len(audit), "client_metrics": client.metrics}
