"""Wallet collector extension point.

Wallet endpoints were not inferred. This module records an explicit unsupported
result until a capability probe confirms a read-only wallet/holdings endpoint.
"""

from typing import Any


def collect_wallets(*_: Any, **__: Any) -> dict[str, Any]:
    return {"status": "unsupported", "reason": "No wallet/holdings endpoint confirmed during local capability discovery."}
