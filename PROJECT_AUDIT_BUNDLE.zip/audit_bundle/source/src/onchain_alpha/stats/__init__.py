from .multiple_testing import benjamini_hochberg
from .walk_forward import time_splits

__all__ = ["benjamini_hochberg", "leave_one_chain_out", "split_ic", "subperiod_ic", "time_splits"]


def __getattr__(name: str):
    if name in {"leave_one_chain_out", "split_ic", "subperiod_ic"}:
        from . import robustness
        return getattr(robustness, name)
    raise AttributeError(name)
