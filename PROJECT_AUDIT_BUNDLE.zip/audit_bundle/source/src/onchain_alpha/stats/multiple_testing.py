from __future__ import annotations

import numpy as np


def benjamini_hochberg(p_values: list[float | None], q: float = 0.05) -> list[dict[str, float | bool | None]]:
    """Return standard Benjamini--Hochberg adjusted p-values.

    NaN/None values are excluded from the multiplicity family and retain a
    missing adjusted value.  The reverse cumulative minimum is applied in
    sorted-p order, which is the same convention as
    ``statsmodels.stats.multitest.multipletests(method='fdr_bh')``.
    """
    if not 0 < q <= 1:
        raise ValueError("q must be in (0, 1]")
    valid = []
    for i, raw in enumerate(p_values):
        if raw is None:
            continue
        value = float(raw)
        if not np.isfinite(value):
            continue
        if not 0 <= value <= 1:
            raise ValueError(f"p-values must be in [0, 1], got {value}")
        valid.append((i, value))
    m = len(valid)
    adjusted: dict[int, float] = {}
    if m:
        ordered = sorted(valid, key=lambda item: (item[1], item[0]))
        running = 1.0
        for rank in range(m, 0, -1):
            index, raw = ordered[rank - 1]
            running = min(running, raw * m / rank)
            # Numerical clipping and the max(raw, ...) guard keep the output
            # a valid p-value and prevent floating point undershoot below raw.
            adjusted[index] = float(min(1.0, max(raw, running)))
    result = []
    for i, raw in enumerate(p_values):
        adj = adjusted.get(i)
        result.append({
            "raw_p_value": raw,
            "fdr_adjusted_p_value": adj,
            "significant_q05": bool(adj is not None and adj <= 0.05),
            "significant_q10": bool(adj is not None and adj <= 0.10),
        })
    return result
