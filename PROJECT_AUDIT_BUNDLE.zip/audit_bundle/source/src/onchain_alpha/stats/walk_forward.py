from __future__ import annotations

import pandas as pd


def time_splits(frame: pd.DataFrame, train_fraction: float = 0.7) -> tuple[pd.DataFrame, pd.DataFrame]:
    times = sorted(pd.to_datetime(frame["feature_time"], utc=True).dropna().unique())
    cut = max(1, int(len(times) * train_fraction))
    train_times, test_times = set(times[:cut]), set(times[cut:])
    t = pd.to_datetime(frame["feature_time"], utc=True)
    return frame[t.isin(train_times)].copy(), frame[t.isin(test_times)].copy()
