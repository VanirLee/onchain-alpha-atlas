from __future__ import annotations

import pandas as pd

from ..screening.ic import cross_sectional_ic_series, summarize_ic


def _merged(panel: pd.DataFrame, labels: pd.DataFrame, horizon: int) -> pd.DataFrame:
    keys = ["chain", "token_address", "feature_time"]
    df = panel.merge(labels, on=keys, how="inner")
    if df.empty:
        return df
    df["feature_time"] = pd.to_datetime(df["feature_time"], utc=True, errors="coerce")
    exit_col = f"exit_time_{horizon}h"
    if exit_col in df:
        df[exit_col] = pd.to_datetime(df[exit_col], utc=True, errors="coerce")
    return df


def _inference_row(frame: pd.DataFrame, factor: str, horizon: int, split: str, *, test_start: pd.Timestamp | None = None, embargo_hours: int = 0) -> dict[str, object]:
    target = f"forward_return_{horizon}h"
    series = cross_sectional_ic_series(frame, factor, target)
    stat = summarize_ic(series["ic"].tolist() if not series.empty else [], horizon)
    total = len(frame)
    used = int(series["n"].sum()) if not series.empty else 0
    start = pd.to_datetime(frame["feature_time"], utc=True, errors="coerce").min() if not frame.empty else pd.NaT
    end = pd.to_datetime(frame["feature_time"], utc=True, errors="coerce").max() if not frame.empty else pd.NaT
    return {
        "split": split, "factor": factor, "horizon": horizon,
        "train_start": "" if pd.isna(start) else start.isoformat(), "train_end": "" if pd.isna(end) else end.isoformat(),
        "test_start": "" if test_start is None else test_start.isoformat(), "test_end": "" if split == "test_oos" else "",
        "embargo_hours": embargo_hours, "n_timestamps": stat["n_periods"], "n_observations": used,
        "coverage": float(used / total) if total else 0.0, **stat,
        "status": "computed" if stat["n_periods"] else "insufficient evidence",
    }


def split_ic(panel: pd.DataFrame, labels: pd.DataFrame, factor: str = "momentum_1h", horizon: int = 24) -> pd.DataFrame:
    """Timestamp-level train/test IC with purging at the test boundary."""
    df = _merged(panel, labels, horizon)
    target = f"forward_return_{horizon}h"
    exit_col = f"exit_time_{horizon}h"
    if df.empty or factor not in df or target not in df:
        return pd.DataFrame([{ "test": "time_oos", "factor": factor, "horizon": horizon, "status": "insufficient evidence" }])
    times = sorted(pd.to_datetime(df["feature_time"], utc=True).dropna().unique())
    cut = max(1, int(len(times) * 0.7))
    test_start = pd.Timestamp(times[cut]) if cut < len(times) else pd.Timestamp(times[-1])
    train = df[df["feature_time"] < test_start].copy()
    if exit_col in train:
        # Purge every train label whose future endpoint touches the test set.
        train = train[train[exit_col] < test_start]
    test = df[df["feature_time"] >= test_start].copy()
    rows = []
    train_start = pd.to_datetime(train["feature_time"], utc=True).min() if not train.empty else pd.NaT
    train_end = pd.to_datetime(train["feature_time"], utc=True).max() if not train.empty else pd.NaT
    test_end = pd.to_datetime(test["feature_time"], utc=True).max() if not test.empty else pd.NaT
    for split, subset in (("train", train), ("test_oos", test)):
        row = _inference_row(subset[[c for c in subset.columns if c in {"feature_time", factor, target}]], factor, horizon, split, test_start=test_start, embargo_hours=horizon)
        row["test"] = "time_oos"
        row["train_start"] = "" if pd.isna(train_start) else train_start.isoformat()
        row["train_end"] = "" if pd.isna(train_end) else train_end.isoformat()
        row["test_start"] = "" if pd.isna(test_start) else test_start.isoformat()
        row["test_end"] = "" if pd.isna(test_end) else test_end.isoformat()
        rows.append(row)
    return pd.DataFrame(rows)


def subperiod_ic(panel: pd.DataFrame, labels: pd.DataFrame, factor: str = "momentum_1h", horizon: int = 24) -> pd.DataFrame:
    df = _merged(panel, labels, horizon)
    if df.empty or factor not in df:
        return pd.DataFrame()
    times = sorted(pd.to_datetime(df["feature_time"], utc=True).dropna().unique())
    midpoint = max(1, len(times) // 2)
    rows = []
    for period, selected in (("first_half", times[:midpoint]), ("second_half", times[midpoint:])):
        subset = df[df["feature_time"].isin(selected)]
        row = _inference_row(subset[[c for c in subset.columns if c in {"feature_time", factor, f"forward_return_{horizon}h"}]], factor, horizon, period)
        row["scope"] = "subperiod"
        rows.append(row)
    return pd.DataFrame(rows)


def leave_one_chain_out(panel: pd.DataFrame, labels: pd.DataFrame | None = None, factor: str = "momentum_1h", horizon: int = 24) -> pd.DataFrame:
    """Compute held-out-chain timestamp-level IC, not pooled token returns."""
    if labels is None:
        return pd.DataFrame([{ "test": "leave_one_chain_out", "status": "NOT_RUN", "reason": "Labels are required for cross-sectional IC." }])
    df = _merged(panel, labels, horizon)
    target = f"forward_return_{horizon}h"
    rows = []
    for chain in sorted(df["chain"].dropna().astype(str).unique()):
        test = df[df["chain"].astype(str) == chain]
        series = cross_sectional_ic_series(test, factor, target)
        stat = summarize_ic(series["ic"].tolist() if not series.empty else [], horizon)
        rows.append({"test": "leave_one_chain_out", "held_out_chain": chain, "factor": factor, "horizon": horizon, "train_rows": int((df["chain"].astype(str) != chain).sum()), "test_rows": int(len(test)), "n_timestamps": stat["n_periods"], "coverage": float(series["n"].sum() / len(test)) if len(test) else 0.0, **stat, "status": "computed" if stat["n_periods"] else "insufficient evidence"})
    return pd.DataFrame(rows)
