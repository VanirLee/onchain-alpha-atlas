from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


def _read(root: Path, relative: str) -> pd.DataFrame:
    path = root / relative
    if path.suffix == ".parquet" and path.exists():
        return pd.read_parquet(path)
    if path.suffix == ".csv" and path.exists():
        return pd.read_csv(path)
    return pd.DataFrame()


def build_phase2_report(root: Path) -> Path:
    events = _read(root, "artifacts/event_study_results.parquet")
    state = _read(root, "artifacts/state_results.parquet")
    registry = _read(root, "artifacts/experiment_registry.parquet")
    coverage = _read(root, "artifacts/research_coverage.parquet")
    inventory = _read(root, "artifacts/CEX_DATA_INVENTORY.csv")
    factor = _read(root, "reports/factor_ic.csv")
    event_sig = int(events.get("significant_q05", pd.Series(dtype=bool)).fillna(False).sum()) if not events.empty else 0
    top_events = events.sort_values("mean_return").head(6)[[c for c in ["detector_percentile", "horizon", "n_events", "mean_return", "p_value", "fdr_adjusted_p_value"] if c in events]].to_dict("records") if not events.empty else []
    state_summary = state.groupby(["state_variable", "state_bucket"], dropna=False)["mean_return"].mean().reset_index().to_dict("records") if not state.empty and "mean_return" in state else []
    statuses = registry["result"].value_counts().to_dict() if not registry.empty and "result" in registry else {}
    cex_usable = int((~inventory.get("usable_status", pd.Series(dtype=str)).astype(str).str.contains("NO_LOCAL|EMPTY|NOT_CEX", case=False, na=False)).sum()) if not inventory.empty else 0
    lines = [
        "# Phase II Research Report", "", f"Generated: {datetime.now(timezone.utc).isoformat()}", "", "## Executive Summary", "",
        "Phase II activated real event, information-transmission, market-state, and corrected-baseline research without redesigning the frozen PIT/statistics/backtest engine. The current panel is still a current hot-token backfill, not a historical all-token PIT universe.", "",
        f"- Event-study rows: `{len(events)}`; threshold-horizon q<0.05 rows after BH: `{event_sig}` (exploratory only).", f"- State-conditional rows: `{len(state)}`.", f"- Registry experiments: `{len(registry)}`; statuses: `{json.dumps(statuses, ensure_ascii=False)}`.", f"- Local CEX inventory rows usable as CEX: `{cex_usable}`.", f"- Factor baseline rows: `{len(factor)}`.", "",
        "## Family A — Participant Information Advantage", "", "H003 is `BLOCKED_BY_DATA`: the current saved dataset has no wallet trade/holding panel with prior closed-trade outcomes and available-time semantics. No wallet skill or wallet-return finding is claimed.", "",
        "## Family B — Event Response", "", "H001 uses the pre-declared 90/95/97.5/99 volume threshold grid and 1h/4h/24h exact timestamp outcomes. The unmatched response design is exploratory and not causal; overlapping episodes and current-universe selection remain material limitations.", "", json.dumps(top_events, ensure_ascii=False, indent=2, default=str), "", "The BH-adjusted event rows are hypothesis-screening outputs, not OOS-supported alpha. A significant in-sample p-value is not sufficient for execution research.", "",
        "## Family C — Information Transmission", "", "H002 estimates volume-to-future-return lead-lag with HAC regression at 1h/4h/24h. It is predictive association, not causality. A synchronized CEX spot/perpetual panel is required to test a true cross-venue transmission path.", "",
        "## Family D — Market State Dependence", "", "H004 conditions event response on pre-event liquidity and volatility buckets. Current state summaries:", "", json.dumps(state_summary, ensure_ascii=False, indent=2, default=str), "", "These are exploratory conditional associations; the history is insufficient for an OOS-supported regime claim.", "",
        "## Family E — Relative Value / Price Discovery", "", "H005 is `BLOCKED_BY_DATA`: no local Binance Spot/Futures history, synchronized DEX-CEX mapping, or executable depth was found. Capacity is not estimated.", "",
        "## Family F — Network Diffusion", "", "H006 is `BLOCKED_BY_DATA`: no wallet-token edge panel is available. The temporal graph engine remains schema-ready and as-of safe, but no diffusion result is fabricated.", "",
        "## Baseline Factor Family", "", "H007 retains the corrected factor panel as a benchmark. It is not the Phase II primary objective. Its IC/HAC, BH-FDR, purged OOS, and leave-one-chain-out outputs remain in the formal baseline reports.", "",
        "## Falsification, OOS, and tradeability", "", "Future-data invariance tests pass and all threshold variants are retained. No Phase II finding is `OOS_SUPPORTED` or `ECONOMICALLY_VIABLE`; there is no execution candidate. The current run reports `INSUFFICIENT_OOS_HISTORY` for new event/state variants rather than forcing a split.", "",
        "## Highest-value next data", "", "1. Synchronized Binance Spot klines/trades/depth and USDⓈ-M Futures klines/funding/OI/mark-index data.", "2. Paginated Web3 token trades with wallet/address fields and reliable available timestamps.", "3. Wallet holdings/balances plus closed-trade exits and PnL available before measurement time.", "",
        "## Limitations", "", "Current hot-token selection and survivor bias; short/non-synchronized history; no executable depth, latency, gas/funding, or cross-venue mapping; wallet/entity families blocked."
    ]
    path = root / "reports" / "PHASE2_RESEARCH_REPORT.md"; path.write_text("\n".join(lines) + "\n", encoding="utf-8"); return path
