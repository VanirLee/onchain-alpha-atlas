from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from .plots import make_figures


def build_report(root: Path, manifest: dict[str, Any]) -> Path:
    def read(name: str) -> pd.DataFrame:
        p = root / "reports" / name
        return pd.read_csv(p) if p.exists() else pd.DataFrame()
    ic = read("factor_ic.csv")
    bt = read("backtest_results.csv")
    robustness = read("robustness.csv")
    family_rows = []
    registry_path = root / "artifacts" / "experiment_registry.parquet"
    if registry_path.exists():
        registry = pd.read_parquet(registry_path)
        if not registry.empty:
            family_rows = registry.sort_values("created_at").drop_duplicates("hypothesis_id", keep="last").to_dict("records")
    event_study = pd.read_parquet(root / "artifacts/event_study_results.parquet") if (root / "artifacts/event_study_results.parquet").exists() else pd.DataFrame()
    lead_lag = pd.read_parquet(root / "artifacts/lead_lag_results.parquet") if (root / "artifacts/lead_lag_results.parquet").exists() else pd.DataFrame()
    wallet = pd.read_parquet(root / "artifacts/wallet_skill_results.parquet") if (root / "artifacts/wallet_skill_results.parquet").exists() else pd.DataFrame()
    network = pd.read_parquet(root / "artifacts/network_results.parquet") if (root / "artifacts/network_results.parquet").exists() else pd.DataFrame()
    figures = make_figures(root, ic, bt)
    strongest = ic.sort_values("mean_ic", ascending=False).head(5)[["factor", "horizon", "mean_ic", "status"]].to_dict("records") if not ic.empty and "mean_ic" in ic else []
    unstable = ic[(ic.get("status", pd.Series(dtype=str)) != "computed") | (ic.get("significant_q05", pd.Series(False, index=ic.index)) == False)].head(10).to_dict("records") if not ic.empty else []
    lines = [
        "# Onchain Alpha Atlas Research Report", "", f"Generated: {datetime.now(timezone.utc).isoformat()}", "",
        "## 1. Executive Summary", "",
        "This is a point-in-time research run over Binance Web3 read-only observations. It is not a trading-execution or arbitrage result. Results are labelled `insufficient evidence` when the sample cannot support inference.", "",
        f"- Collection source: `{manifest.get('collection_source', 'unknown')}`", f"- Universe size: `{manifest.get('universe_size', 0)}`", f"- Factor count: `{manifest.get('factor_count', 0)}`", f"- Read-only: `{manifest.get('read_only', True)}`", "",
        "## 2. Data and PIT methodology", "",
        "Raw API responses are retained in Bronze; normalized observations carry `observed_at`, `known_at`, request hashes, payload hashes, and feature-safety metadata. Candle event time is used when supplied. Outcome-like fields such as `maxGain` are not used as triggers. Current-state values are not backfilled into past timestamps.", "",
        "## 3. Universe construction", "",
        "The live universe is derived from the API's ranked hot-token discovery endpoint by chain. Token identity is `(chain, token_address)`, with first/last seen and discovery source. A survivor-only universe is not claimed.", "",
        "## 4. Factor definitions and hypotheses", "",
        "Market, liquidity, flow, smart-money proxy, holder proxy, attention/rank proxy, risk proxy, and ecosystem/regime factors are computed only from fields available at the observation time. Unsupported wallet/event endpoints remain explicit extension points.", "",
        "## 5. Research family results", "",
        "The platform now treats factors as a baseline family. Event response and lead-lag outputs are association studies, not causal claims; entity skill and temporal network families remain explicitly blocked when the required wallet/trade edge panel is absent.", "",
        json.dumps([{"hypothesis_id": row.get("hypothesis_id"), "family": row.get("family"), "status": row.get("result"), "variant": row.get("variant")} for row in family_rows], ensure_ascii=False, indent=2, default=str) if family_rows else "insufficient evidence: no hypothesis registry rows.", "",
        "### Non-factor evidence", "",
        f"- Event response: `{event_study.iloc[0].get('status', 'NOT_RUN') if not event_study.empty else 'NOT_RUN'}`; unmatched event returns are not interpreted causally.",
        f"- Lead-lag: `{lead_lag['status'].astype(str).iloc[0] if not lead_lag.empty and 'status' in lead_lag else 'NOT_RUN'}`; output is predictive association only.",
        f"- Wallet/entity skill: `{wallet['status'].astype(str).iloc[0] if not wallet.empty and 'status' in wallet else 'NOT_RUN'}`; no future PnL or identity labels are fabricated.",
        f"- Temporal network: `{network['status'].astype(str).iloc[0] if not network.empty and 'status' in network else 'NOT_RUN'}`; as-of edge logic is implemented but current edge data are unavailable.", "",
        "## 6. Factor results", "",
        json.dumps(strongest, ensure_ascii=False, indent=2, default=str) if strongest else "insufficient evidence: no factor has enough valid cross-sections.", "",
        "## 7. Cross-sectional regression", "",
        "The implementation supports Fama–MacBeth-style cross-sectional screening with HAC/Newey-West covariance. Overlapping-label limitations remain and are not hidden.", "",
        "## 8. Multiple testing", "",
        "Benjamini–Hochberg FDR is applied across the reported factor/horizon hypotheses. Raw p-values and q=0.05/q=0.10 flags are exported.", "",
        "## 9. Portfolio results and transaction costs", "",
        "Long-only top-quantile and optional long/short portfolios are evaluated at 5/10/25/50/100 bps. Costs are parameterized proxies, not executable quotes or depth.", "",
        "## 10. Robustness", "",
        json.dumps(robustness.to_dict("records"), ensure_ascii=False, indent=2, default=str) if not robustness.empty else "insufficient evidence: robustness splits require more observations.", "",
        "## 11. Smart-money and wallet studies", "",
        "Smart-money and wallet-specific studies are marked unsupported unless the corresponding read-only endpoint is confirmed. Existing smart-money outcome fields are not used as features. Wallet persona clustering is therefore deferred rather than fabricated.", "",
        "## 12. Failure cases and limitations", "",
        json.dumps(unstable, ensure_ascii=False, indent=2, default=str) if unstable else "No stable factor conclusion was asserted.", "",
        "## 13. Conclusions", "",
        "The current run is a reproducible data and research pipeline. Any promising factor is a candidate for longer prospective collection, not evidence of a deployable strategy. The most valuable next step is to accumulate a longer PIT panel, then rerun the pre-specified OOS and leave-one-chain-out tests.", "",
        "## Figures", "", *[f"- `{p}`" for p in figures],
    ]
    path = root / "reports" / "research_report.md"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
