from __future__ import annotations

from pathlib import Path
import pandas as pd


def make_figures(root: Path, ic: pd.DataFrame | None = None, backtest: pd.DataFrame | None = None) -> list[str]:
    out = root / "reports" / "figures"
    out.mkdir(parents=True, exist_ok=True)
    paths: list[str] = []
    try:
        import matplotlib.pyplot as plt
        if ic is not None and not ic.empty and "mean_ic" in ic:
            chart = ic.sort_values("mean_ic").tail(20)
            fig, ax = plt.subplots(figsize=(9, 6))
            ax.barh(chart["factor"], chart["mean_ic"]); ax.set_title("Factor mean Rank IC"); ax.set_xlabel("mean IC")
            p = out / "factor_ic_distribution.png"; fig.tight_layout(); fig.savefig(p, dpi=140); plt.close(fig); paths.append(str(p))
        if backtest is not None and not backtest.empty and "net_return" in backtest:
            fig, ax = plt.subplots(figsize=(8, 4)); ax.plot(backtest["cost_bps"], backtest["net_return"], marker="o"); ax.set_title("Cost sensitivity"); ax.set_xlabel("cost bps"); ax.set_ylabel("mean net return");
            p = out / "cost_sensitivity.png"; fig.tight_layout(); fig.savefig(p, dpi=140); plt.close(fig); paths.append(str(p))
    except Exception:
        pass
    return paths
