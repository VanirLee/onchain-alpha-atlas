from __future__ import annotations

from typing import Iterable

import pandas as pd


FOUR_CLOCKS = ("event_time", "observed_time", "available_time", "ingest_time")
ENTITY_TYPES = ("wallet", "entity", "token", "pool", "dex", "chain", "bridge", "cex", "cex_instrument", "transaction", "trade", "market_event")
ECONOMIC_PRIMITIVES = ("information", "flow", "inventory", "liquidity", "crowding", "relative_value", "volatility_risk", "regime_state", "diffusion", "execution")


def ensure_pit_columns(frame: pd.DataFrame, *, copy: bool = True) -> pd.DataFrame:
    """Normalize the four-clock contract without inventing event times."""
    out = frame.copy() if copy else frame
    for col in FOUR_CLOCKS:
        if col not in out:
            out[col] = pd.NaT
        out[col] = pd.to_datetime(out[col], utc=True, errors="coerce")
    if "available_time" in out and "observed_time" in out:
        out["available_time"] = out["available_time"].fillna(out["observed_time"])
    if "ingest_time" in out and "available_time" in out:
        out["ingest_time"] = out["ingest_time"].fillna(out["available_time"])
    return out


def require_columns(frame: pd.DataFrame, columns: Iterable[str]) -> None:
    missing = [col for col in columns if col not in frame.columns]
    if missing:
        raise ValueError(f"missing canonical columns: {missing}")
