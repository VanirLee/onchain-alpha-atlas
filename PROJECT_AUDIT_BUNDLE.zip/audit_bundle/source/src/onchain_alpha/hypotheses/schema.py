from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Hypothesis:
    id: str
    family: str
    title: str
    research_question: str
    economic_mechanism: str
    economic_primitives: tuple[str, ...]
    entity_scope: str
    data_dependencies: tuple[str, ...]
    research_methods: tuple[str, ...]
    prediction_horizons: tuple[str, ...]
    classification: str = "EXPLORATORY"
    status: str = "NOT_RUN"
    parameters: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_mapping(cls, data: dict[str, Any]) -> "Hypothesis":
        return cls(
            id=str(data["id"]), family=str(data["family"]), title=str(data["title"]), research_question=str(data.get("research_question", "")), economic_mechanism=str(data.get("economic_mechanism", "")),
            economic_primitives=tuple(data.get("economic_primitives", ())), entity_scope=str(data.get("entity_scope", "")), data_dependencies=tuple(data.get("data_dependencies", ())), research_methods=tuple(data.get("research_methods", ())), prediction_horizons=tuple(str(x) for x in data.get("prediction_horizons", ())), classification=str(data.get("classification", "EXPLORATORY")), status=str(data.get("status", "NOT_RUN")), parameters=dict(data.get("parameters", {})),
        )
