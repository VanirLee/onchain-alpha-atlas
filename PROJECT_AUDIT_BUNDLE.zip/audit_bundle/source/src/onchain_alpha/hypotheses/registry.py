from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

from .schema import Hypothesis


def load_hypotheses(root: Path) -> list[Hypothesis]:
    directory = root / "configs" / "hypotheses"
    return [Hypothesis.from_mapping(yaml.safe_load(path.read_text(encoding="utf-8"))) for path in sorted(directory.glob("*.yaml"))]


def load_hypothesis(root: Path, hypothesis_id: str) -> Hypothesis:
    for hypothesis in load_hypotheses(root):
        if hypothesis.id == hypothesis_id:
            return hypothesis
    raise KeyError(f"unknown hypothesis: {hypothesis_id}")


class ExperimentRegistry:
    def __init__(self, root: Path):
        self.root = root
        self.path = root / "artifacts" / "experiment_registry.parquet"

    def record(self, *, hypothesis: Hypothesis, variant: str, result: str, dataset_hash: str, code_hash: str | None, parameters: dict[str, Any], p_value: float | None = None, adjusted_p_value: float | None = None, oos_result: str = "NOT_RUN", config_hash: str | None = None, universe_version: str = "CURRENT-UNIVERSE-BACKFILL", data_start: str | None = None, data_end: str | None = None) -> pd.DataFrame:
        row = {"experiment_id": hashlib.sha256(f"{hypothesis.id}|{variant}|{json.dumps(parameters, sort_keys=True, default=str)}".encode()).hexdigest()[:20], "hypothesis_id": hypothesis.id, "family": hypothesis.family, "variant": variant, "parameters": json.dumps(parameters, sort_keys=True, default=str), "dataset_version": dataset_hash, "code_version": code_hash, "config_hash": config_hash, "universe_version": universe_version, "data_start": data_start, "data_end": data_end, "created_at": datetime.now(timezone.utc).isoformat(), "classification": hypothesis.classification, "result": result, "p_value": p_value, "adjusted_p_value": adjusted_p_value, "oos_result": oos_result}
        prior = pd.read_parquet(self.path) if self.path.exists() else pd.DataFrame()
        out = pd.concat([prior, pd.DataFrame([row])], ignore_index=True).drop_duplicates("experiment_id", keep="last")
        self.path.parent.mkdir(parents=True, exist_ok=True); out.to_parquet(self.path, index=False)
        return out
