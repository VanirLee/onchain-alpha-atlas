from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd


class ParquetStore:
    def __init__(self, root: Path):
        self.root = root

    def write(self, name: str, rows: list[dict[str, Any]] | pd.DataFrame) -> Path:
        path = self.root / "gold" / f"{name}.parquet"
        path.parent.mkdir(parents=True, exist_ok=True)
        frame = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(rows)
        frame.to_parquet(path, index=False)
        return path

    def read(self, name: str) -> pd.DataFrame:
        return pd.read_parquet(self.root / "gold" / f"{name}.parquet")
