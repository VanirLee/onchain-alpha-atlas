from __future__ import annotations

from pathlib import Path
from typing import Any


class Catalog:
    def __init__(self, root: Path):
        self.root = root
        self.path = root / "artifacts" / "catalog.duckdb"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def refresh(self) -> dict[str, Any]:
        try:
            import duckdb
        except ImportError:
            return {"status": "unavailable", "reason": "duckdb not installed"}
        con = duckdb.connect(str(self.path))
        tables: dict[str, str] = {}
        for name in ("market_observations", "universe", "factor_panel", "labels"):
            file = self.root / "gold" / f"{name}.parquet"
            if file.exists():
                con.execute(f"CREATE OR REPLACE VIEW {name} AS SELECT * FROM read_parquet(?)", [str(file)])
                tables[name] = str(file)
        con.close()
        return {"status": "ok", "path": str(self.path), "tables": tables}
