from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def stable_hash(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode()
    return hashlib.sha256(raw).hexdigest()


class RawStore:
    def __init__(self, root: Path):
        self.root = root

    def write(self, *, source: str, endpoint: str, chain: str, payload: Any, request_params: Any, observed_at: str, response_meta: dict[str, Any]) -> Path:
        day = observed_at[:10]
        folder = self.root / "bronze" / f"source={source}" / f"endpoint={endpoint.strip('/').replace('/', '_')}" / f"chain={chain}" / f"date={day}"
        folder.mkdir(parents=True, exist_ok=True)
        params_hash, payload_hash = stable_hash(request_params), stable_hash(payload)
        path = folder / f"{observed_at.replace(':', '').replace('+00:00', 'Z')}_{payload_hash[:16]}.json"
        record = {
            "source": source, "endpoint": endpoint, "chain": chain,
            "observed_at": observed_at, "ingested_at": datetime.now(timezone.utc).isoformat(),
            "request_params": request_params, "request_params_hash": params_hash, "payload_hash": payload_hash,
            "response_meta": response_meta, "payload": payload,
        }
        if not path.exists():
            path.write_text(json.dumps(record, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
        return path
