from __future__ import annotations

import pandas as pd


def asof_graph_edges(edges: pd.DataFrame, decision_time: pd.Timestamp) -> pd.DataFrame:
    """Return only edges known and economically present at decision_time."""
    if edges.empty:
        return edges.copy()
    out = edges.copy()
    decision = pd.Timestamp(decision_time, tz="UTC") if pd.Timestamp(decision_time).tzinfo is None else pd.Timestamp(decision_time).tz_convert("UTC")
    for col in ("event_time", "available_time", "start_time"):
        if col in out:
            out[col] = pd.to_datetime(out[col], utc=True, errors="coerce")
    if "available_time" in out:
        out = out[out["available_time"] <= decision]
    if "event_time" in out:
        out = out[out["event_time"] <= decision]
    if "start_time" in out:
        out = out[out["start_time"].isna() | (out["start_time"] <= decision)]
    return out.copy()


def temporal_snapshot_summary(edges: pd.DataFrame, decision_time: pd.Timestamp) -> dict[str, object]:
    snapshot = asof_graph_edges(edges, decision_time)
    return {"decision_time": pd.Timestamp(decision_time, tz="UTC").isoformat() if pd.Timestamp(decision_time).tzinfo is None else pd.Timestamp(decision_time).tz_convert("UTC").isoformat(), "n_edges": int(len(snapshot)), "n_nodes": int(pd.unique(pd.concat([snapshot.get("source", pd.Series(dtype=str)), snapshot.get("target", pd.Series(dtype=str))])).size) if not snapshot.empty else 0, "status": "COMPUTED" if not snapshot.empty else "BLOCKED_BY_DATA"}
