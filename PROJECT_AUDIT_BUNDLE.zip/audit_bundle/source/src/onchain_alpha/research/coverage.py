from __future__ import annotations

from pathlib import Path

import pandas as pd


def build_research_coverage(root: Path) -> pd.DataFrame:
    universe = pd.read_parquet(root / "data/gold/universe.parquet") if (root / "data/gold/universe.parquet").exists() else pd.DataFrame()
    state = pd.read_parquet(root / "data/gold/canonical/fact_token_market_state.parquet") if (root / "data/gold/canonical/fact_token_market_state.parquet").exists() else pd.DataFrame()
    events = pd.read_parquet(root / "artifacts/events.parquet") if (root / "artifacts/events.parquet").exists() else pd.DataFrame()
    cex = pd.read_csv(root / "artifacts/CEX_DATA_INVENTORY.csv") if (root / "artifacts/CEX_DATA_INVENTORY.csv").exists() else pd.DataFrame()
    start = pd.to_datetime(state["event_time"], utc=True, errors="coerce").min().isoformat() if not state.empty else ""
    end = pd.to_datetime(state["event_time"], utc=True, errors="coerce").max().isoformat() if not state.empty else ""
    has_cex = bool(not cex.empty and (cex["usable_status"].astype(str).str.contains("CEX", case=False, na=False) & ~cex["usable_status"].astype(str).str.contains("NO_LOCAL|NOT_CEX", case=False, na=False)).any())
    rows = [
        {"research_family": "participant_information_advantage", "data_available": False, "sample_size": 0, "time_start": "", "time_end": "", "entities": 0, "events": 0, "chains": 0, "oos_available": False, "execution_data": False, "status": "BLOCKED_BY_DATA", "next_data": "wallet trade history with exit/available clocks"},
        {"research_family": "event_response", "data_available": bool(not events.empty), "sample_size": int(len(events)), "time_start": start, "time_end": end, "entities": int(state["asset_id"].nunique()) if not state.empty else 0, "events": int(len(events)), "chains": int(state["chain"].nunique()) if not state.empty else 0, "oos_available": False, "execution_data": False, "status": "EXPLORATORY" if not events.empty else "INSUFFICIENT_EVIDENCE", "next_data": "longer event history and matched controls"},
        {"research_family": "information_transmission", "data_available": bool(not state.empty), "sample_size": int(len(state)), "time_start": start, "time_end": end, "entities": int(state["asset_id"].nunique()) if not state.empty else 0, "events": 0, "chains": int(state["chain"].nunique()) if not state.empty else 0, "oos_available": False, "execution_data": False, "status": "EXPLORATORY" if not state.empty else "BLOCKED_BY_DATA", "next_data": "CEX spot/perpetual synchronized panel"},
        {"research_family": "market_state_dependence", "data_available": bool(not state.empty and not events.empty), "sample_size": int(len(events)), "time_start": start, "time_end": end, "entities": int(state["asset_id"].nunique()) if not state.empty else 0, "events": int(len(events)), "chains": int(state["chain"].nunique()) if not state.empty else 0, "oos_available": False, "execution_data": False, "status": "EXPLORATORY" if not state.empty and not events.empty else "INSUFFICIENT_EVIDENCE", "next_data": "longer history with contemporaneous liquidity and volatility"},
        {"research_family": "relative_value_price_discovery", "data_available": has_cex, "sample_size": 0, "time_start": "", "time_end": "", "entities": 0, "events": 0, "chains": 0, "oos_available": False, "execution_data": False, "status": "EXPLORATORY" if has_cex else "BLOCKED_BY_DATA", "next_data": "CEX spot/perpetual prices, funding, OI, depth"},
        {"research_family": "network_diffusion", "data_available": False, "sample_size": 0, "time_start": "", "time_end": "", "entities": 0, "events": 0, "chains": 0, "oos_available": False, "execution_data": False, "status": "BLOCKED_BY_DATA", "next_data": "wallet-token trade edges and entity resolution"},
        {"research_family": "factor_baseline", "data_available": bool(not state.empty), "sample_size": int(len(state)), "time_start": start, "time_end": end, "entities": int(universe["token_address"].nunique()) if not universe.empty else 0, "events": 0, "chains": int(universe["chain"].nunique()) if not universe.empty else 0, "oos_available": (root / "artifacts/oos_results.parquet").exists(), "execution_data": False, "status": "EXPLORATORY" if not state.empty else "NOT_RUN", "next_data": "PIT historical universe and longer synchronized panel"},
    ]
    out = pd.DataFrame(rows); out.to_parquet(root / "artifacts/research_coverage.parquet", index=False); return out
