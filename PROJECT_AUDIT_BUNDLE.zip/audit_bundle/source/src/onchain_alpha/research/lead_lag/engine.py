from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import pearsonr
import statsmodels.api as sm


def run_lead_lag(market_state: pd.DataFrame, *, x: str = "volume", y: str = "price", lags: tuple[int, ...] = (1, 4, 24)) -> pd.DataFrame:
    """Estimate timestamp-aligned lead-lag association; not causality."""
    if market_state.empty or x not in market_state or y not in market_state:
        return pd.DataFrame([{"status": "BLOCKED_BY_DATA", "reason": "required series unavailable"}])
    df = market_state.copy(); df["event_time"] = pd.to_datetime(df["event_time"], utc=True, errors="coerce"); df["chain"] = df["chain"].astype(str)
    for col in (x, y): df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["chain", "event_time", x, y]).sort_values(["chain", "event_time"])
    df["y_return"] = df.groupby("chain")[y].pct_change()
    agg = df.groupby(["chain", "event_time"], as_index=False).agg(x_value=(x, "mean"), y_return=("y_return", "mean"))
    rows = []
    for lag in lags:
        target = agg.copy(); target["target_time"] = target["event_time"] + pd.Timedelta(hours=int(lag))
        right = agg[["chain", "event_time", "y_return"]].rename(columns={"event_time": "target_time", "y_return": "future_y_return"})
        joined = target.merge(right, on=["chain", "target_time"], how="inner").dropna(subset=["x_value", "future_y_return"])
        if len(joined) < 8 or joined["x_value"].nunique() < 2 or joined["future_y_return"].nunique() < 2:
            rows.append({"x": x, "y": y, "lag_hours": lag, "n_observations": int(len(joined)), "status": "INSUFFICIENT_EVIDENCE", "interpretation": "not causal"})
            continue
        corr, corr_p = pearsonr(joined["x_value"], joined["future_y_return"])
        model = sm.OLS(joined["future_y_return"], sm.add_constant(joined[["x_value"]])).fit(cov_type="HAC", cov_kwds={"maxlags": min(int(lag), len(joined) - 1)})
        rows.append({"x": x, "y": y, "lag_hours": lag, "n_observations": int(len(joined)), "correlation": float(corr), "correlation_p_value": float(corr_p), "beta": float(model.params["x_value"]), "HAC_t_stat": float(model.tvalues["x_value"]), "HAC_p_value": float(model.pvalues["x_value"]), "HAC_lag": min(int(lag), len(joined) - 1), "status": "EXPLORATORY", "interpretation": "predictive association, not causal"})
    return pd.DataFrame(rows)
