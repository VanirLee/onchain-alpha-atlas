from __future__ import annotations

from datetime import timedelta

import numpy as np
import pandas as pd


def _state_frame(market_state: pd.DataFrame) -> pd.DataFrame:
    df = market_state.copy()
    df["event_time"] = pd.to_datetime(df["event_time"], utc=True, errors="coerce")
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    df["liquidity"] = pd.to_numeric(df.get("liquidity"), errors="coerce")
    df = df.sort_values(["asset_id", "event_time"])
    df["asset_return_1h"] = df.groupby("asset_id")["price"].pct_change()
    df["volatility_24h"] = df.groupby("asset_id")["asset_return_1h"].transform(lambda s: s.shift(1).rolling(24, min_periods=6).std())
    df["liquidity_state"] = df.groupby(["chain", "event_time"])["liquidity"].transform(lambda s: np.where(s >= s.median(), "HIGH", "LOW"))
    df["volatility_state"] = df.groupby(["chain", "event_time"])["volatility_24h"].transform(lambda s: np.where(s >= s.median(), "HIGH", "LOW"))
    return df


def run_state_conditional_event_study(events: pd.DataFrame, market_state: pd.DataFrame, *, horizons: tuple[int, ...] = (1, 4, 24)) -> pd.DataFrame:
    """Estimate event response conditional on states known at event_time.

    The state variables are formed from prior returns or current-time liquidity
    snapshots. No post-event state is used for conditioning.
    """
    if events.empty or market_state.empty:
        return pd.DataFrame([{"status": "BLOCKED_BY_DATA", "reason": "events or market_state unavailable"}])
    state = _state_frame(market_state)
    state["asset_id"] = state["asset_id"].astype(str)
    lookup = state.dropna(subset=["asset_id", "event_time", "price"]).drop_duplicates(["asset_id", "event_time"], keep="last").set_index(["asset_id", "event_time"])
    rows = []
    for _, event in events.iterrows():
        event_time = pd.Timestamp(event["event_time"])
        if event_time.tzinfo is None:
            event_time = event_time.tz_localize("UTC")
        key = (str(event["asset_id"]), event_time.tz_convert("UTC"))
        if key not in lookup.index:
            continue
        base = lookup.loc[key]
        for horizon in horizons:
            target_key = (str(event["asset_id"]), event_time + timedelta(hours=int(horizon)))
            if target_key not in lookup.index:
                continue
            future = lookup.loc[target_key]
            if not np.isfinite(float(base["price"])) or not np.isfinite(float(future["price"])) or float(base["price"]) == 0:
                continue
            for state_name in ("liquidity_state", "volatility_state"):
                condition = str(base.get(state_name, "UNKNOWN"))
                rows.append({"event_id": event["event_id"], "horizon": int(horizon), "state_variable": state_name, "state_bucket": condition, "return": float(future["price"] / base["price"] - 1), "event_time": event_time})
    observed = pd.DataFrame(rows)
    if observed.empty:
        return pd.DataFrame([{"status": "INSUFFICIENT_EVIDENCE", "reason": "no exact event/outcome matches"}])
    out = []
    for (horizon, state_variable, state_bucket), group in observed.groupby(["horizon", "state_variable", "state_bucket"], dropna=False):
        values = group["return"].to_numpy(dtype=float)
        out.append({"hypothesis_id": "H004", "horizon": int(horizon), "state_variable": state_variable, "state_bucket": state_bucket, "n_events": int(len(values)), "mean_return": float(np.mean(values)), "median_return": float(np.median(values)), "hit_rate": float(np.mean(values > 0)), "independent_event_episodes": int(group["event_id"].nunique()), "status": "EXPLORATORY" if len(values) >= 3 else "INSUFFICIENT_EVIDENCE", "interpretation": "conditional association; not causal"})
    return pd.DataFrame(out)
