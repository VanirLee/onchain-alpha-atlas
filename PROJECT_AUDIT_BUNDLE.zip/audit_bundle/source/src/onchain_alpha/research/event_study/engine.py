from __future__ import annotations

from datetime import timedelta

import numpy as np
import pandas as pd
from scipy.stats import t as student_t


def _bootstrap_mean(values: np.ndarray, seed: int, n_bootstrap: int) -> tuple[float | None, float | None]:
    if len(values) < 2:
        return None, None
    rng = np.random.default_rng(seed)
    samples = rng.choice(values, size=(n_bootstrap, len(values)), replace=True).mean(axis=1)
    return float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))


def run_event_study(events: pd.DataFrame, market_state: pd.DataFrame, *, horizons: tuple[int, ...] = (1, 4, 24), n_bootstrap: int = 1000, random_seed: int = 42) -> pd.DataFrame:
    """Generic exact-timestamp event response study.

    This estimates association around events. It is not a causal estimate and
    does not claim executable alpha without a matched-control design.
    """
    if events.empty or market_state.empty:
        return pd.DataFrame([{"status": "BLOCKED_BY_DATA", "reason": "events or market_state is empty"}])
    state = market_state.copy()
    state["event_time"] = pd.to_datetime(state["event_time"], utc=True, errors="coerce")
    state["asset_id"] = state["asset_id"].astype(str)
    state["price"] = pd.to_numeric(state["price"], errors="coerce")
    lookup = state.dropna(subset=["asset_id", "event_time", "price"]).drop_duplicates(["asset_id", "event_time"], keep="last").set_index(["asset_id", "event_time"])["price"]
    ev = events.copy(); ev["event_time"] = pd.to_datetime(ev["event_time"], utc=True, errors="coerce"); ev["asset_id"] = ev["asset_id"].astype(str)
    event_rows = []
    for _, row in ev.dropna(subset=["asset_id", "event_time"]).iterrows():
        base = lookup.get((row["asset_id"], row["event_time"]))
        if base is None or not np.isfinite(base) or base == 0:
            continue
        for horizon in horizons:
            target_time = row["event_time"] + timedelta(hours=int(horizon))
            future = lookup.get((row["asset_id"], target_time))
            if future is None or not np.isfinite(future):
                continue
            event_rows.append({"event_id": row["event_id"], "asset_id": row["asset_id"], "chain": row.get("chain", ""), "event_time": row["event_time"], "horizon": horizon, "return": float(future / base - 1), "available_time": row.get("available_time", pd.NaT)})
    observed = pd.DataFrame(event_rows)
    if observed.empty:
        return pd.DataFrame([{"status": "INSUFFICIENT_EVIDENCE", "reason": "No exact event-to-outcome timestamps matched"}])
    rows = []
    for horizon, group in observed.groupby("horizon", sort=True):
        values = group["return"].to_numpy(dtype=float)
        lower, upper = _bootstrap_mean(values, random_seed + int(horizon), n_bootstrap)
        std = float(np.std(values, ddof=1)) if len(values) > 1 else np.nan
        t_stat = float(np.mean(values) / (std / np.sqrt(len(values)))) if len(values) > 1 and np.isfinite(std) and std > 0 else None
        p_value = float(2 * student_t.sf(abs(t_stat), df=len(values) - 1)) if t_stat is not None else None
        event_times = sorted(group["event_time"].unique())
        overlap = sum(1 for left, right in zip(event_times, event_times[1:]) if right - left <= timedelta(hours=int(horizon)))
        available_after_event = int((pd.to_datetime(group["available_time"], utc=True, errors="coerce") > group["event_time"]).sum())
        rows.append({
            "event_type": str(ev["event_type"].iloc[0]), "horizon": int(horizon), "n_events": int(len(values)), "mean_return": float(np.mean(values)), "median_return": float(np.median(values)),
            "aar": float(np.mean(values)), "car": float(np.sum(values) / len(values)), "q05": float(np.quantile(values, 0.05)), "q50": float(np.quantile(values, 0.50)), "q95": float(np.quantile(values, 0.95)),
            "hit_rate": float(np.mean(values > 0)), "bootstrap_ci_lower": lower, "bootstrap_ci_upper": upper, "overlap_rate": float(overlap / max(1, len(event_times))),
            "available_after_event_count": available_after_event, "t_stat": t_stat, "p_value": p_value, "control_definition": "unmatched raw event response; no causal claim", "status": "EXPLORATORY",
        })
    return pd.DataFrame(rows)
