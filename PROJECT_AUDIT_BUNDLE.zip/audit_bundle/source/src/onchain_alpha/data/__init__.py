from .canonical import build_canonical_tables

__all__ = ["build_canonical_tables"]
