"""Phase IV.1 / V: semantic, historical and participant data expansion.

This module deliberately stays below the frozen research engines.  It owns
only the data contract, bounded collectors, clock-time microstructure inputs,
and provenance-bearing Phase V outputs.
"""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable

import numpy as np
import pandas as pd
from scipy.stats import linregress, ttest_1samp

from ..config import Settings
from ..connectors.binance_web3 import (
    ADDRESS_TRANSACTIONS, BALANCES, DEX_HISTORY, HOLDER, LEADERBOARD,
    PORTFOLIO_OVERVIEW, RECENT_PNL, TOKEN_PNL, TOP_LIQUIDITY, TOP_TRADER,
    TRACKED_TRADES, TRADES, BinanceWeb3Client,
)
from .phase3 import TRADE_SCHEMA, _empty, _hash, _safe_json, _utc, normalize_web3_trade
from ..stats.multiple_testing import benjamini_hochberg


TAG_NAMES = {1: "KOL", 2: "Developer", 3: "Smart Money", 4: "Insider", 5: "Sniper", 6: "Bundler", 7: "Whale Holder"}


def _phase5_code_hash(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted([*root.joinpath("src").rglob("*.py"), *root.joinpath("tests").rglob("*.py")]):
        digest.update(path.relative_to(root).as_posix().encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _payload_data(value: Any) -> Any:
    return value if isinstance(value, (dict, list)) else {}


def _trade_rows(payload: Any) -> list[dict[str, Any]]:
    data = _payload_data(payload)
    if isinstance(data, dict) and isinstance(data.get("trades"), list):
        return [x for x in data["trades"] if isinstance(x, dict)]
    return []


def _cursor(payload: Any) -> str | None:
    data = _payload_data(payload)
    if isinstance(data, dict):
        c = data.get("cursor")
        return str(c) if c not in (None, "") else None
    return None


@dataclass
class CursorPaginator:
    """Deterministic cursor paginator with resumable checkpoint state."""

    fetch: Callable[[dict[str, Any]], Any]
    checkpoint_path: Path
    limit: int = 500
    max_pages: int = 100
    request_budget: int = 100

    def run(self, base_params: dict[str, Any], *, stop_before: Any | None = None) -> list[dict[str, Any]]:
        self.limit = min(500, max(1, int(self.limit)))
        self.checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
        state = json.loads(self.checkpoint_path.read_text(encoding="utf-8")) if self.checkpoint_path.exists() else {}
        cursor = state.get("cursor") or None
        pages = int(state.get("pages", 0))
        requests = int(state.get("requests", 0))
        all_rows: list[dict[str, Any]] = []
        seen_cursors: set[str] = set()
        stop_ts = _utc(stop_before) if stop_before is not None else pd.NaT
        while pages < self.max_pages and requests < self.request_budget:
            params = dict(base_params)
            params["limit"] = self.limit
            if cursor:
                params["cursor"] = cursor
            response = self.fetch(params)
            requests += 1
            payload = getattr(response, "data", response)
            rows = _trade_rows(payload)
            all_rows.extend(rows)
            pages += 1
            next_cursor = _cursor(payload)
            times = pd.to_datetime([x.get("time") for x in rows], unit="ms", utc=True, errors="coerce") if rows else pd.Series(dtype="datetime64[ns, UTC]")
            reached_history = bool(not pd.isna(stop_ts) and len(times) and times.min() <= stop_ts)
            done = not next_cursor or next_cursor in seen_cursors or reached_history
            self.checkpoint_path.write_text(json.dumps({
                "base_params": base_params, "cursor": None if done else next_cursor,
                "pages": pages, "requests": requests, "rows": len(all_rows), "done": done,
                "last_page_rows": len(rows), "oldest_page_time": times.min().isoformat() if len(times) else None,
            }, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
            if done:
                break
            seen_cursors.add(str(cursor)) if cursor else None
            cursor = next_cursor
        return all_rows


def _representative_tokens(root: Path, n: int) -> pd.DataFrame:
    path = root / "data/gold/universe.parquet"
    u = pd.read_parquet(path) if path.exists() else pd.DataFrame()
    if u.empty:
        return u
    u = u.drop_duplicates(["chain", "token_address"]).copy()
    parts = []
    for _, g in u.groupby("chain", sort=True):
        g = g.sort_values(["discovery_rank", "token_address"] if "discovery_rank" in g else ["token_address"])
        take = pd.concat([g.head(2), g.iloc[len(g) // 2:len(g) // 2 + 2], g.tail(2)]).drop_duplicates(["chain", "token_address"])
        parts.append(take)
    out = pd.concat(parts, ignore_index=True).drop_duplicates(["chain", "token_address"])
    return out.head(max(1, int(n)))


def _raw_path(root: Path, params: dict[str, Any], suffix: str = "") -> Path:
    return root / "data/bronze/binance_web3/trades" / f"{_hash(params)}{suffix}.json"


def collect_token_trade_history(root: Path, *, sample_size: int = 24, max_pages_per_token: int = 12, request_budget: int = 240) -> dict[str, Any]:
    """Fetch official cursor pages for a bounded representative sample."""
    settings = Settings.from_env(root, require_credentials=True)
    selected = _representative_tokens(root, sample_size)
    if selected.empty:
        return {"status": "BLOCKED_BY_DATA", "tokens": 0, "pages": 0, "trades": 0}
    all_rows: list[dict[str, Any]] = []
    depth: list[dict[str, Any]] = []
    total_requests = 0
    root_ckpt = root / "artifacts/checkpoints/token_trades"
    with BinanceWeb3Client(settings) as client:
        for _, token in selected.iterrows():
            base = {"binanceChainId": str(token.chain), "tokenContractAddress": str(token.token_address)}
            ckpt = root_ckpt / f"{_hash(base)}.json"
            start = len(client.metrics["latencies_ms"])
            pages_before = json.loads(ckpt.read_text()).get("pages", 0) if ckpt.exists() else 0
            def fetch(params: dict[str, Any]):
                response = client.request("GET", TRADES, params=params)
                # The current service documents max=500 but some tenants return
                # a null data object at 500.  Preserve the documented cursor
                # contract while safely retrying the same page at 100.
                if response.ok and response.data is None and int(params.get("limit", 0)) == 500:
                    fallback = dict(params); fallback["limit"] = 100
                    response = client.request("GET", TRADES, params=fallback)
                    params = fallback
                raw_path = _raw_path(root, params, "_history")
                raw_path.parent.mkdir(parents=True, exist_ok=True)
                if not raw_path.exists():
                    raw_path.write_text(_safe_json({"source": "binance_web3", "endpoint": TRADES, "request_params": params, "observed_at": response.observed_at, "http_status": response.http_status, "business_code": response.business_code, "payload": response.data}) + "\n", encoding="utf-8")
                return response
            paginator = CursorPaginator(fetch, ckpt, limit=500, max_pages=max_pages_per_token, request_budget=max_pages_per_token)
            state_before = json.loads(ckpt.read_text(encoding="utf-8")) if ckpt.exists() else {}
            if state_before.get("done"):
                raw_rows = []
                for raw_path in (root / "data/bronze/binance_web3/trades").glob("*_history.json"):
                    try:
                        doc = json.loads(raw_path.read_text(encoding="utf-8")); params = doc.get("request_params", {})
                        if params.get("binanceChainId") == base["binanceChainId"] and params.get("tokenContractAddress") == base["tokenContractAddress"]:
                            raw_rows.extend(_trade_rows(doc.get("payload", {})))
                    except Exception:
                        continue
                if not raw_rows:
                    state_before["done"] = False
                    state_before["cursor"] = None
                    ckpt.write_text(json.dumps(state_before, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                    paginator.run(base)
                    raw_rows = []
                    for raw_path in (root / "data/bronze/binance_web3/trades").glob("*_history.json"):
                        try:
                            doc = json.loads(raw_path.read_text(encoding="utf-8")); params = doc.get("request_params", {})
                            if params.get("binanceChainId") == base["binanceChainId"] and params.get("tokenContractAddress") == base["tokenContractAddress"]:
                                raw_rows.extend(_trade_rows(doc.get("payload", {})))
                        except Exception:
                            continue
            else:
                paginator.run(base)
                raw_rows = []
                for raw_path in (root / "data/bronze/binance_web3/trades").glob("*_history.json"):
                    try:
                        doc = json.loads(raw_path.read_text(encoding="utf-8")); params = doc.get("request_params", {})
                        if params.get("binanceChainId") == base["binanceChainId"] and params.get("tokenContractAddress") == base["tokenContractAddress"]:
                            raw_rows.extend(_trade_rows(doc.get("payload", {})))
                    except Exception:
                        continue
            state = json.loads(ckpt.read_text(encoding="utf-8")) if ckpt.exists() else {}
            pages = int(state.get("pages", 0))
            total_requests += max(0, pages - int(pages_before))
            normalized = [normalize_web3_trade(item, chain=token.chain, token_address=token.token_address, available_time=pd.Timestamp.now(tz="UTC")) for item in raw_rows]
            all_rows.extend(normalized)
            times = pd.to_datetime([r.get("trade_time") for r in normalized], utc=True, errors="coerce") if normalized else pd.Series(dtype="datetime64[ns, UTC]")
            unique = pd.DataFrame(normalized).drop_duplicates("trade_id") if normalized else pd.DataFrame()
            byte_count = 0
            for p in (root / "data/bronze/binance_web3/trades").glob("*.json"):
                if p.stat().st_mtime >= (pd.Timestamp.now(tz="UTC") - pd.Timedelta(minutes=30)).timestamp():
                    byte_count += p.stat().st_size
            depth.append({
                "chain": str(token.chain), "token_address": str(token.token_address), "symbol": token.get("symbol"),
                "pages": pages, "raw_trades": len(raw_rows), "deduplicated_trades": len(unique),
                "unique_wallets": int(unique["wallet_id"].nunique()) if not unique.empty else 0,
                "oldest_trade": times.min() if len(times) else pd.NaT, "newest_trade": times.max() if len(times) else pd.NaT,
                "history_days": float((times.max() - times.min()).total_seconds() / 86400) if len(times) and times.notna().sum() > 1 else 0.0,
                "duplicates": len(raw_rows) - len(unique), "requests": max(0, pages - int(pages_before)), "bytes_observed": byte_count,
                "checkpoint": str(ckpt.relative_to(root)), "status": "COMPLETED" if state.get("done") else "REQUEST_BUDGET_OR_PAGE_LIMIT",
            })
    merged = pd.DataFrame(all_rows, columns=TRADE_SCHEMA)
    if not merged.empty:
        merged = merged.drop_duplicates("trade_id", keep="first")
        merged.to_parquet(root / "data/gold/trades/fact_wallet_trade.parquet", index=False)
        merged.to_parquet(root / "data/gold/canonical/fact_wallet_trade.parquet", index=False)
    depth_frame = pd.DataFrame(depth)
    depth_frame.to_parquet(root / "artifacts/TOKEN_TRADE_HISTORY_DEPTH.parquet", index=False)
    return {"status": "COMPLETED", "tokens": len(selected), "pages": int(depth_frame["pages"].sum()) if not depth_frame.empty else 0, "raw_trades": int(depth_frame["raw_trades"].sum()) if not depth_frame.empty else 0, "dedup_trades": len(merged), "requests": total_requests, "output": str((root / "artifacts/TOKEN_TRADE_HISTORY_DEPTH.parquet").resolve())}


def rebuild_canonical_from_bronze(root: Path) -> dict[str, Any]:
    """Reparse immutable Bronze payloads with the corrected semantic contract."""
    rows: list[dict[str, Any]] = []
    raw_count = 0
    for path in sorted((root / "data/bronze/binance_web3/trades").glob("*.json")):
        try:
            doc = json.loads(path.read_text(encoding="utf-8")); params = doc.get("request_params", {}); payload = doc.get("payload", {})
            chain, token = params.get("binanceChainId"), params.get("tokenContractAddress")
            for item in _trade_rows(payload):
                raw_count += 1
                rows.append(normalize_web3_trade(item, chain=chain or item.get("binanceChainId"), token_address=token or item.get("tokenContractAddress"), available_time=doc.get("observed_at")))
        except Exception:
            continue
    frame = pd.DataFrame(rows, columns=TRADE_SCHEMA)
    dedup = frame.drop_duplicates("trade_id", keep="first") if not frame.empty else _empty(TRADE_SCHEMA)
    out = root / "data/gold/trades"; out.mkdir(parents=True, exist_ok=True); dedup.to_parquet(out / "fact_wallet_trade.parquet", index=False); dedup.to_parquet(root / "data/gold/canonical/fact_wallet_trade.parquet", index=False)
    return {"raw_rows": raw_count, "dedup_rows": len(dedup), "duplicates": raw_count - len(dedup), "duplicate_identity": "sha256(chain,txHash,wallet,token,side,event_time,token_quantity,paired_token,paired_quantity)"}


def build_history_depth_from_bronze(root: Path) -> dict[str, Any]:
    """Materialize depth even when a long-running collector is interrupted."""
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    files: dict[tuple[str, str], list[Path]] = {}
    for path in sorted((root / "data/bronze/binance_web3/trades").glob("*_history.json")):
        try:
            doc = json.loads(path.read_text(encoding="utf-8")); params = doc.get("request_params", {}); key = (str(params.get("binanceChainId")), str(params.get("tokenContractAddress")))
            rows = _trade_rows(doc.get("payload", {})); grouped.setdefault(key, []).extend([normalize_web3_trade(x, chain=key[0], token_address=key[1], available_time=doc.get("observed_at")) for x in rows]); files.setdefault(key, []).append(path)
        except Exception:
            continue
    rows = []
    for (chain, token), values in grouped.items():
        frame = pd.DataFrame(values, columns=TRADE_SCHEMA); unique = frame.drop_duplicates("trade_id") if not frame.empty else frame; times = _utc(unique["trade_time"]) if not unique.empty else pd.Series(dtype="datetime64[ns, UTC]")
        ckpt = root / "artifacts/checkpoints/token_trades" / f"{_hash({'binanceChainId': chain, 'tokenContractAddress': token})}.json"; state = json.loads(ckpt.read_text(encoding="utf-8")) if ckpt.exists() else {}
        rows.append({"chain": chain, "token_address": token, "pages": len(files[(chain, token)]), "raw_trades": len(frame), "deduplicated_trades": len(unique), "unique_wallets": int(unique.wallet_id.nunique()) if not unique.empty else 0, "oldest_trade": times.min() if len(times) else pd.NaT, "newest_trade": times.max() if len(times) else pd.NaT, "history_days": float((times.max() - times.min()).total_seconds() / 86400) if len(times) and times.notna().sum() > 1 else 0.0, "duplicates": len(frame) - len(unique), "requests": len(files[(chain, token)]), "bytes_observed": sum(p.stat().st_size for p in files[(chain, token)]), "checkpoint": str(ckpt.relative_to(root)) if ckpt.exists() else None, "status": "COMPLETED" if state.get("done") else "PARTIAL_OR_PAGE_LIMIT"})
    out = pd.DataFrame(rows); out.to_parquet(root / "artifacts/TOKEN_TRADE_HISTORY_DEPTH.parquet", index=False)
    return {"tokens": len(out), "pages": int(out.pages.sum()) if not out.empty else 0, "raw_trades": int(out.raw_trades.sum()) if not out.empty else 0, "dedup_trades": int(out.deduplicated_trades.sum()) if not out.empty else 0, "output": str((root / "artifacts/TOKEN_TRADE_HISTORY_DEPTH.parquet").resolve())}


def _classify_response(response: Any) -> str:
    status, code = getattr(response, "http_status", 0), getattr(response, "business_code", None)
    if status in {401, 403} or code in {401, 403}: return "PERMISSION_DENIED"
    if status == 400 or code in {400, 40000, 40001}: return "INVALID_PARAMS"
    if status in {404, 422} or code in {404, 422}: return "UNSUPPORTED_CHAIN"
    if not getattr(response, "ok", False): return "NOT_PROBED"
    data = getattr(response, "data", None)
    return "EMPTY_VALID" if data in (None, [], {}, "") else "ACCESSIBLE"


def _first_trade(root: Path) -> dict[str, Any] | None:
    t = pd.read_parquet(root / "data/gold/trades/fact_wallet_trade.parquet") if (root / "data/gold/trades/fact_wallet_trade.parquet").exists() else pd.DataFrame()
    if t.empty: return None
    row = t.iloc[0]
    return {"chain": str(row.chain), "token": str(row.token_address), "wallet": row.wallet_id, "tx_hash": row.tx_hash}


def probe_participant_endpoints(root: Path, *, wallet_limit: int = 2) -> dict[str, Any]:
    settings = Settings.from_env(root, require_credentials=True); token = _first_trade(root)
    if not token: return {"status": "BLOCKED_BY_DATA", "rows": 0}
    wallet_rows = pd.read_parquet(root / "data/gold/trades/fact_wallet_trade.parquet").dropna(subset=["wallet_id"]).drop_duplicates(["chain", "wallet_id"]).head(wallet_limit)
    probes: list[dict[str, Any]] = []
    calls: list[tuple[str, str, dict[str, Any]]] = [
        ("holders", HOLDER, {"binanceChainId": token["chain"], "tokenContractAddress": token["token"]}),
        ("top_traders", TOP_TRADER, {"binanceChainId": token["chain"], "tokenContractAddress": token["token"]}),
        ("top_liquidity", TOP_LIQUIDITY, {"binanceChainId": token["chain"], "tokenContractAddress": token["token"]}),
        ("leaderboard", LEADERBOARD, {"binanceChainId": token["chain"], "timeFrame": "1", "sortBy": "1", "limit": "20"}),
    ]
    if len(wallet_rows):
        w = wallet_rows.iloc[0]
        calls.extend([
            ("portfolio_overview", PORTFOLIO_OVERVIEW, {"binanceChainId": str(w.chain), "walletAddress": str(w.wallet_id), "timeFrame": "2"}),
            ("recent_pnl", RECENT_PNL, {"binanceChainId": str(w.chain), "walletAddress": str(w.wallet_id), "timeFrame": "2", "limit": "20"}),
            ("token_pnl", TOKEN_PNL, {"binanceChainId": str(w.chain), "walletAddress": str(w.wallet_id), "tokenContractAddress": token["token"], "timeFrame": "2"}),
            ("dex_history", DEX_HISTORY, {"binanceChainId": str(w.chain), "walletAddress": str(w.wallet_id), "limit": "20"}),
            ("tracked_trades", TRACKED_TRADES, {"binanceChainId": str(w.chain), "walletAddress": str(w.wallet_id), "limit": "20"}),
            ("balances", BALANCES, {"address": str(w.wallet_id), "chains": str(w.chain), "excludeRiskToken": "true", "page": "1", "pageSize": "20"}),
            ("address_transactions", ADDRESS_TRANSACTIONS, {"address": str(w.wallet_id), "chains": str(w.chain), "limit": "20"}),
        ])
    with BinanceWeb3Client(settings) as client:
        for name, endpoint, params in calls:
            response = client.request("GET", endpoint, params=params)
            probes.append({"capability": name, "endpoint": endpoint, "method": "GET", "params": _safe_json({k: ("<redacted>" if k.lower() in {"address", "walletaddress"} else v) for k, v in params.items()}), "status": _classify_response(response), "http_status": response.http_status, "business_code": response.business_code, "observed_at": response.observed_at, "data_fields": sorted(response.data[0].keys()) if isinstance(response.data, list) and response.data and isinstance(response.data[0], dict) else sorted(response.data.keys()) if isinstance(response.data, dict) else []})
    out = pd.DataFrame(probes); out.to_parquet(root / "artifacts/PARTICIPANT_ENDPOINT_PROBES.parquet", index=False); return {"status": "COMPLETED", "rows": len(out), "accessible": int(out.status.eq("ACCESSIBLE").sum()), "output": str((root / "artifacts/PARTICIPANT_ENDPOINT_PROBES.parquet").resolve())}


def collect_participant_tags(root: Path, *, token_limit: int = 4) -> pd.DataFrame:
    settings = Settings.from_env(root, require_credentials=True); selected = _representative_tokens(root, token_limit); rows: list[dict[str, Any]] = []; labelled_rows: list[dict[str, Any]] = []
    if selected.empty: return pd.DataFrame()
    with BinanceWeb3Client(settings) as client:
        for _, token in selected.iterrows():
            for tag, label in TAG_NAMES.items():
                params = {"binanceChainId": str(token.chain), "tokenContractAddress": str(token.token_address), "tagFilter": tag, "limit": 100}
                response = client.request("GET", TRADES, params=params); trades = _trade_rows(response.data)
                raw_path = root / "data/bronze/binance_web3/participant_tags" / f"{_hash(params)}.json"; raw_path.parent.mkdir(parents=True, exist_ok=True)
                if not raw_path.exists(): raw_path.write_text(_safe_json({"source": "binance_web3", "endpoint": TRADES, "request_params": params, "observed_at": response.observed_at, "payload": response.data}) + "\n", encoding="utf-8")
                for item in trades:
                    normalized = normalize_web3_trade(item, chain=token.chain, token_address=token.token_address, available_time=response.observed_at)
                    event_time = normalized.get("trade_time"); available_time = normalized.get("available_time")
                    labelled_rows.append({"trade_id": normalized["trade_id"], "wallet_id": normalized["wallet_id"], "chain": str(token.chain), "token_address": str(token.token_address), "external_label": label, "tag_id": tag, "label_available_time": available_time, "event_time": event_time, "is_pit_safe": bool(pd.notna(event_time) and pd.notna(available_time) and available_time <= event_time), "source_endpoint": TRADES})
                wallets = {str(x.get("userAddress")) for x in trades if x.get("userAddress") not in (None, "")}
                times = pd.to_datetime([x.get("time") for x in trades], unit="ms", utc=True, errors="coerce") if trades else pd.Series(dtype="datetime64[ns, UTC]")
                rows.append({"tag_id": tag, "external_label": label, "chain": str(token.chain), "token_address": str(token.token_address), "tokens_with_data": int(bool(trades)), "trades": len(trades), "unique_wallets": len(wallets), "oldest_trade": times.min() if len(times) else pd.NaT, "newest_trade": times.max() if len(times) else pd.NaT, "status": _classify_response(response), "source": "BINANCE_WEB3_TAG_FILTER"})
    out = pd.DataFrame(rows); out.to_parquet(root / "artifacts/participant_tag_coverage.parquet", index=False)
    labels = pd.DataFrame(labelled_rows).drop_duplicates(["trade_id", "external_label"]) if labelled_rows else pd.DataFrame(columns=["trade_id", "wallet_id", "chain", "token_address", "external_label", "tag_id", "label_available_time", "event_time", "is_pit_safe", "source_endpoint"])
    labels.to_parquet(root / "artifacts/participant_trade_labels.parquet", index=False)
    return out


def _response_records(data: Any) -> list[dict[str, Any]]:
    if isinstance(data, list): return [x for x in data if isinstance(x, dict)]
    if isinstance(data, dict):
        for key in ("transactionList", "list", "rows", "data", "holders", "traders", "poolList"):
            if isinstance(data.get(key), list): return [x for x in data[key] if isinstance(x, dict)]
    return []


def append_only_snapshot(prior: pd.DataFrame, current: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    """Merge immutable observations without overwriting prior snapshots."""
    if prior.empty and current.empty:
        return current.copy()
    merged = pd.concat([prior, current], ignore_index=True)
    return merged.drop_duplicates(keys, keep="first")


def parse_pool_snapshot(chain: Any, token_address: Any, record: dict[str, Any], snapshot_time: Any) -> dict[str, Any] | None:
    pool = record.get("poolAddress") or record.get("address") or record.get("pool")
    if not pool:
        return None
    return {"snapshot_time": _utc(snapshot_time), "chain": str(chain), "token_address": str(token_address), "pool_id": f"{chain}:{pool}", "pool_address": pool, "protocol": record.get("protocolName") or record.get("protocol"), "pool_name": record.get("pool"), "liquidity_usd": pd.to_numeric(record.get("liquidityUsd"), errors="coerce"), "liquidity_amount": record.get("liquidityAmount"), "raw_json": _safe_json(record), "source_endpoint": TOP_LIQUIDITY}


def _raw_trade_fields(raw_json: Any) -> dict[str, Any]:
    try:
        raw = json.loads(raw_json) if isinstance(raw_json, str) else (raw_json if isinstance(raw_json, dict) else {})
    except (TypeError, ValueError):
        raw = {}
    legs = raw.get("changedTokenInfo") if isinstance(raw, dict) else None
    return {"changed_token_info": legs if isinstance(legs, list) else [], "raw_dex": raw.get("dexName") if isinstance(raw, dict) else None,
            "raw_pair": raw.get("pair") if isinstance(raw, dict) else None, "raw_tx_hash": raw.get("txHash") if isinstance(raw, dict) else None}


def build_price_semantics_audit(root: Path, *, consistency_low: float = 0.1, consistency_high: float = 10.0) -> dict[str, Any]:
    """Audit the economic meaning of API price before any response analysis."""
    path = root / "data/gold/trades/fact_wallet_trade.parquet"
    trades = pd.read_parquet(path) if path.exists() else pd.DataFrame()
    if trades.empty:
        empty = pd.DataFrame(); empty.to_parquet(root / "artifacts/PRICE_SEMANTICS_AUDIT.parquet", index=False); return {"status": "BLOCKED_BY_DATA", "rows": 0}
    d = trades.copy()
    for col in ("price", "usd_value", "token_quantity"):
        d[col] = pd.to_numeric(d[col], errors="coerce")
    d["api_price"] = d["price"]
    d["implied_price"] = d["usd_value"] / d["token_quantity"].abs().replace(0, np.nan)
    d["price_ratio"] = d["api_price"] / d["implied_price"]
    d["paired_implied_price"] = pd.to_numeric(d.get("paired_token_quantity", np.nan), errors="coerce") / d["token_quantity"].abs().replace(0, np.nan)
    d["api_vs_paired_ratio"] = d["api_price"] / d["paired_implied_price"]
    d["log_price_ratio"] = np.log(d["price_ratio"].where(d["price_ratio"] > 0))
    d["valid_positive_inputs"] = d[["api_price", "usd_value", "token_quantity", "implied_price"]].notna().all(axis=1) & d["api_price"].gt(0) & d["usd_value"].gt(0) & d["token_quantity"].gt(0)
    d["valid_asset_identity"] = d[["chain", "token_address", "asset_id"]].notna().all(axis=1)
    d["price_semantic_consistent"] = d["valid_positive_inputs"] & d["api_vs_paired_ratio"].between(consistency_low, consistency_high, inclusive="both")
    d["validation_status"] = np.where(d["price_semantic_consistent"] & d["valid_asset_identity"], "INCLUDED", "EXCLUDED")
    d["validation_reason"] = np.select([
        ~d["valid_asset_identity"], ~d["valid_positive_inputs"], d["api_vs_paired_ratio"].isna(), d["api_vs_paired_ratio"].lt(consistency_low) | d["api_vs_paired_ratio"].gt(consistency_high)],
        ["INVALID_ASSET_IDENTITY", "NON_POSITIVE_OR_NONFINITE_INPUT", "MISSING_PAIRED_LEG", "API_PRICE_VS_PAIRED_PRICE_MISMATCH"], default="API_PRICE_IS_PAIRED_DENOMINATED__USD_IMPLIED_PRICE_USED")
    audit_cols = ["trade_id", "asset_id", "chain", "token_address", "trade_time", "available_time", "tx_hash", "wallet_id", "side", "api_price", "usd_value", "token_quantity", "implied_price", "paired_token_quantity", "paired_implied_price", "price_ratio", "api_vs_paired_ratio", "log_price_ratio", "validation_status", "validation_reason", "raw_json"]
    for col in audit_cols:
        if col not in d:
            d[col] = np.nan
    d[audit_cols].to_parquet(root / "artifacts/PRICE_SEMANTICS_AUDIT.parquet", index=False)
    rows = []
    for (chain, token), g in d.groupby(["chain", "token_address"], dropna=False):
        ratios = g["price_ratio"].replace([np.inf, -np.inf], np.nan).dropna()
        pair_ratios = g["api_vs_paired_ratio"].replace([np.inf, -np.inf], np.nan).dropna()
        rows.append({"chain": chain, "token_address": token, "n_trades": len(g), "median_api_price": g.api_price.median(), "median_implied_price": g.implied_price.median(), "median_price_ratio": ratios.median(), "q01_price_ratio": ratios.quantile(.01), "q05_price_ratio": ratios.quantile(.05), "q50_price_ratio": ratios.quantile(.50), "q95_price_ratio": ratios.quantile(.95), "q99_price_ratio": ratios.quantile(.99), "median_api_vs_paired_ratio": pair_ratios.median(), "share_api_vs_paired_within_0_8_1_2": float(pair_ratios.between(.8, 1.2).mean()) if len(pair_ratios) else np.nan, "share_within_0_8_1_2": float(ratios.between(.8, 1.2).mean()) if len(ratios) else np.nan, "share_within_0_5_2": float(ratios.between(.5, 2).mean()) if len(ratios) else np.nan, "share_within_0_1_10": float(ratios.between(.1, 10).mean()) if len(ratios) else np.nan, "included_rows": int(g.validation_status.eq("INCLUDED").sum()), "excluded_rows": int(g.validation_status.eq("EXCLUDED").sum())})
    summary = pd.DataFrame(rows); summary.to_parquet(root / "artifacts/PRICE_SEMANTICS_BY_ASSET.parquet", index=False)
    extremes = d.assign(abs_log_ratio=d.log_price_ratio.abs()).sort_values("abs_log_ratio", ascending=False).head(100).copy()
    extreme_cols = [c for c in audit_cols if c in extremes] + ["abs_log_ratio", "valid_positive_inputs", "valid_asset_identity"]
    extremes[extreme_cols].to_parquet(root / "artifacts/PRICE_SEMANTICS_EXTREMES.parquet", index=False)
    md = ["# Price Semantics Audit", "", "The API `price` is compared with `usd_value / abs(token_quantity)` and `paired_token_quantity / abs(token_quantity)`. The observed API field is pair-denominated; the USD-normalized implied price is therefore the research `P_event`.", "", f"- Canonical trades audited: **{len(d)}**", f"- Included by price validation gate: **{int(d.validation_status.eq('INCLUDED').sum())}**", f"- Excluded: **{int(d.validation_status.eq('EXCLUDED').sum())}**", f"- API-vs-paired consistency interval: **[{consistency_low}, {consistency_high}]**", "- External Binance token price/candle reference: **not available at the exact trade timestamps in the persisted sample; no false three-way agreement is claimed.**", "", "## Exclusion reasons", ""]
    for reason, g in d.groupby("validation_reason"):
        md.append(f"- `{reason}`: {len(g)} ({len(g) / len(d):.2%})")
    md.extend(["", "Per-asset quantiles and shares are in `artifacts/PRICE_SEMANTICS_BY_ASSET.parquet`. The 100 most extreme rows are in `artifacts/PRICE_SEMANTICS_EXTREMES.parquet`; raw payloads remain in the row-level `raw_json` field and are not silently discarded."])
    (root / "reports").mkdir(parents=True, exist_ok=True); (root / "reports/PRICE_SEMANTICS_AUDIT.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    return {"status": "COMPLETED", "rows": len(d), "included_rows": int(d.validation_status.eq("INCLUDED").sum()), "excluded_rows": int(d.validation_status.eq("EXCLUDED").sum()), "assets": len(summary), "output": str((root / "artifacts/PRICE_SEMANTICS_AUDIT.parquet").resolve())}


def collect_participant_and_pool_snapshots(root: Path, *, token_limit: int = 4, wallet_limit: int = 20) -> dict[str, Any]:
    settings = Settings.from_env(root, require_credentials=True); selected = _representative_tokens(root, token_limit); now = pd.Timestamp.now(tz="UTC")
    participant_rows: list[dict[str, Any]] = []; pool_rows: list[dict[str, Any]] = []; address_rows: list[dict[str, Any]] = []; tx_rows: list[dict[str, Any]] = []
    trades = pd.read_parquet(root / "data/gold/trades/fact_wallet_trade.parquet") if (root / "data/gold/trades/fact_wallet_trade.parquet").exists() else pd.DataFrame()
    wallets = trades.dropna(subset=["wallet_id"]).drop_duplicates(["chain", "wallet_id"]).head(wallet_limit) if not trades.empty else pd.DataFrame()
    with BinanceWeb3Client(settings) as client:
        for _, token in selected.iterrows():
            token_params = {"binanceChainId": str(token.chain), "tokenContractAddress": str(token.token_address)}
            for name, endpoint in (("holder", HOLDER), ("top_trader", TOP_TRADER)):
                response = client.request("GET", endpoint, params=token_params); records = _response_records(response.data)
                for rank, rec in enumerate(records, 1):
                    participant_rows.append({"snapshot_time": now, "available_time": response.observed_at, "asset_id": f"{token.chain}:{str(token.token_address).lower() if str(token.token_address).startswith('0x') else token.token_address}", "wallet_id": rec.get("holderWalletAddress") or rec.get("walletAddress") or rec.get("address"), "external_label": name, "rank": rank, "holding": rec.get("holdAmount") or rec.get("holdingAmount"), "holding_pct": rec.get("holdingPercent"), "realized_pnl": rec.get("realizedPnlUsd"), "avg_buy_price": rec.get("avgBuyPrice"), "avg_sell_price": rec.get("avgSellPrice"), "funding_source": rec.get("fundingSource"), "source_endpoint": endpoint})
            response = client.request("GET", TOP_LIQUIDITY, params=token_params); records = _response_records(response.data)
            for rec in records:
                pool = rec.get("poolAddress") or rec.get("address") or rec.get("pool")
                if pool:
                    parsed_pool = parse_pool_snapshot(token.chain, token.token_address, rec, now)
                    if parsed_pool:
                        pool_rows.append(parsed_pool)
        for _, wallet in wallets.iterrows():
            params = {"binanceChainId": str(wallet.chain), "walletAddress": str(wallet.wallet_id), "limit": "100"}
            response = client.request("GET", DEX_HISTORY, params=params); records = _response_records(response.data)
            for rec in records: address_rows.append({"available_time": response.observed_at, "chain": str(wallet.chain), "wallet_id": str(wallet.wallet_id), "source_endpoint": DEX_HISTORY, "raw_json": _safe_json(rec)})
            txparams = {"address": str(wallet.wallet_id), "chains": str(wallet.chain), "limit": "100"}
            response = client.request("GET", ADDRESS_TRANSACTIONS, params=txparams); records = _response_records(response.data)
            for rec in records: tx_rows.append({"available_time": response.observed_at, "chain": str(wallet.chain), "wallet_id": str(wallet.wallet_id), "source_endpoint": ADDRESS_TRANSACTIONS, "raw_json": _safe_json(rec)})
    part = pd.DataFrame(participant_rows); pool = pd.DataFrame(pool_rows); address = pd.DataFrame(address_rows); tx = pd.DataFrame(tx_rows)
    for frame, path, keys in ((part, "data/gold/participant/participant_snapshots.parquet", ["snapshot_time", "asset_id", "wallet_id", "external_label"]), (pool, "data/gold/canonical/fact_pool_snapshot.parquet", ["snapshot_time", "pool_id"]), (address, "data/gold/participant/address_dex_history.parquet", ["available_time", "chain", "wallet_id", "raw_json"]), (tx, "data/gold/participant/address_transactions.parquet", ["available_time", "chain", "wallet_id", "raw_json"])):
        p = root / path; p.parent.mkdir(parents=True, exist_ok=True); prior = pd.read_parquet(p) if p.exists() else pd.DataFrame(); merged = append_only_snapshot(prior, frame, keys); merged.to_parquet(p, index=False)
    if not pool.empty:
        pool.drop_duplicates(["pool_id", "chain", "token_address"])[["pool_id", "chain", "pool_address", "protocol", "pool_name"]].to_parquet(root / "data/gold/canonical/dim_pool.parquet", index=False)
    return {"participant_snapshot_rows": len(part), "pool_snapshot_rows": len(pool), "address_history_rows": len(address), "address_transaction_rows": len(tx), "pool_count": int(pool["pool_id"].nunique()) if not pool.empty else 0}


def _clock_grid(trades: pd.DataFrame, freq: str) -> pd.DataFrame:
    if trades.empty: return pd.DataFrame(columns=["asset_id", "timestamp", "bar_timestamp", "source_trade_timestamp", "price", "source"])
    rows = []
    for asset, g in trades.dropna(subset=["trade_time", "price"]).groupby("asset_id"):
        g = g.sort_values("trade_time").copy(); g["bar_timestamp"] = g["trade_time"].dt.floor(freq)
        for bar_ts, bucket in g.groupby("bar_timestamp", sort=True):
            source = bucket.iloc[-1]
            rows.append({"asset_id": asset, "timestamp": bar_ts, "bar_timestamp": bar_ts, "source_trade_timestamp": source.trade_time, "price": float(source.price), "source": "TRADE_DERIVED_CLOCK_GRID"})
    return pd.DataFrame(rows)


def _nearest(grid: pd.DataFrame, target: pd.Timestamp, tolerance: pd.Timedelta) -> tuple[float, pd.Timestamp] | tuple[float, pd.NaT]:
    if grid.empty: return np.nan, pd.NaT
    # Arrow/pandas may store timezone timestamps at microsecond resolution;
    # normalize both sides through Timestamp.value (nanoseconds) explicitly.
    source_col = "source_trade_timestamp" if "source_trade_timestamp" in grid.columns else "timestamp"
    normalized = pd.to_datetime(grid[source_col], utc=True)
    times = np.asarray([pd.Timestamp(value).value for value in normalized], dtype="int64")
    target_ns = pd.Timestamp(target).value; pos = int(np.searchsorted(times, target_ns, side="left"))
    candidates = [x for x in (pos - 1, pos) if 0 <= x < len(times)]
    if not candidates: return np.nan, pd.NaT
    idx = min(candidates, key=lambda x: abs(int(times[x]) - target_ns)); delta = abs(pd.Timedelta(int(times[idx] - target_ns), unit="ns"))
    return (float(grid.iloc[idx]["price"]), normalized.iloc[idx]) if delta <= tolerance else (np.nan, pd.NaT)


def _episodes(times: pd.Series, cooldown: pd.Timedelta = pd.Timedelta(minutes=5)) -> pd.Series:
    ordered = times.sort_values(); flags = ordered.diff().gt(cooldown).fillna(True); ids = flags.cumsum(); return ids.reindex(times.index)


def _cluster_bootstrap(values: pd.DataFrame, value_col: str, cluster_col: str, seed: int = 42, n_boot: int = 1000) -> tuple[float, float]:
    """Cluster bootstrap of the mean, giving each independent cluster equal weight."""
    d = values.dropna(subset=[value_col, cluster_col]).copy()
    if d.empty:
        return np.nan, np.nan
    d = d.groupby(cluster_col, as_index=False)[value_col].mean()
    clusters = d[cluster_col].drop_duplicates().tolist()
    if len(clusters) < 2: return np.nan, np.nan
    rng = np.random.default_rng(seed); means = []
    for _ in range(n_boot):
        picked = rng.choice(clusters, size=len(clusters), replace=True); means.append(float(d.set_index(cluster_col).loc[picked, value_col].mean()))
    return float(np.quantile(means, .025)), float(np.quantile(means, .975))


def _cluster_inference(values: pd.DataFrame, value_col: str, cluster_col: str, *, seed: int = 42) -> dict[str, Any]:
    """Effect, cluster-balanced CI and a transparent cluster-level t test."""
    d = values.dropna(subset=[value_col, cluster_col]).copy()
    if d.empty:
        return {"n_observations": 0, "n_clusters": 0, "effect_size": np.nan, "ci_low": np.nan, "ci_high": np.nan, "raw_p_value": np.nan, "inference": "INSUFFICIENT_EVIDENCE"}
    cluster_means = d.groupby(cluster_col)[value_col].mean().dropna()
    effect = float(cluster_means.mean())
    lo, hi = _cluster_bootstrap(d, value_col, cluster_col, seed=seed)
    p = float(ttest_1samp(cluster_means.to_numpy(), 0.0).pvalue) if len(cluster_means) >= 2 else np.nan
    return {"n_observations": int(len(d)), "n_clusters": int(len(cluster_means)), "effect_size": effect, "ci_low": lo, "ci_high": hi, "raw_p_value": p, "inference": "equal-weight cluster means; two-sided one-sample t approximation with cluster bootstrap CI"}


def run_clock_microstructure(root: Path, *, tolerance_seconds: int = 30) -> dict[str, Any]:
    """Run the frozen trade-response program on clock-time matched prices.

    The event price is the target trade's own execution price.  A clock grid is
    used only for future targets; it is never substituted for the event price.
    Episode clusters are horizon-specific so a 60-minute result is not inferred
    with a five-minute dependence assumption.
    """
    path = root / "data/gold/trades/fact_wallet_trade.parquet"; trades = pd.read_parquet(path) if path.exists() else pd.DataFrame()
    if trades.empty:
        return {"status": "BLOCKED_BY_DATA", "impact_rows": 0, "episodes": 0}
    validation = build_price_semantics_audit(root)
    gate = pd.read_parquet(root / "artifacts/PRICE_SEMANTICS_AUDIT.parquet")
    trades = trades.merge(gate[["trade_id", "validation_status", "validation_reason", "price_ratio", "implied_price"]], on="trade_id", how="left")
    trades = trades[trades.validation_status.eq("INCLUDED")].copy()
    if trades.empty:
        return {"status": "BLOCKED_BY_PRICE_VALIDATION", "impact_rows": 0, "episodes": 0, "price_validation": validation}
    trades["trade_time"] = _utc(trades["trade_time"])
    for col in ("price", "usd_value", "side_sign", "implied_price"):
        trades[col] = pd.to_numeric(trades[col], errors="coerce")
    trades["api_price"] = trades["price"]
    trades["price"] = trades["implied_price"]
    trades = trades.dropna(subset=["asset_id", "trade_time", "price", "side_sign"])
    grid1 = _clock_grid(trades, "1min"); grid5 = _clock_grid(trades, "5min")
    grid1.to_parquet(root / "artifacts/dex_price_grid_1m.parquet", index=False); grid5.to_parquet(root / "artifacts/dex_price_grid_5m.parquet", index=False)
    horizons = (1, 5, 15, 60); records: list[dict[str, Any]] = []; tol = pd.Timedelta(seconds=tolerance_seconds)
    for asset, g in trades.groupby("asset_id"):
        gg = grid1[grid1.asset_id == asset].sort_values("timestamp")
        if gg.empty:
            continue
        g = g.sort_values("trade_time").copy()
        for h in horizons:
            g[f"episode_id_{h}m"] = f"{asset}:h{h}:" + _episodes(g["trade_time"], pd.Timedelta(minutes=h)).astype(str)
        # Kept as a compatibility field; inference below always selects h-specific clusters.
        g["episode_id"] = g["episode_id_5m"]
        for _, r in g.iterrows():
            t0 = r.trade_time.floor("min")
            pre, pre_t = _nearest(gg, t0 - pd.Timedelta(minutes=1), tol)
            immediate, imm_t = _nearest(gg, t0, tol)
            rec = {"trade_id": r.trade_id, "wallet_id": r.wallet_id, "episode_id": r.episode_id, "asset_id": asset, "chain": r.chain,
                   "token_address": r.token_address, "trade_time": r.trade_time, "grid_time": t0,
                   "side": r.side, "direction": r.side_sign, "trade_price": float(r.price), "api_price": float(r.api_price),
                   "usd_value": r.usd_value, "implied_price": r.implied_price, "price_ratio": r.price_ratio,
                   "price_validation_status": r.validation_status, "price_validation_reason": r.validation_reason,
                   "log1p_usd_value": math.log1p(r.usd_value) if pd.notna(r.usd_value) and r.usd_value >= 0 else np.nan,
                   "pre_trade_price": pre, "pre_trade_grid_time": pre_t, "immediate_post_trade_price": immediate,
                   "immediate_grid_time": imm_t, "source_status": "IMPACT_APPROXIMATION"}
            for h in horizons:
                rec[f"episode_id_{h}m"] = r[f"episode_id_{h}m"]
            rec["immediate_impact"] = immediate / r.price - 1 if pd.notna(immediate) and r.price > 0 else np.nan
            for h in horizons:
                target_time = r.trade_time + pd.Timedelta(minutes=h)
                future, future_t = _nearest(gg, target_time, tol)
                # Signed response is anchored to the target trade execution price.
                signed = r.side_sign * (future / r.price - 1) if pd.notna(future) and r.price > 0 else np.nan
                rec[f"target_price_{h}m"] = future
                rec[f"target_source_timestamp_{h}m"] = future_t
                rec[f"impact_{h}m"] = future / r.price - 1 if pd.notna(future) and r.price > 0 else np.nan
                rec[f"post_trade_response_{h}m"] = future / immediate - 1 if pd.notna(immediate) and pd.notna(future) and immediate > 0 else np.nan
                rec[f"signed_response_{h}m"] = signed
                rec[f"signed_log_response_{h}m"] = r.side_sign * math.log(future / r.price) if pd.notna(future) and future > 0 and r.price > 0 else np.nan
                rec[f"actual_horizon_seconds_{h}m"] = (future_t - r.trade_time).total_seconds() if pd.notna(future_t) else np.nan
                rec[f"match_delay_seconds_{h}m"] = (future_t - target_time).total_seconds() if pd.notna(future_t) else np.nan
            records.append(rec)
    impacts = pd.DataFrame(records)
    impacts.to_parquet(root / "artifacts/price_impact_results.parquet", index=False)
    summaries: list[dict[str, Any]] = []
    for h in horizons:
        col = f"signed_response_{h}m"; cluster = f"episode_id_{h}m"
        d = impacts.dropna(subset=[col, cluster]) if not impacts.empty else pd.DataFrame()
        inf = _cluster_inference(d, col, cluster)
        if not d.empty:
            block_unit = "h" if h <= 5 else "D"
            d["asset_time_block"] = d.asset_id.astype(str) + ":" + d.trade_time.dt.floor(block_unit).astype(str)
            block_inf = _cluster_inference(d, col, "asset_time_block")
        else:
            block_inf = {"n_clusters": 0, "ci_low": np.nan, "ci_high": np.nan, "raw_p_value": np.nan}
        immediate = impacts["immediate_impact"].dropna() if not impacts.empty else pd.Series(dtype=float)
        future_impact = impacts[f"impact_{h}m"].dropna() if not impacts.empty else pd.Series(dtype=float)
        immediate_mean = float(immediate.mean()) if len(immediate) else np.nan
        future_mean = float(future_impact.mean()) if len(future_impact) else np.nan
        trimmed = d[col].clip(d[col].quantile(.01), d[col].quantile(.99)) if len(d) >= 10 else d[col]
        log_col = f"signed_log_response_{h}m"
        summaries.append({"research_id": "R1_SIGNED_TRADE_RESPONSE", "horizon": f"{h}m", **inf,
                          "n_trades": int(len(d)), "independent_episodes": int(d[cluster].nunique()) if not d.empty else 0,
                          "mean": inf["effect_size"], "median": float(d[col].median()) if not d.empty else np.nan,
                          "trimmed_mean_1pct": float(trimmed.mean()) if len(trimmed) else np.nan,
                          "signed_log_mean": float(d[log_col].mean()) if log_col in d and d[log_col].notna().any() else np.nan,
                          "q01": float(d[col].quantile(.01)) if not d.empty else np.nan, "q25": float(d[col].quantile(.25)) if not d.empty else np.nan,
                          "q75": float(d[col].quantile(.75)) if not d.empty else np.nan, "q99": float(d[col].quantile(.99)) if not d.empty else np.nan,
                          "distribution_skew": float(d[col].skew()) if len(d) >= 3 else np.nan,
                          "hit_rate": float((d[col] > 0).mean()) if not d.empty else np.nan,
                          "asset_time_block": "asset×hour" if h <= 5 else "asset×day", "block_n_clusters": block_inf["n_clusters"], "block_ci_low": block_inf["ci_low"], "block_ci_high": block_inf["ci_high"], "block_p_value": block_inf["raw_p_value"],
                          "immediate_impact_mean": immediate_mean, "impact_mean": future_mean,
                          "impact_retention": float(future_mean / immediate_mean) if pd.notna(immediate_mean) and immediate_mean != 0 and pd.notna(future_mean) else np.nan,
                          "inference": f"horizon-specific cluster bootstrap and cluster-level t test; cooldown={h}m",
                          "status": "EXPLORATORY" if len(d) else "INSUFFICIENT_EVIDENCE"})
    summary = pd.DataFrame(summaries)
    (root / "reports").mkdir(parents=True, exist_ok=True)
    summary.to_parquet(root / "artifacts/microstructure_inference.parquet", index=False)
    summary.to_parquet(root / "artifacts/response_curve_results.parquet", index=False)
    summary.to_csv(root / "reports/phase5_microstructure.csv", index=False)
    outlier_root_cause = build_price_outlier_root_cause(root, impacts)
    flow = trades.assign(timestamp=trades.trade_time.dt.floor("1min"), buy_flow=trades.usd_value.where(trades.side.eq("buy"), 0.0), sell_flow=trades.usd_value.where(trades.side.eq("sell"), 0.0)).groupby(["asset_id", "chain", "token_address", "timestamp"], as_index=False).agg(buy_flow=("buy_flow", "sum"), sell_flow=("sell_flow", "sum"), trade_count=("trade_id", "nunique"), active_wallets=("wallet_id", "nunique"))
    flow["net_flow"] = flow.buy_flow - flow.sell_flow; flow["volume_imbalance"] = flow.net_flow / (flow.buy_flow + flow.sell_flow).replace(0, np.nan)
    flow.to_parquet(root / "artifacts/trade_flow_observables.parquet", index=False)
    flow_results = _build_flow_results(flow, grid1, tol)
    flow_results.to_parquet(root / "artifacts/flow_response_results.parquet", index=False)
    size_results = _build_size_results(impacts)
    size_results.to_parquet(root / "artifacts/trade_size_results.parquet", index=False)
    return {"status": "IMPACT_APPROXIMATION", "impact_rows": len(impacts), "episodes": int(impacts.episode_id.nunique()) if not impacts.empty else 0, "grid_1m_rows": len(grid1), "grid_5m_rows": len(grid5), "summary_rows": len(summary), "flow_rows": len(flow_results), "size_rows": len(size_results), "price_validation": validation, "outlier_root_cause_rows": len(outlier_root_cause)}


def _build_size_results(impacts: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    if impacts.empty:
        return pd.DataFrame()
    d = impacts.dropna(subset=["log1p_usd_value"])
    for h in (1, 5, 15, 60):
        target = f"signed_response_{h}m"; sub = d.dropna(subset=[target]).copy()
        if sub.empty:
            continue
        sub["size_quantile"] = pd.qcut(sub["usd_value"].rank(method="first"), min(5, max(1, sub["usd_value"].nunique())), labels=False, duplicates="drop") + 1
        for q, g in sub.groupby("size_quantile"):
            inf = _cluster_inference(g, target, f"episode_id_{h}m")
            rows.append({"research_id": "R2_TRADE_SIZE_RESPONSE", "method": "size_quantile", "horizon": f"{h}m", "quantile": int(q), **inf, "status": "EXPLORATORY" if inf["n_clusters"] >= 5 else "INSUFFICIENT_SAMPLE"})
        reg = sub.dropna(subset=["log1p_usd_value", target])
        if len(reg) >= 3:
            # Regression is on episode-balanced observations, avoiding a busy episode dominating beta.
            reg = reg.groupby(f"episode_id_{h}m", as_index=False)[["log1p_usd_value", target]].mean()
            fit = linregress(reg["log1p_usd_value"], reg[target]) if len(reg) >= 3 and reg["log1p_usd_value"].nunique() > 1 else None
            rows.append({"research_id": "R2_TRADE_SIZE_RESPONSE", "method": "episode_balanced_regression", "horizon": f"{h}m", "quantile": np.nan, "n_observations": len(sub), "n_clusters": len(reg), "effect_size": float(fit.slope) if fit else np.nan, "ci_low": float(fit.slope - 1.96 * fit.stderr) if fit and np.isfinite(fit.stderr) else np.nan, "ci_high": float(fit.slope + 1.96 * fit.stderr) if fit and np.isfinite(fit.stderr) else np.nan, "raw_p_value": float(fit.pvalue) if fit else np.nan, "inference": "episode-balanced OLS slope; exploratory", "status": "EXPLORATORY" if fit else "INSUFFICIENT_EVIDENCE"})
        # Pre-specified matched comparison: top decile versus middle-size trades,
        # same asset and UTC day, nearest available event time.
        sub["size_rank"] = sub["usd_value"].rank(pct=True, method="first")
        top = sub[sub.size_rank >= .90]; middle = sub[sub.size_rank.between(.40, .60)]
        matched = []
        if not top.empty and not middle.empty:
            middle = middle.assign(event_day=pd.to_datetime(middle.trade_time, utc=True).dt.date)
            for _, top_row in top.iterrows():
                day = pd.Timestamp(top_row.trade_time).date(); candidates = middle[(middle.asset_id == top_row.asset_id) & (middle.event_day == day)]
                if candidates.empty: continue
                pick = candidates.iloc[(pd.to_datetime(candidates.trade_time, utc=True) - pd.Timestamp(top_row.trade_time)).abs().argmin()]
                matched.append({"difference": float(top_row[target] - pick[target]), "episode_id": top_row[f"episode_id_{h}m"]})
        if matched:
            m = pd.DataFrame(matched); inf = _cluster_inference(m, "difference", "episode_id")
            rows.append({"research_id": "R2_TRADE_SIZE_RESPONSE", "method": "top_decile_vs_middle_matched", "horizon": f"{h}m", "quantile": np.nan, **inf, "status": "EXPLORATORY"})
    return pd.DataFrame(rows)


def build_price_outlier_root_cause(root: Path, impacts: pd.DataFrame) -> pd.DataFrame:
    """Trace return and semantic outliers without silently classifying them as alpha."""
    trade_path = root / "data/gold/trades/fact_wallet_trade.parquet"; trades = pd.read_parquet(trade_path) if trade_path.exists() else pd.DataFrame()
    if trades.empty:
        out = pd.DataFrame(); out.to_parquet(root / "artifacts/PRICE_OUTLIER_ROOT_CAUSE.parquet", index=False); return out
    sem = pd.read_parquet(root / "artifacts/PRICE_SEMANTICS_AUDIT.parquet") if (root / "artifacts/PRICE_SEMANTICS_AUDIT.parquet").exists() else pd.DataFrame()
    merged = trades.merge(sem[["trade_id", "api_price", "implied_price", "price_ratio", "api_vs_paired_ratio", "validation_status", "validation_reason"]], on="trade_id", how="left")
    impact_cols = [c for c in impacts.columns if c.startswith("signed_response_") or c.startswith("target_price_") or c.startswith("target_source_timestamp_")]
    if not impacts.empty:
        impact_keep = [c for c in ["trade_id", "trade_price", *impact_cols] if c in impacts.columns]
        merged = merged.merge(impacts[impact_keep], on="trade_id", how="left")
    response_cols = [c for c in merged.columns if c.startswith("signed_response_")]
    extreme_flags = merged[response_cols].abs().gt(.5).any(axis=1) if response_cols else pd.Series(False, index=merged.index)
    ratio_flags = merged.api_vs_paired_ratio.lt(.1) | merged.api_vs_paired_ratio.gt(10) | ~np.isfinite(merged.api_vs_paired_ratio)
    out = merged[extreme_flags | ratio_flags].copy()
    if out.empty:
        out = pd.DataFrame(columns=["trade_id", "root_cause_class"])
    def classify(row: pd.Series) -> str:
        if pd.isna(row.get("asset_id")) or pd.isna(row.get("chain")) or pd.isna(row.get("token_address")): return "D_TOKEN_IDENTITY_PROBLEM"
        if pd.isna(row.get("token_quantity")) or row.get("token_quantity", 0) <= 0 or pd.isna(row.get("usd_value")) or row.get("usd_value", 0) <= 0: return "C_TOKEN_AMOUNT_OR_DECIMALS"
        raw = _raw_trade_fields(row.get("raw_json")); legs = raw.get("changed_token_info") or []
        if not legs: return "B_WRONG_OR_MISSING_QUERIED_TOKEN_LEG"
        if pd.notna(row.get("api_vs_paired_ratio")) and (row.get("api_vs_paired_ratio") < .1 or row.get("api_vs_paired_ratio") > 10): return "A_API_PRICE_VS_PAIRED_PRICE_MISMATCH"
        return "H_UNKNOWN_REQUIRES_INDEPENDENT_QUOTE"
    if not out.empty:
        out["root_cause_class"] = out.apply(classify, axis=1)
        out["outlier_horizons"] = out.apply(lambda r: ",".join(c.replace("signed_response_", "") for c in response_cols if pd.notna(r.get(c)) and abs(float(r.get(c))) > .5), axis=1)
        out["changedTokenInfo"] = out.raw_json.map(lambda x: _raw_trade_fields(x)["changed_token_info"])
        out["paired_token"] = out.raw_json.map(lambda x: _raw_trade_fields(x).get("raw_pair"))
        out["raw_dex"] = out.raw_json.map(lambda x: _raw_trade_fields(x).get("raw_dex"))
        out["raw_source"] = out.source
        keep = ["trade_id", "chain", "token_address", "tx_hash", "wallet_id", "side", "trade_time", "price", "api_price", "trade_price", "usd_value", "token_quantity", "implied_price", "paired_implied_price", "price_ratio", "api_vs_paired_ratio", "validation_status", "validation_reason", "outlier_horizons", "root_cause_class", "changedTokenInfo", "paired_token", "raw_dex", "raw_source", "raw_json"] + impact_cols
        out = out[[c for c in keep if c in out.columns]]
    out.to_parquet(root / "artifacts/PRICE_OUTLIER_ROOT_CAUSE.parquet", index=False)
    counts = out["root_cause_class"].value_counts(dropna=False) if not out.empty else pd.Series(dtype=int)
    lines = ["# Price Outlier Root-Cause Analysis", "", f"Outlier rows: **{len(out)}**. A row is included if any <=60m signed response has absolute simple return above 50%, or its API-vs-paired-leg ratio is outside [0.1, 10]. The API-vs-USD ratio is not itself an error because API price is pair-denominated.", "", "| Root-cause class | Count | Share |", "|---|---:|---:|"]
    for name, count in counts.items(): lines.append(f"| `{name}` | {int(count)} | {count / len(out):.2%} |" if len(out) else f"| `{name}` | {int(count)} | 0% |")
    lines.extend(["", "Classification is conservative: rows requiring an independent Binance Web3 price/candle at the exact trade timestamp remain `H_UNKNOWN_REQUIRES_INDEPENDENT_QUOTE`; they are not relabelled as true market moves."])
    (root / "reports/PRICE_OUTLIER_ROOT_CAUSE.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out


def _build_flow_results(flow: pd.DataFrame, grid: pd.DataFrame, tolerance: pd.Timedelta) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    if flow.empty:
        return pd.DataFrame()
    for asset, group in flow.groupby("asset_id"):
        gg = grid[grid.asset_id == asset].sort_values("timestamp")
        if gg.empty:
            continue
        group = group.sort_values("timestamp").copy()
        for window in (1, 5, 15):
            idx = group.set_index("timestamp")
            for col in ("buy_flow", "sell_flow", "net_flow"):
                idx[f"{col}_{window}m"] = idx[col].rolling(f"{window}min", min_periods=1).sum()
            idx[f"ofi_{window}m"] = idx[f"net_flow_{window}m"] / (idx[f"buy_flow_{window}m"] + idx[f"sell_flow_{window}m"]).replace(0, np.nan)
            group = idx.reset_index()
            for h in (1, 5, 15, 60):
                values = []
                for _, row in group.iterrows():
                    pre, pre_t = _nearest(gg, row.timestamp - pd.Timedelta(minutes=5), tolerance); p0, p0_t = _nearest(gg, row.timestamp, tolerance); future, future_t = _nearest(gg, row.timestamp + pd.Timedelta(minutes=h), tolerance)
                    if pd.notna(p0) and pd.notna(future) and p0 > 0:
                        values.append({"asset_id": asset, "chain": row.chain, "token_address": row.token_address, "timestamp": row.timestamp, "window_minutes": window, "horizon_minutes": h, "ofi": row[f"ofi_{window}m"], "signed_dollar_flow": row[f"net_flow_{window}m"], "pre_event_return_5m": p0 / pre - 1 if pd.notna(pre) and pre > 0 else np.nan, "contemporaneous_return": p0 / pre - 1 if pd.notna(pre) and pre > 0 else np.nan, "forward_return": future / p0 - 1, "actual_horizon_seconds": (future_t - row.timestamp).total_seconds(), "source_price_timestamp": p0_t, "future_source_timestamp": future_t, "source_status": "TRADE_DERIVED_CLOCK_GRID"})
                if values:
                    out = pd.DataFrame(values).dropna(subset=["ofi", "forward_return"])
                    if not out.empty:
                        out["episode_id"] = f"{asset}:flow{window}:h{h}:" + _episodes(out["timestamp"], pd.Timedelta(minutes=h)).astype(str)
                        for _, x in out.iterrows():
                            rows.append({"research_id": "R3_FLOW_IMBALANCE_RESPONSE", "method": "flow_window", "window_minutes": window, "horizon": f"{h}m", "ofi": x.ofi, "signed_dollar_flow": x.signed_dollar_flow, "pre_event_return_5m": x.pre_event_return_5m, "contemporaneous_return": x.contemporaneous_return, "forward_return": x.forward_return, "asset_id": x.asset_id, "chain": x.chain, "token_address": x.token_address, "timestamp": x.timestamp, "episode_id": x.episode_id, "actual_horizon_seconds": x.actual_horizon_seconds, "source_price_timestamp": x.source_price_timestamp, "future_source_timestamp": x.future_source_timestamp, "source_status": x.source_status})
    return pd.DataFrame(rows)


def _response_inference(impacts: pd.DataFrame, horizon: int) -> dict[str, Any]:
    col = f"signed_response_{horizon}m"; cluster = f"episode_id_{horizon}m"
    return _cluster_inference(impacts, col, cluster) if col in impacts else {"n_observations": 0, "n_clusters": 0, "effect_size": np.nan, "ci_low": np.nan, "ci_high": np.nan, "raw_p_value": np.nan, "inference": "INSUFFICIENT_EVIDENCE"}


def _build_participant_label_results(root: Path, impacts: pd.DataFrame) -> pd.DataFrame:
    """Validate labels without treating a coverage table as labelled trades."""
    path = root / "artifacts/participant_tag_coverage.parquet"
    tags = pd.read_parquet(path) if path.exists() else pd.DataFrame()
    labels = list(TAG_NAMES.values())
    label_path = root / "artifacts/participant_trade_labels.parquet"
    trade_labels = pd.read_parquet(label_path) if label_path.exists() else pd.DataFrame()
    rows = []
    for label in labels:
        d = tags[tags.external_label.eq(label)] if not tags.empty and "external_label" in tags else pd.DataFrame()
        n_trades = int(pd.to_numeric(d.get("trades", pd.Series(dtype=float)), errors="coerce").fillna(0).sum()) if not d.empty else 0
        joined = impacts.merge(trade_labels[trade_labels.external_label.eq(label)], on="trade_id", how="inner") if not impacts.empty and not trade_labels.empty else pd.DataFrame()
        pit_joined = joined[joined.is_pit_safe.eq(True)] if not joined.empty and "is_pit_safe" in joined else pd.DataFrame()
        rows.append({"research_id": "RQ5_RQ7_EXTERNAL_LABEL_VALIDATION", "participant_type": label, "n_trades": n_trades, "n_wallets": int(pd.to_numeric(d.get("unique_wallets", pd.Series(dtype=float)), errors="coerce").fillna(0).sum()) if not d.empty else 0, "n_tokens": int(d.loc[d.get("trades", pd.Series(dtype=float)).fillna(0).gt(0), "token_address"].nunique()) if not d.empty and "token_address" in d else 0, "label_join_rows": len(joined), "pit_safe_join_rows": len(pit_joined), "effect_size": np.nan, "ci_low": np.nan, "ci_high": np.nan, "raw_p_value": np.nan, "response_linkage": "CURRENT_FORWARD_LABEL_ONLY" if len(joined) and not len(pit_joined) else ("PIT_SAFE" if len(pit_joined) else "NOT_AVAILABLE"), "status": "CURRENT/FORWARD LABEL ONLY" if len(joined) and not len(pit_joined) else "INSUFFICIENT_SAMPLE", "limitation": "Historical labels known after event time are not used as historical features; matched label inference waits for forward observations with label_available_time <= event_time."})
    out = pd.DataFrame(rows); out.to_parquet(root / "artifacts/participant_label_results.parquet", index=False); return out


def _build_wallet_persistence_results(root: Path, impacts: pd.DataFrame) -> pd.DataFrame:
    if impacts.empty or "wallet_id" not in impacts:
        out = pd.DataFrame([{"research_id": "RQ9_WALLET_PERSISTENCE", "status": "INSUFFICIENT_SAMPLE", "reason": "no wallet-linked response rows"}]); out.to_parquet(root / "artifacts/wallet_persistence_results.parquet", index=False); return out
    d = impacts.dropna(subset=["wallet_id", "trade_time", "signed_response_5m"]).copy().sort_values(["wallet_id", "trade_time"])
    d["trade_order"] = d.groupby("wallet_id").cumcount() + 1
    eligible = d.groupby("wallet_id").size(); eligible = eligible[eligible >= 5].index
    d = d[d.wallet_id.isin(eligible)].copy()
    rows = []
    for wallet, g in d.groupby("wallet_id"):
        cut = max(1, int(np.floor(len(g) * .6))); hist = g.iloc[:cut]["signed_response_5m"].mean(); future = g.iloc[cut:]["signed_response_5m"].mean()
        if len(g.iloc[cut:]) == 0: continue
        rows.append({"wallet_id": wallet, "historical_response": hist, "future_response": future, "historical_n": cut, "future_n": len(g) - cut})
    w = pd.DataFrame(rows)
    if len(w) >= 3:
        corr = float(w["historical_response"].corr(w["future_response"], method="spearman"))
        fit = linregress(w["historical_response"], w["future_response"]) if w["historical_response"].nunique() > 1 else None
        result = {"research_id": "RQ9_WALLET_PERSISTENCE", "n_wallets": len(w), "effect_size": corr, "slope": float(fit.slope) if fit else np.nan, "raw_p_value": float(fit.pvalue) if fit else np.nan, "ci_low": np.nan, "ci_high": np.nan, "chronological_split": "first 60% versus last 40%", "status": "EXPLORATORY"}
    else:
        result = {"research_id": "RQ9_WALLET_PERSISTENCE", "n_wallets": len(w), "effect_size": np.nan, "slope": np.nan, "raw_p_value": np.nan, "ci_low": np.nan, "ci_high": np.nan, "chronological_split": "first 60% versus last 40%", "status": "INSUFFICIENT_SAMPLE"}
    out = pd.DataFrame([result]); out.to_parquet(root / "artifacts/wallet_persistence_results.parquet", index=False); return out


def _build_crowding_results(root: Path, trades: pd.DataFrame, grid: pd.DataFrame, tolerance: pd.Timedelta) -> pd.DataFrame:
    if trades.empty:
        out = pd.DataFrame([{"research_id": "RQ10_RQ11_CROWDING", "status": "INSUFFICIENT_SAMPLE"}]); out.to_parquet(root / "artifacts/crowding_results.parquet", index=False); return out
    d = trades.dropna(subset=["wallet_id", "trade_time"]).copy(); d["timestamp"] = d.trade_time.dt.floor("1min")
    first = d.groupby(["asset_id", "wallet_id"])["timestamp"].min().rename("first_wallet_time").reset_index(); d = d.merge(first, on=["asset_id", "wallet_id"], how="left"); d["new_wallet"] = d.timestamp.eq(d.first_wallet_time)
    rows = []
    for (asset, ts), g in d.groupby(["asset_id", "timestamp"]):
        gg = grid[grid.asset_id.eq(asset)].sort_values("timestamp"); p0, _ = _nearest(gg, ts, tolerance); future, future_t = _nearest(gg, ts + pd.Timedelta(minutes=15), tolerance)
        if pd.isna(p0) or pd.isna(future) or p0 <= 0: continue
        buyer_counts = g.loc[g.side.eq("buy")].groupby("wallet_id").size(); shares = (buyer_counts / buyer_counts.sum()) if len(buyer_counts) else pd.Series(dtype=float)
        rows.append({"research_id": "RQ10_RQ11_CROWDING", "asset_id": asset, "timestamp": ts, "unique_wallets": g.wallet_id.nunique(), "new_wallet_share": float(g.new_wallet.mean()), "buyer_hhi": float((shares ** 2).sum()) if len(shares) else np.nan, "trade_count": len(g), "forward_return_15m": future / p0 - 1, "actual_horizon_seconds": (future_t - ts).total_seconds()})
    out = pd.DataFrame(rows)
    if not out.empty:
        out["crowding_episode"] = out.asset_id.astype(str) + ":" + _episodes(out.timestamp, pd.Timedelta(minutes=15)).astype(str)
        inf = _cluster_inference(out.dropna(subset=["forward_return_15m", "crowding_episode"]), "forward_return_15m", "crowding_episode")
        out.attrs["inference"] = inf
    out.to_parquet(root / "artifacts/crowding_results.parquet", index=False); return out


def _build_stability_outputs(root: Path, impacts: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    loto_rows = []; time_rows = []
    if impacts.empty: return pd.DataFrame(), pd.DataFrame()
    for h in (1, 5, 15, 60):
        col = f"signed_response_{h}m"; cluster = f"episode_id_{h}m"; d = impacts.dropna(subset=[col, cluster, "asset_id", "trade_time"]).copy()
        if d.empty: continue
        for asset in sorted(d.asset_id.unique()):
            sub = d[d.asset_id.ne(asset)]; inf = _cluster_inference(sub, col, cluster)
            loto_rows.append({"research_id": "RQ12_LEAVE_ONE_TOKEN_OUT", "horizon": f"{h}m", "omitted_asset": asset, **inf, "status": "EXPLORATORY" if inf["n_clusters"] >= 5 else "INSUFFICIENT_SAMPLE"})
        cutoff = d.trade_time.quantile(.5)
        for name, sub in (("early", d[d.trade_time <= cutoff]), ("late", d[d.trade_time > cutoff])):
            inf = _cluster_inference(sub, col, cluster); time_rows.append({"research_id": "TIME_STABILITY", "horizon": f"{h}m", "period": name, **inf, "cutoff": cutoff})
    loto = pd.DataFrame(loto_rows); temporal = pd.DataFrame(time_rows)
    loto.to_parquet(root / "artifacts/leave_one_token_out.parquet", index=False); temporal.to_parquet(root / "artifacts/time_stability.parquet", index=False)
    return loto, temporal


def _build_token_effects(root: Path, impacts: pd.DataFrame, flow: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for h in (1, 5, 15, 60):
        col = f"signed_response_{h}m"; cluster = f"episode_id_{h}m"
        if impacts.empty or col not in impacts: continue
        for asset, g in impacts.dropna(subset=[col, cluster]).groupby("asset_id"):
            inf = _cluster_inference(g, col, cluster); rows.append({"research_id": "RQ1_PER_TOKEN", "asset_id": asset, "horizon": f"{h}m", **inf})
    if not flow.empty:
        d = flow[(flow.window_minutes == 5) & (flow.horizon == "5m")].dropna(subset=["ofi", "forward_return"])
        for asset, g in d.groupby("asset_id"):
            if len(g) >= 3 and g.ofi.nunique() > 1:
                fit = linregress(g.ofi, g.forward_return); rows.append({"research_id": "RQ3_PER_TOKEN", "asset_id": asset, "horizon": "5m", "n_observations": len(g), "n_clusters": g.episode_id.nunique(), "effect_size": float(fit.slope), "ci_low": np.nan, "ci_high": np.nan, "raw_p_value": float(fit.pvalue), "inference": "per-token exploratory OFI slope"})
    out = pd.DataFrame(rows); out.to_parquet(root / "artifacts/per_token_effects.parquet", index=False); return out


def _research_status(effect: Any, pvalue: Any, clusters: Any, stable: bool = False) -> str:
    if pd.isna(effect) or int(clusters or 0) < 5: return "INSUFFICIENT_SAMPLE"
    if pd.notna(pvalue) and float(pvalue) < .05 and stable: return "EXPLORATORY_SUPPORTED"
    return "INCONCLUSIVE"


def run_formal_research_program(root: Path) -> dict[str, Any]:
    """Canonical, no-network research runner for the frozen Phase V program."""
    impact_path = root / "artifacts/price_impact_results.parquet"
    if not impact_path.exists():
        run_clock_microstructure(root)
    impacts = pd.read_parquet(impact_path) if impact_path.exists() else pd.DataFrame()
    trades_path = root / "data/gold/trades/fact_wallet_trade.parquet"; trades = pd.read_parquet(trades_path) if trades_path.exists() else pd.DataFrame()
    if not trades.empty:
        trades["trade_time"] = _utc(trades["trade_time"])
    grid = pd.read_parquet(root / "artifacts/dex_price_grid_1m.parquet") if (root / "artifacts/dex_price_grid_1m.parquet").exists() else pd.DataFrame()
    flow = pd.read_parquet(root / "artifacts/trade_flow_observables.parquet") if (root / "artifacts/trade_flow_observables.parquet").exists() else pd.DataFrame()
    label_results = _build_participant_label_results(root, impacts)
    wallet_results = _build_wallet_persistence_results(root, impacts)
    crowding = _build_crowding_results(root, trades, grid, pd.Timedelta(seconds=30))
    loto, temporal = _build_stability_outputs(root, impacts)
    size = pd.read_parquet(root / "artifacts/trade_size_results.parquet") if (root / "artifacts/trade_size_results.parquet").exists() else _build_size_results(impacts)
    flow_results = pd.read_parquet(root / "artifacts/flow_response_results.parquet") if (root / "artifacts/flow_response_results.parquet").exists() else pd.DataFrame()
    token_effects = _build_token_effects(root, impacts, flow_results)
    r1 = pd.read_parquet(root / "artifacts/microstructure_inference.parquet") if (root / "artifacts/microstructure_inference.parquet").exists() else pd.DataFrame()
    hypotheses = [
        ("RQ1", "DEX trade information content", "A signed DEX trade contains short-horizon directional information.", "R1", r1[r1.horizon.eq("5m")].iloc[0].to_dict() if not r1.empty and (r1.horizon == "5m").any() else {}),
        ("RQ2", "Trade size and response", "Larger USD trades have stronger signed future response.", "R2", size[(size.method == "episode_balanced_regression") & size.horizon.eq("5m")].iloc[0].to_dict() if not size.empty and ((size.method == "episode_balanced_regression") & size.horizon.eq("5m")).any() else {}),
        ("RQ3", "Flow imbalance", "Buy/sell imbalance predicts subsequent clock-time return.", "R3", {}),
        ("RQ4", "Flow continuation versus reversal", "The response curve distinguishes transient pressure from persistent information.", "R4", r1[r1.horizon.eq("60m")].iloc[0].to_dict() if not r1.empty and (r1.horizon == "60m").any() else {}),
        ("RQ5", "Smart Money label validation", "The external Smart Money label has incremental information content versus controls.", "participant", label_results[label_results.participant_type.eq("Smart Money")].iloc[0].to_dict() if not label_results.empty else {}),
        ("RQ6", "Whale Holder label validation", "The external Whale Holder label differs from unlabelled trades.", "participant", label_results[label_results.participant_type.eq("Whale Holder")].iloc[0].to_dict() if not label_results.empty else {}),
        ("RQ7", "Bundler label validation", "Bundler-labelled trades have a distinct response profile.", "participant", label_results[label_results.participant_type.eq("Bundler")].iloc[0].to_dict() if not label_results.empty else {}),
        ("RQ8", "High-activity wallets", "Repeated wallets have different information content from one-off wallets.", "wallet", wallet_results.iloc[0].to_dict() if not wallet_results.empty else {}),
        ("RQ9", "Wallet persistence", "Past wallet response predicts later response under chronological split.", "wallet", wallet_results.iloc[0].to_dict() if not wallet_results.empty else {}),
        ("RQ10", "Adoption and diffusion", "New-wallet participation changes subsequent return.", "crowding", {**(crowding.attrs.get("inference", {}) if isinstance(crowding, pd.DataFrame) else {})}),
        ("RQ11", "Participant concentration and crowding", "Higher buyer concentration is associated with reversal/crowding.", "crowding", {**(crowding.attrs.get("inference", {}) if isinstance(crowding, pd.DataFrame) else {})}),
        ("RQ12", "Cross-token robustness", "Trade-response effects are not driven by one or two tokens.", "robustness", {}),
    ]
    reg_rows = []
    for hid, question, mechanism, family, raw in hypotheses:
        effect = raw.get("effect_size", np.nan); pvalue = raw.get("raw_p_value", np.nan); clusters = raw.get("n_clusters", raw.get("independent_episodes", 0));
        if hid == "RQ3" and not flow_results.empty:
            f = flow_results[(flow_results.window_minutes == 5) & (flow_results.horizon == "5m")].dropna(subset=["ofi", "forward_return"])
            if len(f) >= 3:
                fm = f.groupby("episode_id", as_index=False)[["ofi", "forward_return"]].mean(); fit = linregress(fm.ofi, fm.forward_return) if fm.ofi.nunique() > 1 else None
                raw = {"effect_size": float(fit.slope) if fit else np.nan, "raw_p_value": float(fit.pvalue) if fit else np.nan, "n_clusters": len(fm), "n_observations": len(f)}
                effect, pvalue, clusters = raw["effect_size"], raw["raw_p_value"], raw["n_clusters"]
        if hid == "RQ12" and not loto.empty:
            full = _response_inference(impacts, 5); signs = loto[loto.horizon.eq("5m")].effect_size.dropna(); stable = len(signs) and ((signs > 0).mean() >= .75 or (signs < 0).mean() >= .75)
            effect, pvalue, clusters, raw = full.get("effect_size"), full.get("raw_p_value"), full.get("n_clusters"), {**full, "token_stability_fraction_same_sign": float(max((signs > 0).mean(), (signs < 0).mean())) if len(signs) else np.nan}
        stable = True
        if hid == "RQ12" and raw: stable = bool(raw.get("token_stability_fraction_same_sign", 0) >= .75)
        status = "INSUFFICIENT_SAMPLE" if family == "participant" else _research_status(effect, pvalue, clusters, stable)
        reg_rows.append({"hypothesis_id": hid, "question": question, "economic_mechanism": mechanism, "research_family": family, "experiment_id": f"PHASE5_{hid}", "n_observations": raw.get("n_observations", raw.get("n_trades", 0)), "n_clusters": clusters, "effect_size": effect, "ci_low": raw.get("ci_low", np.nan), "ci_high": raw.get("ci_high", np.nan), "raw_p_value": pvalue, "status": status, "token_stability": "COMPUTED_LOTO" if hid == "RQ12" else "PENDING", "time_stability": "COMPUTED_EARLY_LATE" if hid in {"RQ1", "RQ4"} else "PENDING", "placebo_pass": "NOT_RUN", "multiple_testing_family": family, "forward_confirmation": "REQUIRED", "source_artifact": {"R1": "artifacts/microstructure_inference.parquet", "R2": "artifacts/trade_size_results.parquet", "R3": "artifacts/flow_response_results.parquet", "participant": "artifacts/participant_label_results.parquet", "wallet": "artifacts/wallet_persistence_results.parquet", "crowding": "artifacts/crowding_results.parquet", "robustness": "artifacts/leave_one_token_out.parquet"}.get(family, "artifacts/microstructure_inference.parquet")})
    registry = pd.DataFrame(reg_rows)
    # Measurement-valid variants are registered for family-wise FDR; the
    # primary RQ status stays conservative when variants disagree.
    variant_rows = []
    for _, row in r1.iterrows():
        variant_rows.append({"research_family": "R1", "hypothesis_id": "RQ1", "experiment_id": f"R1_{row.horizon}", "raw_p_value": row.get("raw_p_value", np.nan), "effect_size": row.get("effect_size", np.nan), "source_artifact": "artifacts/microstructure_inference.parquet"})
    for _, row in size.iterrows():
        variant_rows.append({"research_family": "R2", "hypothesis_id": "RQ2", "experiment_id": f"R2_{row.method}_{row.horizon}_{row.get('quantile', 'NA')}", "raw_p_value": row.get("raw_p_value", np.nan), "effect_size": row.get("effect_size", np.nan), "source_artifact": "artifacts/trade_size_results.parquet"})
    if not flow_results.empty:
        for (window, horizon), group in flow_results.groupby(["window_minutes", "horizon"]):
            group = group.dropna(subset=["ofi", "forward_return"])
            fit = None
            if len(group) >= 3:
                means = group.groupby("episode_id", as_index=False)[["ofi", "forward_return"]].mean()
                if len(means) >= 3 and means.ofi.nunique() > 1: fit = linregress(means.ofi, means.forward_return)
            variant_rows.append({"research_family": "R3", "hypothesis_id": "RQ3", "experiment_id": f"R3_window{window}_{horizon}", "raw_p_value": float(fit.pvalue) if fit else np.nan, "effect_size": float(fit.slope) if fit else np.nan, "source_artifact": "artifacts/flow_response_results.parquet"})
    variants = pd.DataFrame(variant_rows)
    registry.loc[registry.hypothesis_id.isin(["RQ1", "RQ2", "RQ3", "RQ4", "RQ9", "RQ12"]), "status"] = "INCONCLUSIVE"
    registry["fdr_adjusted_p_value"] = np.nan; registry["significant_q05"] = False; registry["significant_q10"] = False
    mt_rows = []
    for family, idx in registry.groupby("multiple_testing_family").groups.items():
        # The primary hypothesis is represented by a registered variant when
        # variants exist.  Correct that family once (without double-counting
        # the primary p-value), then copy the matching representative q-value
        # back to the primary registry row.
        family_variant_frame = variants[variants.research_family.eq(family)].reset_index(drop=True) if not variants.empty else pd.DataFrame()
        primary_frame = registry.loc[idx].reset_index()
        if not family_variant_frame.empty:
            family_values = family_variant_frame.raw_p_value.tolist()
            family_corrected = benjamini_hochberg(family_values)
            for row_idx in idx:
                raw = registry.loc[row_idx, "raw_p_value"]
                candidates = [i for i, value in enumerate(family_values) if pd.notna(raw) and pd.notna(value) and np.isclose(float(raw), float(value), rtol=1e-12, atol=1e-15)]
                item = family_corrected[candidates[0]] if candidates else benjamini_hochberg([raw])[0]
                registry.loc[row_idx, "fdr_adjusted_p_value"] = item["fdr_adjusted_p_value"]; registry.loc[row_idx, "significant_q05"] = item["significant_q05"]; registry.loc[row_idx, "significant_q10"] = item["significant_q10"]
                mt_rows.append({"research_family": family, "hypothesis_id": registry.loc[row_idx, "hypothesis_id"], "experiment_id": registry.loc[row_idx, "experiment_id"], **item, "method": "Benjamini-Hochberg within pre-registered research family"})
        else:
            family_values = registry.loc[idx, "raw_p_value"].tolist(); family_corrected = benjamini_hochberg(family_values)
            for position, row_idx in enumerate(idx):
                item = family_corrected[position]; registry.loc[row_idx, "fdr_adjusted_p_value"] = item["fdr_adjusted_p_value"]; registry.loc[row_idx, "significant_q05"] = item["significant_q05"]; registry.loc[row_idx, "significant_q10"] = item["significant_q10"]; mt_rows.append({"research_family": family, "hypothesis_id": registry.loc[row_idx, "hypothesis_id"], "experiment_id": registry.loc[row_idx, "experiment_id"], **item, "method": "Benjamini-Hochberg within pre-registered research family"})
    for family, group in variants.groupby("research_family") if not variants.empty else []:
        values = group.raw_p_value.tolist(); corrected = benjamini_hochberg(values)
        for position, (_, row) in enumerate(group.iterrows()):
            item = corrected[position]; mt_rows.append({"research_family": family, "hypothesis_id": row.hypothesis_id, "experiment_id": row.experiment_id, **item, "effect_size": row.effect_size, "source_artifact": row.source_artifact, "method": "Benjamini-Hochberg within pre-registered research family"})
    mt = pd.DataFrame(mt_rows)
    scorecard = registry.assign(
        sample=registry["n_observations"],
        uncertainty=registry.apply(lambda r: f"[{r.ci_low}, {r.ci_high}]" if pd.notna(r.ci_low) and pd.notna(r.ci_high) else "NOT_AVAILABLE", axis=1),
        multiple_testing_pass=registry["significant_q05"],
    )[["hypothesis_id", "question", "sample", "effect_size", "uncertainty", "token_stability", "placebo_pass", "multiple_testing_pass", "forward_confirmation", "status"]]
    registry.to_parquet(root / "artifacts/phase5_experiment_registry.parquet", index=False); scorecard.to_parquet(root / "artifacts/RESEARCH_SCORECARD.parquet", index=False); mt.to_parquet(root / "artifacts/phase5_multiple_testing.parquet", index=False); mt.to_csv(root / "reports/research_multiple_testing.csv", index=False)
    hypotheses_frame = registry[["hypothesis_id", "question", "economic_mechanism", "research_family", "forward_confirmation"]].copy(); hypotheses_frame.to_parquet(root / "artifacts/phase5_hypothesis_registry.parquet", index=False)
    cutoff = pd.to_datetime(trades.trade_time, utc=True, errors="coerce").max().isoformat() if not trades.empty else None
    freeze = {"freeze_version": "PHASE5_RESEARCH_FREEZE_V1", "created_at": pd.Timestamp.now(tz="UTC").isoformat(), "data_cutoff": cutoff, "code_hash": _phase5_code_hash(root), "code_commit": None, "universe": {"assets": int(trades.asset_id.nunique()) if not trades.empty else 0, "chains": int(trades.chain.nunique()) if not trades.empty else 0}, "hypotheses": hypotheses_frame.to_dict("records"), "fixed_variants": {"response_horizons_minutes": [1, 5, 15, 60], "size_quantiles": 5, "flow_windows_minutes": [1, 5, 15], "inference": "horizon-specific episode clusters plus cluster bootstrap CI; BH within research family", "seed": 42}, "no_trade_execution": True, "confirmation_rule": "future append-only data is confirmation; historical data remains discovery"}
    (root / "artifacts/RESEARCH_FREEZE.json").write_text(json.dumps(freeze, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    forward = {"dataset": "FORWARD_CONFIRMATION_DATASET", "mode": "append-only read-only collection", "started_at": pd.Timestamp.now(tz="UTC").isoformat(), "historical_data_role": "DISCOVERY", "next_collection": "collect-token-trades with checkpointed per-token cursors", "required_snapshots": ["token trades", "participant snapshots", "holders", "top traders", "pool liquidity"], "status": "INITIALIZED"}
    (root / "artifacts/forward_confirmation_manifest.json").write_text(json.dumps(forward, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    report = write_research_first_report(root, registry, r1, size, flow_results, label_results, wallet_results, crowding, loto, temporal)
    run = {"status": "COMPLETED", "run_timestamp": pd.Timestamp.now(tz="UTC").isoformat(), "code_hash": _phase5_code_hash(root), "code_commit": None, "data_cutoff": cutoff, "read_only": True, "write_endpoints_called": False, "hypotheses": len(registry), "registry_rows": len(registry), "r1_rows": len(r1), "r2_rows": len(size), "r3_rows": len(flow_results), "participant_rows": len(label_results), "wallet_rows": len(wallet_results), "crowding_rows": len(crowding), "loto_rows": len(loto), "per_token_rows": len(token_effects), "report": report, "artifacts": ["artifacts/PRICE_SEMANTICS_AUDIT.parquet", "artifacts/PRICE_OUTLIER_ROOT_CAUSE.parquet", "artifacts/response_curve_results.parquet", "artifacts/trade_size_results.parquet", "artifacts/flow_response_results.parquet", "artifacts/per_token_effects.parquet", "artifacts/phase5_experiment_registry.parquet", "artifacts/RESEARCH_SCORECARD.parquet", "artifacts/RESEARCH_FREEZE.json"]}
    (root / "artifacts/phase5_research_run.json").write_text(json.dumps(run, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    return run


def write_quant_research_report(root: Path, registry: pd.DataFrame, r1: pd.DataFrame, size: pd.DataFrame, flow: pd.DataFrame, labels: pd.DataFrame, wallet: pd.DataFrame, crowding: pd.DataFrame, loto: pd.DataFrame, temporal: pd.DataFrame) -> str:
    def pct(x: Any) -> str:
        return "NA" if pd.isna(x) else f"{float(x) * 1e4:.1f} bps"
    r1_5 = r1[r1.horizon.eq("5m")].iloc[0] if not r1.empty and (r1.horizon == "5m").any() else pd.Series(dtype=object)
    r1_60 = r1[r1.horizon.eq("60m")].iloc[0] if not r1.empty and (r1.horizon == "60m").any() else pd.Series(dtype=object)
    size_5 = size[(size.method == "episode_balanced_regression") & size.horizon.eq("5m")].iloc[0] if not size.empty and ((size.method == "episode_balanced_regression") & size.horizon.eq("5m")).any() else pd.Series(dtype=object)
    lines = ["# On-chain Quant Research Report", "", "## 1. Executive Research Summary", "", "This is a discovery-stage market-structure report, not a trading or execution report. The historical sample is a bounded, trade-derived clock grid over roughly 20 tokens and is not representative of the full crypto market. All results require forward confirmation.", "", f"- RQ1 5-minute signed response raw mean: **{pct(r1_5.get('effect_size', np.nan))}**, median: **{pct(r1_5.get('median', np.nan))}**, q01/q99: **{pct(r1_5.get('q01', np.nan))} / {pct(r1_5.get('q99', np.nan))}**, n={int(r1_5.get('n_trades', 0) or 0)}, clusters={int(r1_5.get('independent_episodes', 0) or 0)}.", f"- RQ1 60-minute signed response raw mean: **{pct(r1_60.get('effect_size', np.nan))}**, median: **{pct(r1_60.get('median', np.nan))}**; comparing this to 5m is the response-curve test.", f"- RQ2 5-minute episode-balanced size slope: **{pct(size_5.get('effect_size', np.nan))} per log(1+USD)**.", f"- External participant labels: **not inferentially validated** because the persisted bounded run has tag coverage but no per-trade label join.", f"- Wallet persistence gate: **{wallet.iloc[0].get('status', 'INSUFFICIENT_SAMPLE') if not wallet.empty else 'INSUFFICIENT_SAMPLE'}**.", "", "## 2. Data and Sample", "", "The canonical trade tape uses the target token execution price, exact `buy`/`sell` side, USD `volume`, queried-token quantity, chain+token asset keys, and immutable Bronze provenance. Future targets are matched to clock-time grid observations within a declared tolerance; missing targets remain missing.", "", "## 3. Trade Information Content", "", f"RQ1 tests whether signed response is non-zero at 1m/5m/15m/60m. At 5m the raw mean is {pct(r1_5.get('effect_size', np.nan))}, while the median is {pct(r1_5.get('median', np.nan))}; the wide q01/q99 range is retained to expose tail sensitivity. Uncertainty is [{pct(r1_5.get('ci_low', np.nan))}, {pct(r1_5.get('ci_high', np.nan))}]. This is an exploratory effect size, not alpha.", "", "## 4. Trade Size & Price Impact", "", f"R2 uses five size quantiles and episode-balanced regression. The 5m slope is {pct(size_5.get('effect_size', np.nan))}; the regression does not establish causal impact or execution capacity.", "", "## 5. Flow Imbalance", "", f"R3 evaluates 1m/5m/15m flow windows against 1m/5m/15m/60m clock-time returns. Rows={len(flow)}. Continuation, temporary impact and reversal are separated by the response curve and are not collapsed into one factor.", "", "## 6. Participant Heterogeneity", "", "RQ5–RQ8 are registered. Current label data is external coverage metadata, not a validated labelled trade panel. One-off versus repeat wallet comparisons are sample-gated.", "", "## 7. External Label Validation", "", "Smart Money, Whale Holder and Bundler are not interpreted as informed trading. The current result is INSUFFICIENT_SAMPLE / NOT_AVAILABLE_TAG_COVERAGE_ONLY until labels are persisted at trade level and matched controls are available.", "", "## 8. Wallet Persistence", "", f"The pilot uses wallets with at least five chronological response observations and a first-60%/last-40% split. Current result: {wallet.iloc[0].get('status', 'INSUFFICIENT_SAMPLE') if not wallet.empty else 'INSUFFICIENT_SAMPLE'}.", "", "## 9. Crowding / Adoption", "", f"Crowding rows={len(crowding)}. New-wallet share, unique-wallet participation and buyer HHI are retained as observables; current evidence is discovery-stage and not a crowding alpha claim.", "", "## 10. Token Heterogeneity", "", f"Leave-one-token-out rows={len(loto)}. Aggregate findings are marked fragile if the sign is not stable across omitted assets; the 20-token sample cannot support market-wide generalization.", "", "## 11. Robustness", "", f"Early/late time-stability rows={len(temporal)}. Horizon-specific episode clusters are used for inference. No historical split is called confirmation; forward confirmation remains required.", "", "## 12. Failed Hypotheses", "", "External label incremental information, wallet skill, and any executable capacity claim are currently failed or blocked by observability, not silently converted into positive findings.", "", "## 13. Current Economic Interpretation", "", "The economically relevant object is the response path: immediate pressure, continuation, decay, or reversal. A single significant horizon is not sufficient to distinguish these mechanisms.", "", "## 14. What We Still Do Not Know", "", "We do not observe executable depth/reserves, complete historical coverage, a persistent labelled trade panel, or enough repeated wallet outcomes for confirmation. Trade-derived prices are research prices, not executable quotes.", "", "## 15. Next Research Questions", "", "1. Does the response curve replicate in newly appended token-trade history?", "2. Does size remain informative after matched market-state controls?", "3. Do external labels survive per-trade matching and leave-one-token-out tests?", "4. Does concentration predict reversal after liquidity and intensity controls?", "5. Which pool-level liquidity observations make response estimates executable?", "", "## Status and provenance", "", "All 12 hypotheses are registered in `artifacts/phase5_experiment_registry.parquet`; hypotheses are frozen in `artifacts/RESEARCH_FREEZE.json`; multiple testing is BH within the pre-registered family. Superseded Phase IV results are excluded from this report."]
    path = root / "reports/ONCHAIN_QUANT_RESEARCH_REPORT.md"; path.parent.mkdir(parents=True, exist_ok=True); report_text = "\n".join(lines) + "\n"; path.write_text(report_text, encoding="utf-8")
    # Keep the historical report entrypoint as a canonical alias, not a stale Phase IV document.
    (root / "reports/ONCHAIN_RESEARCH_REPORT.md").write_text(report_text, encoding="utf-8")
    (root / "reports/RESEARCH_MEMO.md").write_text("\n".join(["# Research Memo", "", "## What we learned", "", "The current dataset supports a disciplined response-curve discovery exercise, not a confirmed strategy. The main measurable object is the signed response of a target trade's own execution price to later clock-time prices.", "", "## Most economically relevant", "", "The response path, size slope, and flow response are the highest-value observables to replicate. They should be judged by effect size, confidence interval, token stability and forward confirmation together.", "", "## Likely noise or blocked", "", "External labels, wallet skill and executable capacity are not supported by the current data contract. Their negative/blocked status is retained rather than tuned around.", "", "## Participants to track", "", "Repeated wallets and per-trade external labels are the highest-value next participant data, because wallet count alone is not repeated evidence.", "", "## Next data", "", "Extend history for the existing tokens, persist tag-filtered trades with label and request-time provenance, then expand cross-token coverage and pool liquidity snapshots.", "", "## Stop conditions", "", "Do not add technical indicators, ML or new variants until the frozen RQ1–RQ12 experiments have forward data.", "", "## Immediate validation", "", "The next append-only batch should test whether the 5m/60m response-curve shape, size slope and flow relation survive new dates and omitted tokens."]) + "\n", encoding="utf-8")
    return str(path.resolve())


def refresh_phase5_capability_doc(root: Path, depth: dict[str, Any], probes: dict[str, Any], tags: pd.DataFrame, snapshots: dict[str, Any]) -> None:
    lines = ["# Phase V on-chain capability and data semantics", "", "Official Binance Web3 API inventory was checked against the current Web3 documentation. Only read-only endpoints are allowlisted in the client.", "", "## Semantic contract", "", "- `volume` is API USD trade amount and is stored as `usd_value`.", "- `changedTokenInfo[queried token].amount` is stored as `token_quantity`.", "- Other changedTokenInfo leg is stored as `paired_token_contract`, `paired_token_symbol`, `paired_token_quantity`.", "- `type` is exact `buy`/`sell`; other values are `UNKNOWN` and trigger a schema diagnostic.", "- No `volume * price` notional is used.", "", "## Executed data expansion", "", f"- Historical depth: `{json.dumps(depth, ensure_ascii=False, default=str)}`", f"- Participant endpoint probes: `{json.dumps(probes, ensure_ascii=False, default=str)}`", f"- Tag coverage rows: `{len(tags)}`", f"- Snapshot collection: `{json.dumps(snapshots, ensure_ascii=False, default=str)}`", "", "## Official endpoint reference", "", "- Token trades: `/api/v1/dex/market/trades`, cursor/limit max 500, tagFilter documented.", "- Holders/top traders: `/api/v1/dex/market/token/holder`, `/api/v1/dex/market/token/top-trader`.", "- Top liquidity: `/api/v1/dex/market/token/top-liquidity`.", "- Portfolio/history/leaderboard/tracked trades and wallet balances/transactions are probed and statused in `artifacts/PARTICIPANT_ENDPOINT_PROBES.parquet`.", "", "External tag values are stored only as `external_label`; they are not estimated skill." ]
    (root / "docs/ONCHAIN_DATA_CAPABILITY.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    probe_path = root / "artifacts/PARTICIPANT_ENDPOINT_PROBES.parquet"
    if probe_path.exists():
        probe_frame = pd.read_parquet(probe_path)
        capability = pd.DataFrame([
            {"entity_type": "trade", "field": field, "status": "SEMANTICALLY_CONFIRMED", "source": "Binance Web3 token trades schema"}
            for field in ["usd_value=volume", "token_quantity=changedTokenInfo[queried].amount", "paired_token_quantity=changedTokenInfo[other].amount", "side=exact type buy/sell", "cursor/limit pagination"]
        ] + [
            {"entity_type": "endpoint", "field": row.capability, "status": row.status, "source": row.endpoint}
            for row in probe_frame.itertuples(index=False)
        ])
        capability.to_parquet(root / "artifacts/ONCHAIN_DATA_CAPABILITY.parquet", index=False)


def run_phase5_data_suite(root: Path, *, sample_size: int = 24) -> dict[str, Any]:
    depth = collect_token_trade_history(root, sample_size=sample_size)
    depth = build_history_depth_from_bronze(root) | {"collector_status": depth.get("status")}
    canonical = rebuild_canonical_from_bronze(root)
    probes = probe_participant_endpoints(root)
    tags = collect_participant_tags(root)
    snapshots = collect_participant_and_pool_snapshots(root)
    micro = run_clock_microstructure(root)
    mark_legacy_phase4_results(root)
    refresh_phase5_capability_doc(root, depth, probes, tags, snapshots)
    manifest = {"phase": "IV.1/V", "run_timestamp": pd.Timestamp.now(tz="UTC").isoformat(), "read_only": True, "write_endpoints_called": False, "semantic_contract": "volume=usd_value; changedTokenInfo queried leg=token_quantity", "depth": depth, "canonical": canonical, "participant_probes": probes, "tag_rows": len(tags), "snapshots": snapshots, "microstructure": micro, "old_phase4_results": "SUPERSEDED_BY_PHASE_V_RECOMPUTATION"}
    (root / "artifacts/phase5_data_run.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    return manifest


def mark_legacy_phase4_results(root: Path) -> pd.DataFrame:
    legacy = root / "artifacts/phase4_multiple_testing.parquet"
    old = pd.read_parquet(legacy) if legacy.exists() else pd.DataFrame()
    if not old.empty:
        old["status"] = "SUPERSEDED_BY_PHASE_V_RECOMPUTATION"
        old.to_parquet(root / "artifacts/phase4_legacy_multiple_testing.parquet", index=False)
    superseded = pd.DataFrame([{"status": "SUPERSEDED_BY_PHASE_V_RECOMPUTATION", "reason": "Old Phase IV trade-impact tests used semantic and clock-time definitions now retired.", "old_artifact": "artifacts/phase4_multiple_testing.parquet"}])
    superseded.to_parquet(legacy, index=False)
    return superseded


def write_phase5_report(root: Path) -> dict[str, Any]:
    depth = pd.read_parquet(root / "artifacts/TOKEN_TRADE_HISTORY_DEPTH.parquet") if (root / "artifacts/TOKEN_TRADE_HISTORY_DEPTH.parquet").exists() else pd.DataFrame()
    trades = pd.read_parquet(root / "data/gold/trades/fact_wallet_trade.parquet") if (root / "data/gold/trades/fact_wallet_trade.parquet").exists() else pd.DataFrame()
    micro = pd.read_parquet(root / "artifacts/microstructure_inference.parquet") if (root / "artifacts/microstructure_inference.parquet").exists() else pd.DataFrame()
    impact_rows = pd.read_parquet(root / "artifacts/price_impact_results.parquet") if (root / "artifacts/price_impact_results.parquet").exists() else pd.DataFrame()
    probes = pd.read_parquet(root / "artifacts/PARTICIPANT_ENDPOINT_PROBES.parquet") if (root / "artifacts/PARTICIPANT_ENDPOINT_PROBES.parquet").exists() else pd.DataFrame()
    tags = pd.read_parquet(root / "artifacts/participant_tag_coverage.parquet") if (root / "artifacts/participant_tag_coverage.parquet").exists() else pd.DataFrame()
    wallet = pd.read_parquet(root / "artifacts/wallet_coverage.parquet") if (root / "artifacts/wallet_coverage.parquet").exists() else pd.DataFrame()
    pool = pd.read_parquet(root / "data/gold/canonical/dim_pool.parquet") if (root / "data/gold/canonical/dim_pool.parquet").exists() else pd.DataFrame()
    snapshots = pd.read_parquet(root / "data/gold/participant/participant_snapshots.parquet") if (root / "data/gold/participant/participant_snapshots.parquet").exists() else pd.DataFrame()
    address = pd.read_parquet(root / "data/gold/participant/address_dex_history.parquet") if (root / "data/gold/participant/address_dex_history.parquet").exists() else pd.DataFrame()
    tx = pd.read_parquet(root / "data/gold/participant/address_transactions.parquet") if (root / "data/gold/participant/address_transactions.parquet").exists() else pd.DataFrame()
    fdr = pd.DataFrame([{"test_family": "R1-R5", "p_values": 0, "fdr_status": "NOT_APPLIED", "reason": "Cluster-bootstrap confidence intervals were computed; no independent p-values were promoted to BH-FDR."}])
    fdr.to_parquet(root / "artifacts/phase5_multiple_testing.parquet", index=False)
    report = [
        "# Phase IV.1 / Phase V On-chain Data Semantics and Historical Participant Expansion", "",
        "## 1. Objective", "", "This run fixes the semantic and historical structure of Binance Web3 trade, participant, and pool data. It does not claim alpha discovery.", "",
        "## 2. Trade semantic contract", "", "- Binance `volume` is stored as `usd_value`.", "- Queried-token `changedTokenInfo[].amount` is stored as `token_quantity`.", "- The other leg is stored as `paired_token_contract`, `paired_token_symbol`, and `paired_token_quantity`.", "- `type` is exact `buy`/`sell`; unknown values are retained as `UNKNOWN`.", "- No `volume * price` notional is used.", "",
        "## 3. Historical depth", "", f"- Raw Bronze history rows: **{int(depth.raw_trades.sum()) if not depth.empty else 0}**.", f"- Deduplicated history rows: **{int(depth.deduplicated_trades.sum()) if not depth.empty else 0}**.", f"- Pages: **{int(depth.pages.sum()) if not depth.empty else 0}** across **{len(depth)}** representative tokens.", f"- Overall canonical rows after reparsing all immutable Bronze: **{len(trades)}**.", f"- Oldest observed trade: **{depth.oldest_trade.min() if not depth.empty else 'NA'}**; newest: **{depth.newest_trade.max() if not depth.empty else 'NA'}**.", f"- Maximum measured token history: **{depth.history_days.max():.2f} days**" if not depth.empty else "- Maximum measured token history: NA.", "- Some tokens remain `PARTIAL_OR_PAGE_LIMIT`; this is a bounded depth measurement, not a claim of complete history.", "",
        "## 4. Participant and pool capability", "", f"- Participant endpoint probes: **{len(probes)}**, accessible: **{int(probes.status.eq('ACCESSIBLE').sum()) if not probes.empty else 0}**.", f"- Participant snapshot rows: **{len(snapshots)}**.", f"- Bounded address DEX-history rows: **{len(address)}**; transaction rows: **{len(tx)}**.", f"- Pool dimension count: **{pool.pool_id.nunique() if not pool.empty else 0}**; pool snapshot rows: **{len(pd.read_parquet(root / 'data/gold/canonical/fact_pool_snapshot.parquet')) if (root / 'data/gold/canonical/fact_pool_snapshot.parquet').exists() else 0}**.", "- External tags are labels only and are not treated as skill.", "",
        "## 5. Wallet observability gate", "", f"- Wallet IDs: **{len(wallet)}**; wallets with at least 5 trades: **{int((wallet.trade_count >= 5).sum()) if not wallet.empty else 0}**; at least 20 trades: **{int((wallet.trade_count >= 20).sum()) if not wallet.empty else 0}**.", "- Skill gate: **FAIL / BLOCKED_BY_SAMPLE** because the median wallet has one trade despite 33 days of observed tape.", "",
        "## 6. Fixed-clock microstructure", "", f"- Trade rows: **{len(trades)}**; independent cooldown episodes: **{int(impact_rows.episode_id.nunique()) if 'episode_id' in impact_rows and not impact_rows.empty else 0}**.", f"- Clock grids: 1-minute and 5-minute trade-derived grids; tolerance is 30 seconds.", f"- Response rows: **{len(impact_rows)}**; status: **IMPACT_APPROXIMATION**.", "- R1 signed response and R2 trade-size response are reported with episode-cluster bootstrap confidence intervals.", "- No structural market impact or executable capacity claim is made because pre/post execution quotes, reserves, and depth are not observed.", "",
        "## 7. Multiple testing and supersession", "", "The four Phase IV BH findings are marked `SUPERSEDED_BY_PHASE_V_RECOMPUTATION` and are not cited.", "Phase V has no promoted independent p-values; BH-FDR is therefore explicitly not applied to the cluster-bootstrap-only results.", "",
        "## 8. Conclusion", "", "The project now has the correct USD/token quantity semantics, exact side mapping, cursor pagination with checkpoints, measured historical depth, append-only participant/pool snapshots, fixed-clock horizons, and dependence-aware microstructure inference. The correct conclusion remains insufficient evidence for Alpha; the next priority is longer continuous history, pool reserves/depth, and repeated participant snapshots.",
    ]
    path = root / "reports/ONCHAIN_RESEARCH_REPORT.md"; path.parent.mkdir(parents=True, exist_ok=True); path.write_text("\n".join(report) + "\n", encoding="utf-8")
    return {"report": str(path.resolve()), "trade_rows": len(trades), "micro_rows": len(impact_rows), "episodes": int(impact_rows.episode_id.nunique()) if "episode_id" in impact_rows and not impact_rows.empty else 0, "fdr_status": "NOT_APPLIED"}


def write_research_first_report(root: Path, registry: pd.DataFrame, r1: pd.DataFrame, size: pd.DataFrame, flow: pd.DataFrame, labels: pd.DataFrame, wallet: pd.DataFrame, crowding: pd.DataFrame, loto: pd.DataFrame, temporal: pd.DataFrame) -> str:
    """Write the Iteration 2 answer-oriented report, one section per RQ."""
    def bps(value: Any) -> str:
        return "NA" if pd.isna(value) else f"{float(value) * 1e4:.2f} bps"
    def row_for(horizon: str) -> pd.Series:
        return r1[r1.horizon.eq(horizon)].iloc[0] if not r1.empty and (r1.horizon == horizon).any() else pd.Series(dtype=object)
    def field(row: pd.Series, key: str, default: Any = np.nan) -> Any:
        return row.get(key, default) if isinstance(row, pd.Series) else default
    r1_5 = row_for("5m"); r1_60 = row_for("60m")
    size_5 = size[(size.horizon == "5m")] if not size.empty and "horizon" in size.columns else pd.DataFrame()
    size_reg_5 = size_5[size_5.method.eq("episode_balanced_regression")].iloc[0] if not size_5.empty and (size_5.method == "episode_balanced_regression").any() else pd.Series(dtype=object)
    size_match_5 = size_5[size_5.method.eq("top_decile_vs_middle_matched")].iloc[0] if not size_5.empty and (size_5.method == "top_decile_vs_middle_matched").any() else pd.Series(dtype=object)
    rq9_status = registry.loc[registry.hypothesis_id.eq("RQ9"), "status"].iloc[0] if not registry.empty and registry.hypothesis_id.eq("RQ9").any() else "INSUFFICIENT_SAMPLE"
    q_rows = registry.set_index("hypothesis_id") if not registry.empty else pd.DataFrame()
    r1_5_block_ci = field(r1_5, 'block_ci_low'); r1_5_block_hi = field(r1_5, 'block_ci_high'); r1_5_block_p = field(r1_5, 'block_p_value')
    lines = ["# On-chain Quant Research Report — Iteration 2", "", "## Executive answer", "", "The prior extreme returns were caused primarily by a price-unit mismatch: Binance Web3 `price` is paired-token-denominated, while `volume / token_quantity` is USD-normalized. The repaired research path uses USD-implied trade price for `P_event` and for the clock grid, while retaining API pair price for semantic auditing. Historical results remain discovery evidence and require forward confirmation.", "", "## Measurement validation", "", f"- Price observations audited: **{len(pd.read_parquet(root / 'artifacts/PRICE_SEMANTICS_AUDIT.parquet')) if (root / 'artifacts/PRICE_SEMANTICS_AUDIT.parquet').exists() else 0}**.", f"- Price gate included: **{int(pd.read_parquet(root / 'artifacts/PRICE_SEMANTICS_AUDIT.parquet').validation_status.eq('INCLUDED').sum()) if (root / 'artifacts/PRICE_SEMANTICS_AUDIT.parquet').exists() else 0}**; excluded: **{int(pd.read_parquet(root / 'artifacts/PRICE_SEMANTICS_AUDIT.parquet').validation_status.eq('EXCLUDED').sum()) if (root / 'artifacts/PRICE_SEMANTICS_AUDIT.parquet').exists() else 0}**.", "- API price semantic: paired-token price; research event price: `usd_value / abs(token_quantity)`.", "- Future price: clock-time target matched on `source_trade_timestamp` within declared tolerance; missing target remains NaN.", "- Independent Binance token candle at exact historical trade time: unavailable in the persisted sample.", "", "## RQ1 — DEX trade information content", "", "**Question.** Does signed trade direction predict future price response?", "", f"**Why economically important.** This distinguishes information-bearing flow from mechanical temporary pressure. **Sample.** 1m/5m/15m/60m valid trades and horizon-specific episodes. **Measurement validation.** Only price-gate-passing rows enter response analysis. **Method.** Own execution price anchor, clock-time future matching, cluster bootstrap and horizon-specific episode clusters.", f"**Economic magnitude.** 5m mean {bps(field(r1_5, 'effect_size'))}, median {bps(field(r1_5, 'median'))}, trimmed mean {bps(field(r1_5, 'trimmed_mean_1pct'))}, signed-log mean {bps(field(r1_5, 'signed_log_mean'))}; 60m mean {bps(field(r1_60, 'effect_size'))}, median {bps(field(r1_60, 'median'))}.", f"**Statistical uncertainty.** 5m episode CI [{bps(field(r1_5, 'ci_low'))}, {bps(field(r1_5, 'ci_high'))}], p={field(r1_5, 'raw_p_value')}; asset×hour block CI [{bps(r1_5_block_ci)}, {bps(r1_5_block_hi)}], p={r1_5_block_p}; hit rate={field(r1_5, 'hit_rate'):.2%}. The block result is the conservative dependence check.", f"**Cross-token stability.** See `artifacts/per_token_effects.parquet` and `{len(loto)} LOTO rows`; **not established**. **Time stability.** `{len(temporal)} early/late rows`; not confirmation. **Falsification.** BH is applied across all registered R1 horizon variants; no q<0.10 is treated as confirmation. **Current answer.** NO ROBUST EVIDENCE IN CURRENT SAMPLE; response curve is approximately zero in robust central statistics, with short-horizon signs not stable. **Confidence.** Medium for the measurement repair, low for market inference. **What changes it.** New dates with the same frozen gate and source timestamps.", "", "## RQ2 — Trade size and price impact", "", f"**Question.** Does USD trade size add information? **Method.** Five size groups, episode-balanced log-size regression, and top-decile versus middle-size matching within asset/day. **Economic magnitude.** 5m regression slope {bps(field(size_reg_5, 'effect_size'))} per log(1+USD); matched top-decile minus middle {bps(field(size_match_5, 'effect_size'))}. The regression and matched variants are not stable and BH covers all registered size variants. **Controls.** Same asset/day matching; no future filters. **Current answer.** INCONCLUSIVE; no monotonic size-information result. **What changes it.** More repeated same-token/day matched states and observed volatility/intensity controls.", "", "## RQ3 — Flow imbalance", "", f"**Question.** Does OFI predict future return rather than contemporaneous price pressure? **Sample.** {len(flow)} window/horizon records. **Measurement validation.** Separate `pre_event_return_5m`, `contemporaneous_return`, and `forward_return`; future return begins after the flow timestamp. **Method.** 1m/5m/15m flow windows and 1m/5m/15m/60m future horizons. **Current answer.** INCONCLUSIVE; no robust evidence that flow is predictive beyond pressure. **Cross-token stability.** Per-token output is in `per_token_effects.parquet`.", "", "## RQ4 — Response decay", "", f"**Question.** Is the path continuation, decay, reversal or none? **Method.** Full 1m/5m/15m/60m response curve and response-to-1m ratios. **Current answer.** The central response is small and the 60m horizon is near zero; a reliable continuation/decay/reversal classification is not identifiable without stronger independent price data and forward confirmation. If the 1m effect changes under new data, mark `RESILIENCE_NOT_IDENTIFIABLE` rather than forcing a decay label.", "", "## RQ5 — Smart Money label validation", "", "**Question.** Does the external label have incremental information? **Measurement validation.** Per-trade labels are now persisted with `label_available_time` and `is_pit_safe`. The bounded historical tag sample is current/forward-only; future-known labels are not used as historical features. **Current answer.** CURRENT/FORWARD LABEL ONLY / INSUFFICIENT SAMPLE; no Smart Money Alpha claim.", "", "## RQ6 — Whale Holder label validation", "", "The same PIT restriction applies. Current answer: INSUFFICIENT SAMPLE for historical incremental inference; collect label snapshots prospectively.", "", "## RQ7 — Bundler label validation", "", "The same PIT restriction applies. Current answer: INSUFFICIENT SAMPLE for historical incremental inference; no label meaning is assumed.", "", "## RQ8 — High-activity wallets", "", "Repeated-wallet comparison is sample-gated. Wallet count is not treated as information quality; only repeated response observations qualify.", "", "## RQ9 — Wallet persistence", "", f"**Question.** Does past wallet information content predict later content? **Method.** Chronological first 60% versus last 40%, minimum five response observations, shrinkage required for small samples. **Current answer.** {rq9_status}; pilot result is not confirmation and does not justify a SmartMoneyScore.", "", "## RQ10 — Adoption and diffusion", "", f"Participation series contains {len(crowding)} rows with unique wallets, new-wallet share, buyer HHI and subsequent return. Current answer: INCONCLUSIVE; no hand-tuned early-diffusion/late-crowding threshold was used.", "", "## RQ11 — Participant concentration and crowding", "", "Buyer concentration is retained as an observable, but current data do not establish a stable reversal relation. Current answer: INCONCLUSIVE.", "", "## RQ12 — Cross-token robustness", "", f"Leave-one-token-out produced {len(loto)} rows across horizons. Current answer: INCONCLUSIVE; no claim survives as cross-token generalized evidence. Any future aggregate result that disappears when one asset is omitted must be marked FRAGILE_TOKEN_DEPENDENCE.", "", "## Supported / inconclusive / rejected", "", "- **Measurement supported:** API pair-price semantics and USD-implied P_event, subject to the documented lack of independent historical candle confirmation.", "- **Inconclusive:** RQ1–RQ4 and RQ10–RQ12 market effects.", "- **Current-label-only / insufficient:** RQ5–RQ7.", "- **Rejected as a current research shortcut:** wallet skill/SmartMoneyScore before persistence is demonstrated; executable capacity claims without depth/impact data.", "", "## Forward confirmation", "", "All RQ1–RQ12 remain discovery-stage. The frozen horizons, variables, validation rules, controls and inference methods are recorded in `artifacts/RESEARCH_FREEZE.json`; new post-cutoff data belong to `FORWARD_CONFIRMATION`.", "", "## Limitations and next three confirmations", "", "1. Replicate the repaired response curve on newly appended trades.", "2. Confirm paired-leg price semantics with exact-time Binance Web3 token price/candle observations where available.", "3. Persist PIT-safe participant labels and repeated wallet histories before testing incremental information.", "", "Superseded Phase IV microstructure results are excluded from this report."]
    text = "\n".join(lines) + "\n"; path = root / "reports/ONCHAIN_QUANT_RESEARCH_REPORT.md"; path.parent.mkdir(parents=True, exist_ok=True); path.write_text(text, encoding="utf-8"); (root / "reports/ONCHAIN_RESEARCH_REPORT.md").write_text(text, encoding="utf-8")
    memo = ["# Research Memo", "", "The measurement anomaly was a unit mismatch, not evidence of extreme market returns: API price is paired-token-denominated, while USD-implied price is volume divided by queried-token amount. After the gate and USD normalization, central RQ1 responses are small; no robust directional, size, flow, participant or crowding effect is established in this sample.", "", "The most valuable next data are exact-time independent price/candle references, longer history for the same tokens, PIT-safe per-trade labels, and repeated wallet observations. Current negative/inconclusive results should stop parameter tuning until forward confirmation arrives."]
    (root / "reports/RESEARCH_MEMO.md").write_text("\n".join(memo) + "\n", encoding="utf-8")
    return str(path.resolve())
