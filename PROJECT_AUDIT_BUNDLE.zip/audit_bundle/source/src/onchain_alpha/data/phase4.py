"""Phase IV on-chain-native research layer.

This layer consumes the real Web3 trade tape and does not require a CEX pair.
It intentionally treats wallet observations, trade-derived microstructure and
first-observed lifecycle as separate research objects with explicit gates.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

from .phase3 import _empty, _safe_json, _utc


def normalize_wallet_id(chain: Any, address: Any) -> str | None:
    if address in (None, "", "nan"):
        return None
    chain = str(chain)
    value = str(address).strip()
    # EVM addresses are case-insensitive. Solana/base58 and other chains are
    # case-sensitive, so preserve their representation.
    return f"{chain}:{value.lower() if value.startswith(('0x', '0X')) else value}"


def pool_identity(chain: Any, dex: Any, pool: Any) -> str | None:
    if pool in (None, "", "nan"):
        return None
    return f"{chain}:{dex}:{pool}"


def shrink_skill(raw_skill: float, observations: int, prior: float = 0.0, prior_strength: float = 5.0) -> float:
    n = max(0, int(observations)); return float((n * raw_skill + prior_strength * prior) / (n + prior_strength))


def wallet_state_asof(trades: pd.DataFrame, asof: Any) -> pd.DataFrame:
    cutoff = _utc(asof); d = trades[_utc(trades["trade_time"]) <= cutoff].copy() if not trades.empty else trades.copy()
    if d.empty: return pd.DataFrame(columns=["wallet_id", "trade_count", "asset_count", "last_trade"])
    return d.groupby("wallet_key", as_index=False).agg(trade_count=("trade_id", "nunique"), asset_count=("asset_id", "nunique"), last_trade=("trade_time", "max")).rename(columns={"wallet_key": "wallet_id"})


def temporal_edges_asof(edges: pd.DataFrame, asof: Any) -> pd.DataFrame:
    if edges.empty: return edges.copy()
    cutoff = _utc(asof); return edges[_utc(edges["event_time"]) <= cutoff].copy()


def lifecycle_censor_status(first_observed: Any, last_observed: Any, cutoff: Any, inactive_after_hours: int = 24) -> str:
    first, last, end = _utc(first_observed), _utc(last_observed), _utc(cutoff)
    if pd.isna(first) or pd.isna(last) or pd.isna(end): return "UNKNOWN"
    return "EVENT_INACTIVE" if (end - last).total_seconds() >= inactive_after_hours * 3600 else "RIGHT_CENSORED_ACTIVE"


def _trade_frame(root: Path) -> pd.DataFrame:
    path = root / "data/gold/trades/fact_wallet_trade.parquet"
    if not path.exists():
        return pd.DataFrame()
    d = pd.read_parquet(path).copy()
    if not d.empty:
        d["trade_time"] = _utc(d["trade_time"]); d["available_time"] = _utc(d["available_time"])
        d["wallet_key"] = [normalize_wallet_id(c, w) for c, w in zip(d["chain"], d["wallet_id"])]
        if "token_quantity" not in d:
            d["token_quantity"] = pd.to_numeric(d.get("quantity"), errors="coerce")
        d["token_quantity"] = pd.to_numeric(d["token_quantity"], errors="coerce")
        d["quantity"] = d["token_quantity"]  # compatibility alias; not USD notional
        d["usd_value"] = pd.to_numeric(d.get("usd_value"), errors="coerce")
        d["price"] = pd.to_numeric(d["price"], errors="coerce")
    return d


def audit_onchain_capabilities(root: Path) -> dict[str, Any]:
    raw_files = sorted((root / "data/bronze/binance_web3/trades").glob("*.json"))
    field_rows: list[dict[str, Any]] = []
    payload_fields: dict[str, int] = {}
    total = 0
    examples: dict[str, Any] = {}
    for path in raw_files:
        try:
            payload = json.loads(path.read_text(encoding="utf-8")).get("payload", {})
        except Exception:
            continue
        records = payload.get("trades", []) if isinstance(payload, dict) else []
        for record in records:
            if not isinstance(record, dict):
                continue
            total += 1
            for key, value in record.items():
                payload_fields[key] = payload_fields.get(key, 0) + 1
                examples.setdefault(key, type(value).__name__)
    known = ["userAddress", "txHash", "dexName", "type", "price", "volume", "time", "tokenContractAddress", "changedTokenInfo", "pool", "blockNumber", "route"]
    for field in known + sorted(set(payload_fields) - set(known)):
        n = payload_fields.get(field, 0)
        field_rows.append({"entity_type": "trade", "event_state_type": "DEX_TRADE", "field": field, "rows": total, "non_null_rows": n, "coverage": n / total if total else 0.0, "dtype_observed": examples.get(field, "absent"), "historical_depth": "sample response window only", "pagination": "pageId/size; cursor returned", "timestamp": "time (ms)" if field == "time" else "", "address_availability": "available" if field == "userAddress" and n else "unavailable", "pit_usability": "available_time is API response time; event_time is trade time", "snapshot_or_history": "history page/sample", "research_tracks_supported": "B,A,C,F" if field in {"userAddress", "time", "price", "volume", "type"} else "B", "limitations": "No pool/address-derived USD notional confirmed" if field in {"pool", "blockNumber", "route"} and n == 0 else ""})
    for capability, fields, status, reason in [
        ("token trades", "time,txHash,userAddress,dexName,type,price,volume,tokenContractAddress,changedTokenInfo", "ACCESSIBLE_WITH_CURRENT_KEY", "Real raw responses returned 100 trades/page in four chain probes."),
        ("holders ranking", "holders,bnHolderCount,top10HoldingPercent", "SNAPSHOT_PROXY_ONLY", "Observed in advanced-info/price-info token snapshots; no wallet-level history."),
        ("top traders", "", "NOT_PROBED", "No documented safe endpoint path confirmed."),
        ("wallet portfolio/PnL/balances/transactions", "", "NOT_PROBED", "No documented safe endpoint path confirmed."),
        ("pool/liquidity", "liquidity,pool,poolAddress", "PARTIAL", "Liquidity and pool fields are available in separate token probes, not in the trade tape sample."),
    ]:
        field_rows.append({"entity_type": "capability", "event_state_type": capability, "field": fields, "rows": total, "non_null_rows": total if status.startswith("ACCESS") else 0, "coverage": 1.0 if status.startswith("ACCESS") else 0.0, "dtype_observed": "", "historical_depth": "sample only", "pagination": "observed where applicable", "timestamp": "", "address_availability": "available" if capability == "token trades" else "unknown", "pit_usability": "PARTIAL", "snapshot_or_history": "history/sample" if capability == "token trades" else "unknown", "research_tracks_supported": "B,F" if capability == "token trades" else "", "limitations": f"{status}: {reason}"})
    coverage = pd.DataFrame(field_rows)
    coverage.to_parquet(root / "artifacts/WEB3_TRADE_FIELD_COVERAGE.parquet", index=False)
    coverage.to_parquet(root / "artifacts/ONCHAIN_DATA_CAPABILITY.parquet", index=False)
    docs = ["# On-chain data capability", "", f"Trade records audited from raw Bronze responses: **{total}** across **{len(raw_files)}** files.", "", "| Entity/capability | Fields | Coverage | Address | PIT | Status/limitation |", "|---|---|---:|---|---|---|"]
    for _, row in coverage[coverage["entity_type"].isin(["capability", "trade"])].iterrows():
        docs.append(f"| {row['event_state_type']} | `{row['field']}` | {row['coverage']:.1%} | {row['address_availability']} | {row['pit_usability']} | {row['limitations']} |")
    docs.extend(["", "## Schema audit", "", "Observed trade keys: `" + "`, `".join(sorted(payload_fields)) + "`.", "", "The payload contains `userAddress`, so participant research is enabled, but the sample is short and heavily single-trade. `usd_value`, pool address, block number, route and LP state are not reliably supplied in this sample and are not fabricated."])
    (root / "docs/ONCHAIN_DATA_CAPABILITY.md").write_text("\n".join(docs) + "\n", encoding="utf-8")
    return {"raw_files": len(raw_files), "trade_rows": total, "fields": sorted(payload_fields), "address_available": bool(payload_fields.get("userAddress")), "output": str((root / "artifacts/ONCHAIN_DATA_CAPABILITY.parquet").resolve())}


def build_onchain_canonical(root: Path) -> dict[str, int]:
    trades = _trade_frame(root)
    if trades.empty:
        dex = pd.DataFrame(columns=["trade_id", "chain", "dex", "pool", "token_in", "token_out", "wallet_id", "event_time", "available_time", "ingest_time", "tx_hash", "price", "usd_value", "quantity", "side", "route", "block_number", "source"])
    else:
        dex = trades.rename(columns={"token_address": "token_in", "dex": "dex", "pool": "pool", "wallet_id": "wallet_id", "trade_time": "event_time", "quantity": "quantity", "usd_value": "usd_value", "tx_hash": "tx_hash", "price": "price", "side": "side"})
        dex["token_out"] = pd.NA; dex["route"] = pd.NA; dex["block_number"] = pd.NA; dex["ingest_time"] = pd.Timestamp.now(tz="UTC"); dex["source"] = "BINANCE_WEB3_TRADES"; dex = dex[["trade_id", "chain", "dex", "pool", "token_in", "token_out", "wallet_id", "event_time", "available_time", "ingest_time", "tx_hash", "price", "usd_value", "quantity", "side", "route", "block_number", "source"]]
    out = root / "data/gold/canonical"; out.mkdir(parents=True, exist_ok=True); dex.to_parquet(out / "fact_dex_trade.parquet", index=False); trades.to_parquet(out / "fact_wallet_trade.parquet", index=False)
    return {"fact_dex_trade": len(dex), "fact_wallet_trade": len(trades)}


def run_wallet_observability(root: Path) -> dict[str, Any]:
    d = _trade_frame(root)
    if d.empty:
        coverage = pd.DataFrame(columns=["wallet_id", "trade_count", "asset_count", "chain_count", "first_trade", "last_trade", "active_days", "single_trade"])
    else:
        coverage = d.dropna(subset=["wallet_key"]).groupby("wallet_key").agg(trade_count=("trade_id", "nunique"), asset_count=("asset_id", "nunique"), chain_count=("chain", "nunique"), first_trade=("trade_time", "min"), last_trade=("trade_time", "max"), active_days=("trade_time", lambda x: x.dt.floor("D").nunique())).reset_index().rename(columns={"wallet_key": "wallet_id"}); coverage["single_trade"] = coverage["trade_count"].eq(1)
    coverage.to_parquet(root / "artifacts/wallet_coverage.parquet", index=False)
    obs = {"wallet_count": int(len(coverage)), "trade_count": int(len(d)), "multi_trade_wallets": int((coverage["trade_count"] > 1).sum()) if not coverage.empty else 0, "single_trade_ratio": float(coverage["single_trade"].mean()) if not coverage.empty else 1.0, "median_trades_per_wallet": float(coverage["trade_count"].median()) if not coverage.empty else 0.0, "median_assets_per_wallet": float(coverage["asset_count"].median()) if not coverage.empty else 0.0, "chains": int(d["chain"].nunique()) if not d.empty else 0, "status": "OBSERVABLE_BUT_SHORT" if len(coverage) else "BLOCKED_BY_DATA"}
    gate = {"wallet_min": 50, "median_trades_min": 3, "history_days_min": 7, "wallet_count": obs["wallet_count"], "median_trades_per_wallet": obs["median_trades_per_wallet"], "history_days": int((d["trade_time"].max() - d["trade_time"].min()).total_seconds() / 86400) if not d.empty else 0, "status": "PASS" if obs["wallet_count"] >= 50 and obs["median_trades_per_wallet"] >= 3 and obs["history_days"] >= 7 else "FAIL", "reason": "The observed tape is dominated by single-trade wallets and has short history."}
    pd.DataFrame([gate]).to_parquet(root / "artifacts/wallet_skill_gate.parquet", index=False)
    (root / "docs/WALLET_OBSERVABILITY_REPORT.md").write_text("# Wallet observability\n\n" + "\n".join(f"- {k}: {v}" for k, v in obs.items()) + "\n\n## Skill gate\n\n" + "\n".join(f"- {k}: {v}" for k, v in gate.items()) + "\n\nWallet identifiers are `(chain,address)`; EVM addresses are lowercased and non-EVM representations preserve case. Skill research is not promoted when the gate fails.\n", encoding="utf-8")
    return obs | gate


def run_wallet_skill(root: Path) -> pd.DataFrame:
    gate = pd.read_parquet(root / "artifacts/wallet_skill_gate.parquet") if (root / "artifacts/wallet_skill_gate.parquet").exists() else pd.DataFrame()
    cols = ["wallet_id", "raw_skill", "shrunk_skill", "skill_uncertainty", "status", "reason"]
    if gate.empty or gate.iloc[0]["status"] != "PASS":
        out = pd.DataFrame([{"wallet_id": None, "raw_skill": np.nan, "shrunk_skill": np.nan, "skill_uncertainty": np.nan, "status": "BLOCKED_BY_SAMPLE", "reason": "Wallet skill gate FAIL; no single-trade wallet is promoted to skill."}], columns=cols)
    else:
        out = pd.DataFrame(columns=cols)
    out.to_parquet(root / "artifacts/wallet_skill_phase4.parquet", index=False); return out


def _future_price_returns(group: pd.DataFrame, horizons: Iterable[int]) -> dict[str, float]:
    g = group.sort_values("trade_time").dropna(subset=["trade_time", "price"]); times = g["trade_time"].astype("int64").to_numpy(); prices = g["price"].to_numpy(dtype=float); result: dict[str, float] = {}
    for h in horizons:
        vals = []
        for t, p in zip(times, prices):
            j = np.searchsorted(times, t + h * 60 * 1_000_000_000, side="left")
            if j < len(prices) and p > 0: vals.append(prices[j] / p - 1)
        result[f"future_return_{h}m"] = float(np.mean(vals)) if vals else np.nan
    return result


def run_microstructure(root: Path) -> dict[str, Any]:
    d = _trade_frame(root)
    if d.empty:
        observables = pd.DataFrame(); impacts = pd.DataFrame(); resilience = pd.DataFrame()
    else:
        d["flow_value"] = d["usd_value"]
        d["buy_flow"] = d["flow_value"].where(d["side"].eq("buy"), 0.0); d["sell_flow"] = d["flow_value"].where(d["side"].eq("sell"), 0.0)
        observables = d.groupby(["asset_id", "chain", "trade_time"], as_index=False).agg(buy_flow=("buy_flow", "sum"), sell_flow=("sell_flow", "sum"), trade_count=("trade_id", "nunique"), vwap=("price", "mean"), active_wallets=("wallet_key", "nunique")); observables["net_flow"] = observables["buy_flow"] - observables["sell_flow"]; observables["volume_imbalance"] = observables["net_flow"] / (observables["buy_flow"] + observables["sell_flow"] + 1e-12); observables["source"] = "TRADE_RECONSTRUCTED"
        rows = []
        for aid, g in d.groupby("asset_id"):
            g = g.sort_values("trade_time"); g["flow_value"] = g["flow_value"].fillna(0.0); g["signed_flow"] = np.where(g["side"].eq("buy"), g["flow_value"], np.where(g["side"].eq("sell"), -g["flow_value"], np.nan))
            for _, row in g.iterrows():
                t = row.trade_time; future = g[g.trade_time >= t]
                rec = {"asset_id": aid, "chain": row.chain, "event_time": t, "trade_id": row.trade_id, "signed_flow": row.signed_flow, "price": row.price, "trade_size": row.flow_value, "source": "TRADE_RECONSTRUCTED"}
                for h in (1, 5, 15, 60):
                    match = future[future.trade_time >= t + pd.Timedelta(minutes=h)]
                    rec[f"forward_return_{h}m"] = float(match.iloc[0].price / row.price - 1) if not match.empty and row.price > 0 else np.nan
                rows.append(rec)
        impacts = pd.DataFrame(rows); resilience = impacts.groupby("asset_id", as_index=False).agg(n_events=("trade_id", "count"), immediate_return=("forward_return_1m", "mean"), return_5m=("forward_return_5m", "mean"), return_15m=("forward_return_15m", "mean"), return_60m=("forward_return_60m", "mean")); resilience["status"] = np.where(resilience["n_events"] >= 30, "EXPLORATORY", "INSUFFICIENT_EVIDENCE")
    (root / "artifacts/trade_flow_observables.parquet").parent.mkdir(parents=True, exist_ok=True); observables.to_parquet(root / "artifacts/trade_flow_observables.parquet", index=False); impacts.to_parquet(root / "artifacts/price_impact_results.parquet", index=False); resilience.to_parquet(root / "artifacts/resilience_results.parquet", index=False)
    pd.DataFrame([{ "research_id": "R-B3-LIQUIDITY", "status": "BLOCKED_BY_DATA", "reason": "No reliable pool/reserve/depth history in trade tape sample."}]).to_parquet(root / "artifacts/liquidity_shock_results.parquet", index=False)
    return {"trade_rows": len(d), "observable_rows": len(observables), "impact_rows": len(impacts), "resilience_assets": len(resilience), "status": "EXPLORATORY" if len(impacts) else "BLOCKED_BY_DATA"}


def build_temporal_network(root: Path) -> dict[str, Any]:
    d = _trade_frame(root)
    if d.empty:
        edges = pd.DataFrame(columns=["wallet_id", "asset_id", "event_time", "available_time", "edge_weight"]); diffusion = pd.DataFrame()
    else:
        edges = d.dropna(subset=["wallet_key"])[["wallet_key", "asset_id", "trade_time", "available_time", "quantity"]].rename(columns={"wallet_key": "wallet_id", "trade_time": "event_time", "quantity": "edge_weight"}); edges["edge_weight"] = edges["edge_weight"].abs(); edges = edges.drop_duplicates(["wallet_id", "asset_id", "event_time"]); diffusion = edges.groupby("asset_id", as_index=False).agg(first_adoption=("event_time", "min"), adopters=("wallet_id", "nunique"), trade_edges=("wallet_id", "count")); diffusion["status"] = np.where(diffusion["adopters"] >= 10, "EXPLORATORY", "INSUFFICIENT_EVIDENCE")
    edges.to_parquet(root / "artifacts/network_edges.parquet", index=False); diffusion.to_parquet(root / "artifacts/diffusion_results.parquet", index=False); return {"edges": len(edges), "assets": int(diffusion.asset_id.nunique()) if not diffusion.empty else 0, "status": "EXPLORATORY" if len(edges) else "BLOCKED_BY_DATA"}


def build_forward_pit_universe(root: Path) -> pd.DataFrame:
    trades = _trade_frame(root); now = pd.Timestamp.now(tz="UTC");
    if trades.empty:
        out = pd.DataFrame(columns=["snapshot_time", "asset_id", "chain", "first_observed", "token_age_days", "activity_trades", "data_available", "eligibility_reason"])
    else:
        out = trades.groupby(["asset_id", "chain"], as_index=False).agg(first_observed=("trade_time", "min"), activity_trades=("trade_id", "nunique")); out["snapshot_time"] = now; out["token_age_days"] = (now - _utc(out["first_observed"])).dt.total_seconds() / 86400; out["data_available"] = True; out["eligibility_reason"] = "observed trade activity in current forward snapshot"; out = out[["snapshot_time", "asset_id", "chain", "first_observed", "token_age_days", "activity_trades", "data_available", "eligibility_reason"]]
    path = root / "data/gold/universe/forward_pit_universe.parquet"; path.parent.mkdir(parents=True, exist_ok=True); out.to_parquet(path, index=False); return out


def run_lifecycle(root: Path) -> dict[str, Any]:
    d = _trade_frame(root); universe = build_forward_pit_universe(root)
    if d.empty:
        result = pd.DataFrame(columns=["asset_id", "lifecycle_state", "n_trades", "n_wallets", "first_observed", "activity_rate", "volatility", "status"])
    else:
        rows = []
        for aid, g in d.groupby("asset_id"):
            first = g.trade_time.min(); age = (g.trade_time.max() - first).total_seconds() / 86400; state = "initial_discovery" if age <= 1 else "early_growth" if age <= 7 else "expansion" if age <= 30 else "mature"; p = g.sort_values("trade_time").price; rows.append({"asset_id": aid, "lifecycle_state": state, "n_trades": len(g), "n_wallets": g.wallet_key.nunique(), "first_observed": first, "activity_rate": len(g) / max((g.trade_time.max() - first).total_seconds() / 86400, 1 / 24), "volatility": p.pct_change().std(), "censor_status": lifecycle_censor_status(first, g.trade_time.max(), g.trade_time.max()), "status": "EXPLORATORY_FIRST_OBSERVED_AGE"})
        result = pd.DataFrame(rows)
    result.to_parquet(root / "artifacts/lifecycle_results.parquet", index=False)
    if not result.empty:
        result[["asset_id", "first_observed", "censor_status", "n_trades", "status"]].to_parquet(root / "artifacts/lifecycle_survival_results.parquet", index=False)
    return {"assets": len(result), "status": "EXPLORATORY" if len(result) else "BLOCKED_BY_DATA", "forward_universe": len(universe)}


def run_cross_dex(root: Path) -> dict[str, Any]:
    d = _trade_frame(root); relations = d.dropna(subset=["asset_id", "dex"])[["asset_id", "chain", "dex"]].drop_duplicates() if not d.empty else pd.DataFrame(columns=["asset_id", "chain", "dex"]); multi = relations.groupby("asset_id").dex.nunique() if not relations.empty else pd.Series(dtype=int)
    lag_rows = []
    if not d.empty:
        d["bucket"] = d["trade_time"].dt.floor("5min")
        for aid, g in d.groupby("asset_id"):
            venues = sorted(g.dex.dropna().unique())
            for i, left in enumerate(venues):
                for right in venues[i + 1:]:
                    a = g[g.dex == left].groupby("bucket").price.last().rename("left"); b = g[g.dex == right].groupby("bucket").price.last().rename("right"); x = pd.concat([a, b], axis=1).dropna();
                    if len(x) < 4: continue
                    lr = x.left.pct_change(); rr = x.right.pct_change()
                    for lag in (-2, -1, 0, 1, 2):
                        corr = lr.corr(rr.shift(lag)); lag_rows.append({"asset_id": aid, "venue_a": left, "venue_b": right, "lag_5m": lag, "correlation": corr, "n_bars": len(x), "status": "EXPLORATORY" if len(x) >= 10 else "INSUFFICIENT_EVIDENCE", "join": "exact_5m_bucket"})
    lag_frame = pd.DataFrame(lag_rows); lag_frame.to_parquet(root / "artifacts/cross_dex_price_discovery.parquet", index=False)
    result = pd.DataFrame([{ "research_id": "R-D1-CROSS-DEX", "status": "EXPLORATORY" if len(lag_frame) else ("BLOCKED_BY_SAMPLE" if (multi > 1).any() else "BLOCKED_BY_DATA"), "dex_count": int(relations.dex.nunique()) if not relations.empty else 0, "token_dex_relations": len(relations), "multi_dex_assets": int((multi > 1).sum()), "price_discovery_rows": len(lag_frame), "reason": "No asset observed on multiple DEX venues in the current trade sample." if not (multi > 1).any() else ("multi-DEX identities exist but no synchronized 5m pair has enough observations." if not len(lag_frame) else "multi-DEX sample available") }]); result.to_parquet(root / "artifacts/cross_dex_results.parquet", index=False); relations.to_parquet(root / "artifacts/token_dex_relations.parquet", index=False); return result.iloc[0].to_dict()


def build_phase4_coverage(root: Path, *, wallet_obs: dict[str, Any], micro: dict[str, Any], network: dict[str, Any], lifecycle: dict[str, Any], cross_dex: dict[str, Any]) -> pd.DataFrame:
    rows = [
        {"track": "A_PARTICIPANT", "data_available": wallet_obs.get("wallet_count", 0) > 0, "sample_size": wallet_obs.get("trade_count", 0), "entity_count": wallet_obs.get("wallet_count", 0), "event_count": 0, "time_range": "sample trade window", "method_available": True, "confirmation_available": False, "current_status": "BLOCKED_BY_SAMPLE" if wallet_obs.get("status") != "PASS" else "EXPLORATORY", "blocking_reason": "wallet skill gate FAIL"},
        {"track": "B_MICROSTRUCTURE", "data_available": micro.get("trade_rows", 0) > 0, "sample_size": micro.get("trade_rows", 0), "entity_count": 0, "event_count": micro.get("impact_rows", 0), "time_range": "sample trade window", "method_available": True, "confirmation_available": False, "current_status": micro.get("status", "BLOCKED_BY_DATA"), "blocking_reason": "no pool/depth history"},
        {"track": "C_DIFFUSION", "data_available": network.get("edges", 0) > 0, "sample_size": network.get("edges", 0), "entity_count": network.get("edges", 0), "event_count": 0, "time_range": "sample trade window", "method_available": True, "confirmation_available": False, "current_status": "BLOCKED_BY_SAMPLE", "blocking_reason": "short tape and dependence risk"},
        {"track": "D_CROSS_DEX", "data_available": cross_dex.get("multi_dex_assets", 0) > 0, "sample_size": cross_dex.get("token_dex_relations", 0), "entity_count": cross_dex.get("dex_count", 0), "event_count": 0, "time_range": "sample trade window", "method_available": True, "confirmation_available": False, "current_status": cross_dex.get("status", "BLOCKED_BY_DATA"), "blocking_reason": cross_dex.get("reason", "")},
        {"track": "E_CROSS_CHAIN", "data_available": False, "sample_size": 0, "entity_count": 0, "event_count": 0, "time_range": "", "method_available": False, "confirmation_available": False, "current_status": "BLOCKED_BY_DATA", "blocking_reason": "no bridge/transfer data"},
        {"track": "F_LIFECYCLE", "data_available": lifecycle.get("assets", 0) > 0, "sample_size": lifecycle.get("assets", 0), "entity_count": lifecycle.get("assets", 0), "event_count": 0, "time_range": "first-observed sample", "method_available": True, "confirmation_available": False, "current_status": lifecycle.get("status", "BLOCKED_BY_DATA"), "blocking_reason": "first-observed age only; no launch history"},
    ]
    out = pd.DataFrame(rows); out.to_parquet(root / "artifacts/ONCHAIN_RESEARCH_COVERAGE.parquet", index=False); return out


def run_phase4_suite(root: Path) -> dict[str, Any]:
    capability = audit_onchain_capabilities(root); canonical = build_onchain_canonical(root); wallet = run_wallet_observability(root); skill = run_wallet_skill(root); micro = run_microstructure(root); network = build_temporal_network(root); lifecycle = run_lifecycle(root); cross = run_cross_dex(root); coverage = build_phase4_coverage(root, wallet_obs=wallet, micro=micro, network=network, lifecycle=lifecycle, cross_dex=cross)
    experiments = pd.DataFrame([
        {"hypothesis_id": "R-B1", "track": "B_MICROSTRUCTURE", "method": "trade_flow_observable", "status": "EXPLORATORY" if micro["trade_rows"] else "BLOCKED_BY_DATA", "n_experiments": 1},
        {"hypothesis_id": "R-B2", "track": "B_MICROSTRUCTURE", "method": "price_impact_resilience", "status": "EXPLORATORY" if micro["impact_rows"] else "BLOCKED_BY_DATA", "n_experiments": 4},
        {"hypothesis_id": "R-A1", "track": "A_PARTICIPANT", "method": "wallet_observability", "status": "EXPLORATORY" if wallet["wallet_count"] else "BLOCKED_BY_DATA", "n_experiments": 1},
        {"hypothesis_id": "R-A2", "track": "A_PARTICIPANT", "method": "skill_persistence", "status": "BLOCKED_BY_SAMPLE", "n_experiments": 0},
        {"hypothesis_id": "R-C1", "track": "C_DIFFUSION", "method": "temporal_bipartite_graph", "status": "BLOCKED_BY_SAMPLE", "n_experiments": 1},
        {"hypothesis_id": "R-D1", "track": "D_CROSS_DEX", "method": "price_discovery", "status": cross.get("status", "BLOCKED_BY_DATA"), "n_experiments": 0},
        {"hypothesis_id": "R-F1", "track": "F_LIFECYCLE", "method": "first_observed_lifecycle", "status": lifecycle["status"], "n_experiments": 2},
        {"hypothesis_id": "R-F2", "track": "F_LIFECYCLE", "method": "survival_hazard", "status": "BLOCKED_BY_SAMPLE", "n_experiments": 0},
    ])
    experiments.to_parquet(root / "artifacts/phase4_experiment_registry.parquet", index=False)
    # Apply BH only to the finite set of actually computed exploratory return
    # tests.  With this short tape, p-values are retained as exploratory and no
    # result is promoted to confirmation/OOS.
    from scipy.stats import ttest_1samp
    from ..stats.multiple_testing import benjamini_hochberg
    p_rows = []
    impact = pd.read_parquet(root / "artifacts/price_impact_results.parquet") if (root / "artifacts/price_impact_results.parquet").exists() else pd.DataFrame()
    for horizon in (1, 5, 15, 60):
        values = pd.to_numeric(impact.get(f"forward_return_{horizon}m", pd.Series(dtype=float)), errors="coerce").dropna() if not impact.empty else pd.Series(dtype=float)
        p_value = float(ttest_1samp(values, 0.0).pvalue) if len(values) >= 10 else np.nan
        p_rows.append({"family": "B_MICROSTRUCTURE", "test_id": f"trade_impact_{horizon}m", "n_observations": len(values), "raw_p_value": p_value, "status": "EXPLORATORY" if len(values) >= 10 else "INSUFFICIENT_EVIDENCE"})
    adjusted = benjamini_hochberg([x["raw_p_value"] for x in p_rows])
    for row, adj in zip(p_rows, adjusted):
        row.update({"fdr_adjusted_p_value": adj["fdr_adjusted_p_value"], "significant_q05": adj["significant_q05"], "significant_q10": adj["significant_q10"], "multiple_testing_method": "Benjamini-Hochberg"})
    pd.DataFrame(p_rows).to_parquet(root / "artifacts/phase4_multiple_testing.parquet", index=False)
    stop = ["# Phase IV data stop reason", "", "- P0 token trades: completed bounded sample; raw + canonical schema audited.", "- P1 wallet: address exists, but skill gate FAIL due single-trade concentration and short history.", "- P2 holders/top traders: holder proxy snapshots available; wallet ranking endpoint not confirmed.", "- P3/P4 pool identity and historical reserves: insufficient for pool-level impact.", "- P5 cross-DEX: no same asset observed across multiple DEX in sample.", "- P6 bridge: no bridge/transfer source.", "- P7 CEX: optional benchmark only.", "- P8/P9 execution and complex ML: deferred until depth and stable OOS structure exist."]
    (root / "docs/DATA_STOP_REASON.md").write_text("\n".join(stop) + "\n", encoding="utf-8")
    report = ["# Phase IV On-chain Native Research Report", "", "## Executive status", "", "The project now runs on-chain-native Tracks A–F independently of DEX/CEX pairing. CEX is an optional validation layer.", "", "## Participants", f"Wallet observability found {wallet['wallet_count']} wallets across {wallet['trade_count']} trades; multi-trade wallets={wallet['multi_trade_wallets']}. Wallet skill gate={wallet['status']}; skill persistence is BLOCKED_BY_SAMPLE.", "", "## Microstructure", f"Trade-derived observables={micro['observable_rows']} rows; impact rows={micro['impact_rows']}; resilience assets={micro['resilience_assets']}. Results are exploratory and not executable liquidity impact.", "", "## Diffusion", f"Temporal wallet-token edges={network['edges']}; diffusion is retained as exploratory structure but confirmation is blocked by short history/dependence risk.", "", "## Cross-DEX and cross-chain", f"Cross-DEX status={cross['status']}; DEXs={cross.get('dex_count', 0)}; token-DEx relations={cross.get('token_dex_relations', 0)}. Cross-chain migration is BLOCKED_BY_DATA without bridge transfers.", "", "## Lifecycle", f"First-observed lifecycle assets={lifecycle['assets']}; status={lifecycle['status']}. Launch time is not inferred; ages are first-observed ages only.", "", "## Multiple testing / OOS", "No Phase IV confirmation or OOS-supported result is claimed. Exploratory outputs are preserved, not selected by Sharpe.", "", "## Limitations", "The sample is a bounded trade-page probe. USD notional, pools, reserves, LP state, bridge flow and long history are incomplete. No complex ML was trained."]
    (root / "reports/ONCHAIN_RESEARCH_REPORT.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    return {"capability": capability, "canonical": canonical, "wallet": wallet, "skill_rows": len(skill), "microstructure": micro, "network": network, "lifecycle": lifecycle, "cross_dex": cross, "coverage_rows": len(coverage), "hypotheses": int(len(experiments)), "experiments": int(experiments.n_experiments.sum())}
