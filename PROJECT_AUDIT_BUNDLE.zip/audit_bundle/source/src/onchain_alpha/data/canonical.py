from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from ..ontology import ensure_pit_columns


def _asset_id(chain: Any, token: Any) -> str:
    return f"{str(chain)}:{str(token).lower()}"


def build_dim_asset(universe: pd.DataFrame) -> pd.DataFrame:
    if universe.empty:
        return pd.DataFrame(columns=["asset_id", "chain", "token_address", "symbol", "decimals", "native_wrapped", "canonical_asset_id", "first_observed_time", "last_observed_time", "source"])
    out = pd.DataFrame({
        "asset_id": [_asset_id(c, a) for c, a in zip(universe["chain"], universe["token_address"])],
        "chain": universe["chain"].astype(str), "token_address": universe["token_address"].astype(str),
        "symbol": universe.get("symbol", pd.Series(index=universe.index, dtype=str)), "decimals": pd.NA,
        "native_wrapped": pd.NA, "canonical_asset_id": pd.NA,
        "first_observed_time": pd.to_datetime(universe.get("first_seen"), utc=True, errors="coerce"),
        "last_observed_time": pd.to_datetime(universe.get("last_seen"), utc=True, errors="coerce"),
        "source": universe.get("discovery_source", "real_api"),
    })
    return out.drop_duplicates("asset_id").reset_index(drop=True)


def build_fact_token_market_state(observations: pd.DataFrame) -> pd.DataFrame:
    if observations.empty:
        return pd.DataFrame()
    out = observations.copy()
    out["asset_id"] = [_asset_id(c, a) for c, a in zip(out["chain"], out["token_address"])]
    out["event_time"] = pd.to_datetime(out.get("event_time"), utc=True, errors="coerce")
    out["observed_time"] = pd.to_datetime(out.get("observed_at"), utc=True, errors="coerce")
    out["available_time"] = pd.to_datetime(out.get("known_at", out["observed_time"]), utc=True, errors="coerce")
    out["ingest_time"] = pd.to_datetime(out.get("ingested_at", out["observed_time"]), utc=True, errors="coerce")
    out = ensure_pit_columns(out)
    keep = ["asset_id", "chain", "token_address", "symbol", "event_time", "observed_time", "available_time", "ingest_time", "price", "volume", "liquidity", "market_cap", "holders", "tx_count", "buy_volume", "sell_volume", "smart_money_holding_percent", "top10_holding_percent"]
    return out[[c for c in keep if c in out.columns]].sort_values(["asset_id", "event_time"], na_position="last").reset_index(drop=True)


def build_events_table(events: pd.DataFrame) -> pd.DataFrame:
    cols = ["event_id", "event_type", "entity_type", "entity_id", "asset_id", "chain", "event_time", "observed_time", "available_time", "detection_time", "event_strength", "direction", "metadata", "detector_version", "source"]
    if events.empty:
        return pd.DataFrame(columns=cols)
    out = events.copy()
    for col in cols:
        if col not in out:
            out[col] = pd.NA
    return ensure_pit_columns(out[cols])


def build_canonical_tables(root: Path) -> dict[str, pd.DataFrame]:
    def read(name: str) -> pd.DataFrame:
        for path in (root / "data" / "gold" / f"{name}.parquet", root / "data" / "silver" / f"{name}.parquet"):
            if path.exists():
                return pd.read_parquet(path)
        return pd.DataFrame()
    universe, observations = read("universe"), read("market_observations")
    tables = {"dim_asset": build_dim_asset(universe), "fact_token_market_state": build_fact_token_market_state(observations)}
    canonical_dir = root / "data" / "gold" / "canonical"
    canonical_dir.mkdir(parents=True, exist_ok=True)
    for name, table in tables.items():
        table.to_parquet(canonical_dir / f"{name}.parquet", index=False)
    return tables
