from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Iterable

import pandas as pd
import yaml


CAPABILITY_COLUMNS = [
    "source", "api_family", "endpoint", "method", "entity_type", "data_type",
    "historical_or_snapshot", "historical_depth", "pagination", "max_page_size",
    "rate_limit", "required_parameters", "chains_supported", "current_key_access",
    "probe_status", "sample_response_available", "research_value", "data_quality_risk",
]


def _json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _classify_table(table: str) -> tuple[str, str, str]:
    lower = table.lower()
    if lower == "candles":
        return "web3_local_smoke", "candles", "1m candle-like DEX token data"
    if lower == "trades":
        return "web3_local_smoke", "trades", "DEX token trades"
    if lower == "quotes":
        return "web3_local_smoke", "quotes", "DEX aggregator quote observations"
    if lower == "market_state":
        return "web3_local_smoke", "market_state", "DEX token market snapshot"
    return "web3_local_smoke", lower, "local research metadata"


def _sqlite_inventory(path: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    with sqlite3.connect(path) as conn:
        tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        for table in tables:
            source, data_type, description = _classify_table(table)
            info = conn.execute(f'PRAGMA table_info("{table}")').fetchall()
            schema = ", ".join(f"{item[1]}:{item[2]}" for item in info)
            count = int(conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0])
            time_candidates = [c[1] for c in info if any(x in c[1].lower() for x in ("time", "ts", "at"))]
            time_col = next((c for c in ("candle_ts_ms", "trade_ts_ms", "observed_at_ms", "requested_at_ms") if c in time_candidates), None)
            start = end = None
            if time_col and count:
                start, end = conn.execute(f'SELECT MIN("{time_col}"), MAX("{time_col}") FROM "{table}"').fetchone()
            duplicate = 0.0
            if count and table in {"candles", "trades", "market_state"}:
                key_cols = [c for c in ("chain", "token", "candle_ts_ms", "trade_ts_ms", "observed_at_ms") if c in time_candidates or c in [x[1] for x in info]]
                if key_cols:
                    duplicate = float(conn.execute(f'SELECT COALESCE(SUM(cnt - 1), 0) FROM (SELECT COUNT(*) cnt FROM "{table}" GROUP BY {",".join(key_cols)} HAVING cnt > 1)').fetchone()[0] or 0) / count
            rows.append({
                "path": str(path.resolve()), "data_type": data_type, "market": source,
                "symbol": "", "start_time": pd.to_datetime(start, unit="ms", utc=True).isoformat() if start else "",
                "end_time": pd.to_datetime(end, unit="ms", utc=True).isoformat() if end else "",
                "frequency": "1m" if table == "candles" else "snapshot/event",
                "rows": count, "size": path.stat().st_size, "schema": schema,
                "missingness": "not computed for SQLite source inventory", "duplicate_rate": round(duplicate, 8),
                "usable_status": "REUSABLE_LOCAL_WEB3_NOT_CEX" if count else "EMPTY",
                "notes": description,
            })
    return rows


def _candidate_files(roots: Iterable[Path]) -> list[Path]:
    allowed = {".db", ".sqlite", ".duckdb", ".parquet", ".csv", ".jsonl", ".feather"}
    skip_parts = {".venv", "__pycache__", ".git", "audit_bundle", "bronze", ".pytest_cache"}
    found: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in allowed or any(part in skip_parts for part in path.parts):
                continue
            name = path.name.lower()
            if path.suffix.lower() in {".db", ".sqlite", ".duckdb"} or any(token in name for token in ("candle", "kline", "funding", "interest", "premium", "mark", "depth", "trade", "quote", "market", "spot", "future", "binance")):
                found.append(path)
    return sorted(set(found))


def build_cex_inventory(root: Path, search_roots: Iterable[Path] | None = None) -> pd.DataFrame:
    roots = list(search_roots or (root, root.parent, root.parent / "alpha-lab-os", root.parent / "web3-arb-lab"))
    rows: list[dict[str, object]] = []
    for path in _candidate_files(roots):
        if path.suffix.lower() in {".db", ".sqlite"}:
            rows.extend(_sqlite_inventory(path))
        else:
            rows.append({"path": str(path.resolve()), "data_type": "unknown", "market": "unknown", "symbol": "", "start_time": "", "end_time": "", "frequency": "", "rows": "", "size": path.stat().st_size, "schema": "not inspected", "missingness": "not inspected", "duplicate_rate": "", "usable_status": "REVIEW_REQUIRED", "notes": "candidate local file; no automatic copy or overwrite"})
    if not rows:
        rows.append({"path": "", "data_type": "", "market": "CEX", "symbol": "", "start_time": "", "end_time": "", "frequency": "", "rows": 0, "size": 0, "schema": "", "missingness": "", "duplicate_rate": "", "usable_status": "NO_LOCAL_CEX_DATA_FOUND", "notes": "No local Binance Spot/Futures historical file was found in the project or reasonable parent directories."})
    out = pd.DataFrame(rows)
    out.to_csv(root / "artifacts" / "CEX_DATA_INVENTORY.csv", index=False)
    return out


def _web3_matrix_rows(root: Path) -> list[dict[str, object]]:
    path = root / "artifacts" / "api_capabilities.json"
    if not path.exists():
        return []
    report = json.loads(path.read_text(encoding="utf-8"))
    chains = ",".join(str(x) for x in report.get("client_metrics", {}).get("chains", []))
    rows = []
    for item in report.get("endpoints", []):
        status = str(item.get("probe_status", "UNKNOWN"))
        rows.append({
            "source": "Binance Web3", "api_family": "Web3 DEX market", "endpoint": item.get("endpoint", ""), "method": item.get("method", ""),
            "entity_type": "token", "data_type": "market/flow/ranking", "historical_or_snapshot": "historical" if "candle" in str(item.get("endpoint", "")) else "snapshot",
            "historical_depth": "API-returned candles; exact depth recorded in samples" if "candle" in str(item.get("endpoint", "")) else "snapshot only",
            "pagination": _json(item.get("pagination", "unknown")), "max_page_size": item.get("required_params", "unknown"),
            "rate_limit": _json(item.get("rate_limit_headers", {})), "required_parameters": _json(item.get("required_params", [])),
            "chains_supported": item.get("chain", chains), "current_key_access": status == "ACCESSIBLE_WITH_CURRENT_KEY", "probe_status": "ACCESSIBLE" if status == "ACCESSIBLE_WITH_CURRENT_KEY" else status,
            "sample_response_available": bool(item.get("fields")), "research_value": "market backbone, event detection, lead-lag, state conditioning" if "candle" in str(item.get("endpoint", "")) or "price" in str(item.get("endpoint", "")) else "liquidity/holder proxy enrichment",
            "data_quality_risk": "current ranking selection, snapshot availability, endpoint-specific coverage",
        })
    for item in report.get("endpoint_inventory", []):
        if item.get("status") == "NOT_PROBED":
            rows.append({
                "source": "Binance Web3", "api_family": "Web3 analytics", "endpoint": item.get("candidate_endpoint", ""), "method": item.get("method", ""), "entity_type": "wallet/entity", "data_type": item.get("capability", ""), "historical_or_snapshot": "unknown", "historical_depth": "unknown", "pagination": "unknown", "max_page_size": "unknown", "rate_limit": "unknown", "required_parameters": "unknown", "chains_supported": "unknown", "current_key_access": "unknown", "probe_status": "DOCUMENTED_NOT_PROBED", "sample_response_available": False, "research_value": "wallet/entity/network research", "data_quality_risk": str(item.get("reason", "unknown")),
            })
    return rows


def _documented_cex_rows() -> list[dict[str, object]]:
    docs = "https://developers.binance.com/en/docs/catalog"
    definitions = [
        ("Spot", "https://data-api.binance.vision/api/v3/klines", "GET", "instrument", "OHLCV", "historical market backbone", "Spot public market-data docs; not probed with Web3 key"),
        ("Spot", "https://data-api.binance.vision/api/v3/aggTrades", "GET", "instrument", "aggregate trades", "historical market backbone / flow", "Spot public market-data docs; not probed with Web3 key"),
        ("Spot", "https://data-api.binance.vision/api/v3/depth", "GET", "instrument", "order book", "market structure / execution", "Spot public market-data docs; not probed with Web3 key"),
        ("USDⓈ-M Futures", "https://fapi.binance.com/fapi/v1/klines", "GET", "instrument", "OHLCV", "perpetual market backbone", "Futures public market-data docs; not probed"),
        ("USDⓈ-M Futures", "https://fapi.binance.com/fapi/v1/fundingRate", "GET", "instrument", "funding", "state dependence / relative value", "Futures docs; not probed"),
        ("USDⓈ-M Futures", "https://fapi.binance.com/futures/data/openInterestHist", "GET", "instrument", "open interest", "state dependence / crowding", "Futures docs; latest historical depth is endpoint-specific"),
        ("USDⓈ-M Futures", "https://fapi.binance.com/fapi/v1/premiumIndex", "GET", "instrument", "mark/index/funding snapshot", "price discovery / relative value", "Futures docs; not probed"),
        ("COIN-M Futures", "https://dapi.binance.com/dapi/v1/fundingRate", "GET", "instrument", "funding", "state dependence / relative value", "Official COIN-M docs; not probed"),
        ("COIN-M Futures", "https://dapi.binance.com/dapi/v1/premiumIndexKlines", "GET", "instrument", "premium index candles", "price discovery / relative value", "Official COIN-M docs; not probed"),
    ]
    return [{"source": "Binance official docs", "api_family": family, "endpoint": endpoint, "method": method, "entity_type": entity, "data_type": data_type, "historical_or_snapshot": "historical", "historical_depth": "documented endpoint-specific", "pagination": "startTime/endTime/limit where documented", "max_page_size": "documented endpoint-specific", "rate_limit": "documented request weight", "required_parameters": "symbol or pair; interval for klines", "chains_supported": "CEX", "current_key_access": "unknown", "probe_status": "DOCUMENTED_NOT_PROBED", "sample_response_available": True, "research_value": value, "data_quality_risk": note + "; local file inventory found no historical CEX file"} for family, endpoint, method, entity, data_type, value, note in definitions]


def build_api_capability_matrix(root: Path) -> pd.DataFrame:
    rows = _web3_matrix_rows(root) + _documented_cex_rows()
    out = pd.DataFrame(rows, columns=CAPABILITY_COLUMNS)
    for column in CAPABILITY_COLUMNS:
        out[column] = out[column].map(lambda value: _json(value) if isinstance(value, (list, dict, tuple)) else value)
        if out[column].dtype == "object":
            out[column] = out[column].fillna("").astype(str)
    out.to_parquet(root / "data" / "API_CAPABILITY_MATRIX.parquet", index=False)
    lines = ["# API Capability Matrix", "", "Generated from the fresh read-only Web3 capability report plus official Binance market-data documentation. No speculative endpoint was called.", "", "Status values: `ACCESSIBLE`, `DOCUMENTED_NOT_PROBED`, `PERMISSION_DENIED`, `INVALID_TEST_PARAMS`, `UNSUPPORTED`, `DEPRECATED`, `UNKNOWN`.", "", "| source | api_family | endpoint | method | entity_type | data_type | historical_or_snapshot | current_key_access | probe_status | research_value |", "|---|---|---|---|---|---|---|---|---|---|"]
    for row in out.to_dict("records"):
        lines.append("| " + " | ".join(str(row.get(k, "")).replace("|", "\\|") for k in ("source", "api_family", "endpoint", "method", "entity_type", "data_type", "historical_or_snapshot", "current_key_access", "probe_status", "research_value")) + " |")
    lines.extend(["", "## Interpretation", "", "Web3 market/ranking endpoints were probed with the current key. Official Spot and Futures market-data endpoints are documented but intentionally not probed with the Web3 credential; no CEX permission is inferred. Wallet/entity capabilities remain `DOCUMENTED_NOT_PROBED`/`UNKNOWN` because no public endpoint was confirmed in the current Web3 catalog."])
    (root / "docs" / "API_CAPABILITY_MATRIX.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out


def build_api_run_stats(root: Path) -> pd.DataFrame:
    caps = json.loads((root / "artifacts" / "api_capabilities.json").read_text(encoding="utf-8")) if (root / "artifacts" / "api_capabilities.json").exists() else {}
    audit = json.loads((root / "artifacts" / "collection_audit.json").read_text(encoding="utf-8")) if (root / "artifacts" / "collection_audit.json").exists() else {}
    metrics = caps.get("client_metrics", {})
    latencies = [float(x) for x in metrics.get("latencies_ms", []) if x is not None]
    requests = audit.get("requests", [])
    row = {
        "run_id": str(audit.get("run_id", caps.get("generated_at", "phase2"))), "source": "Binance Web3", "request_count": int(len(requests) or metrics.get("requests", 0)),
        "successful_requests": int(sum(1 for x in requests if int(x.get("http_status", 0) or 0) == 200 and int(x.get("business_code", 0) or 0) == 0) or metrics.get("successes", 0)),
        "http_429": int(sum(1 for x in requests if int(x.get("http_status", 0) or 0) == 429) or metrics.get("429", 0)),
        "http_4xx": int(sum(1 for x in requests if 400 <= int(x.get("http_status", 0) or 0) < 500)), "http_5xx": int(sum(1 for x in requests if int(x.get("http_status", 0) or 0) >= 500)),
        "retry_count": int(sum(int(x.get("retry_count", 0) or 0) for x in requests)), "latency_p50_ms": float(pd.Series(latencies).quantile(.5)) if latencies else None, "latency_p95_ms": float(pd.Series(latencies).quantile(.95)) if latencies else None,
        "bytes_received": None, "estimated_remaining_workload": "Stage B pilot complete; Stage C requires explicit budget approval", "qps_target": 40.0, "status": "COMPLETED_READ_ONLY",
    }
    out = pd.DataFrame([row]); out.to_parquet(root / "artifacts" / "API_RUN_STATS.parquet", index=False); return out


def build_pit_universe(root: Path) -> pd.DataFrame:
    path = root / "data" / "gold" / "canonical" / "fact_token_market_state.parquet"
    state = pd.read_parquet(path) if path.exists() else pd.DataFrame()
    if state.empty:
        out = pd.DataFrame(columns=["timestamp", "asset_id", "eligible", "reason", "liquidity_at_time", "age_at_time", "data_available_at_time", "universe_type", "source"])
    else:
        out = state[["event_time", "asset_id", "liquidity", "available_time"]].copy().rename(columns={"event_time": "timestamp", "liquidity": "liquidity_at_time", "available_time": "data_available_at_time"})
        out["eligible"] = state["price"].notna().to_numpy()
        out["reason"] = out["eligible"].map({True: "observed_market_state", False: "missing_price"})
        out["age_at_time"] = pd.NA
        out["universe_type"] = "CURRENT_UNIVERSE_BACKFILL"
        out["source"] = "Binance Web3 observed market panel"
        out = out.drop_duplicates(["timestamp", "asset_id"]).sort_values(["timestamp", "asset_id"]).reset_index(drop=True)
    out.to_parquet(root / "data" / "gold" / "canonical" / "universe_snapshot.parquet", index=False)
    return out


def build_research_agenda(root: Path) -> pd.DataFrame:
    path = root / "configs" / "research_agenda.yaml"
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) if path.exists() else {}
    rows = []
    for family, spec in (raw.get("families", {}) or {}).items():
        for hypothesis_id in spec.get("hypotheses", []):
            rows.append({"family": family, "hypothesis_id": hypothesis_id, "status": spec.get("status", "NOT_RUN"), "priority_dimensions": _json(spec.get("priority_dimensions", [])), "economic_plausibility": "UNSCORED", "data_availability": "UNSCORED", "data_uniqueness": "UNSCORED", "sample_size": "UNSCORED", "expected_persistence": "UNSCORED", "execution_feasibility": "UNSCORED", "research_cost": "UNSCORED", "crowdedness_risk": "UNSCORED"})
    out = pd.DataFrame(rows); out.to_parquet(root / "artifacts/research_agenda.parquet", index=False); return out
