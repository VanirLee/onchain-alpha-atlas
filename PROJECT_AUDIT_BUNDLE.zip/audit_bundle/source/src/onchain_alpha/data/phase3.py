"""Phase III data-first backbone.

The module deliberately keeps the Phase II research engines untouched.  It adds
read-only CEX acquisition, local-data inventory, conservative identity mapping,
trade normalization, synchronization, and explicit data-quality gates.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

import httpx
import numpy as np
import pandas as pd

from ..connectors.binance_web3 import TRADES, BinanceWeb3Client
from ..config import Settings


UTC = "UTC"
CE_URLS = {
    "spot": "https://api.binance.com",
    "um": "https://fapi.binance.com",
}
CE_ENDPOINTS = {
    "spot_klines": ("spot", "/api/v3/klines"),
    "um_klines": ("um", "/fapi/v1/klines"),
    "um_mark_klines": ("um", "/fapi/v1/markPriceKlines"),
    "um_index_klines": ("um", "/fapi/v1/indexPriceKlines"),
    "um_premium_klines": ("um", "/fapi/v1/premiumIndexKlines"),
    "um_funding": ("um", "/fapi/v1/fundingRate"),
    "um_oi_hist": ("um", "/futures/data/openInterestHist"),
}
TRADE_SCHEMA = [
    "trade_id", "asset_id", "chain", "token_address", "trade_time", "available_time",
    "side", "side_sign", "token_quantity", "paired_token_contract", "paired_token_symbol",
    "paired_token_quantity", "quantity", "usd_value", "price", "tx_hash", "dex", "pool",
    "wallet_id", "source", "schema_diagnostic", "raw_json",
]
SYNC_SCHEMA = ["timestamp", "asset_id", "chain", "token_address", "spot_price", "spot_return", "spot_volume", "perp_price", "perp_return", "perp_volume", "mark_price", "index_price", "premium", "funding_rate", "open_interest", "dex_price", "dex_return", "dex_volume", "dex_buy_flow", "dex_sell_flow", "dex_net_flow", "dex_trade_count", "dex_vwap", "dex_source", "available_time", "match_delay_seconds", "source_status"]


def _utc(value: Any) -> pd.Timestamp:
    return pd.to_datetime(value, utc=True, errors="coerce")


def _safe_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _hash(value: Any) -> str:
    return hashlib.sha256(_safe_json(value).encode()).hexdigest()


def _empty(columns: Iterable[str]) -> pd.DataFrame:
    return pd.DataFrame({c: pd.Series(dtype="object") for c in columns})


def _first_present(item: dict[str, Any], *keys: str) -> Any:
    return next((item[k] for k in keys if item.get(k) not in (None, "")), None)


def _changed_token_fields(item: dict[str, Any], queried_token: str) -> dict[str, Any]:
    """Parse the two-leg trade payload without assigning USD semantics to token amount."""
    legs = item.get("changedTokenInfo")
    if not isinstance(legs, list):
        return {"token_quantity": np.nan, "paired_token_contract": None, "paired_token_symbol": None, "paired_token_quantity": np.nan}
    queried = str(queried_token).lower()
    target = next((x for x in legs if isinstance(x, dict) and str(x.get("tokenContractAddress", "")).lower() == queried), None)
    paired = next((x for x in legs if isinstance(x, dict) and x is not target), None)
    return {
        "token_quantity": pd.to_numeric(target.get("amount"), errors="coerce") if target else np.nan,
        "paired_token_contract": paired.get("tokenContractAddress") if paired else None,
        "paired_token_symbol": paired.get("tokenSymbol") if paired else None,
        "paired_token_quantity": pd.to_numeric(paired.get("amount"), errors="coerce") if paired else np.nan,
    }


def normalize_web3_trade(item: dict[str, Any], *, chain: Any, token_address: Any, available_time: Any, row_number: int = 0) -> dict[str, Any]:
    """Normalize the official Web3 token-trades schema.

    The documented `volume` is USD trade amount. Token quantity comes only from
    changedTokenInfo for the queried contract; it is never reconstructed as
    volume * price. `type` is an exact buy/sell enum.
    """
    chain_s, token_s = str(chain), str(token_address)
    event = _first_present(item, "time", "timestamp", "eventTime", "tradeTime", "blockTime")
    event_ts = pd.to_datetime(event, unit="ms", utc=True, errors="coerce") if event is not None else pd.NaT
    raw_side = str(item.get("type", "")).strip().lower()
    side = raw_side if raw_side in {"buy", "sell"} else "UNKNOWN"
    side_sign = 1 if raw_side == "buy" else -1 if raw_side == "sell" else np.nan
    fields = _changed_token_fields(item, token_s)
    tx_hash = _first_present(item, "txHash", "transactionHash")
    identity = {
        "chain": chain_s, "tx_hash": tx_hash, "wallet": item.get("userAddress"),
        "token": token_s, "side": side, "event_time": event_ts.isoformat() if not pd.isna(event_ts) else None,
        "token_quantity": fields["token_quantity"], "paired_token": fields["paired_token_contract"],
        "paired_quantity": fields["paired_token_quantity"],
    }
    trade_id = _hash(identity)
    return {
        "trade_id": trade_id,
        "asset_id": f"{chain_s}:{token_s.lower() if token_s.startswith(('0x', '0X')) else token_s}",
        "chain": chain_s, "token_address": token_s, "trade_time": event_ts,
        "available_time": _utc(available_time), "side": side, "side_sign": side_sign,
        "token_quantity": fields["token_quantity"], "paired_token_contract": fields["paired_token_contract"],
        "paired_token_symbol": fields["paired_token_symbol"], "paired_token_quantity": fields["paired_token_quantity"],
        "quantity": fields["token_quantity"],  # legacy alias; semantic meaning is token quantity
        "usd_value": pd.to_numeric(item.get("volume"), errors="coerce"),
        "price": pd.to_numeric(_first_present(item, "price", "priceUsd"), errors="coerce"),
        "tx_hash": tx_hash, "dex": item.get("dexName"), "pool": _first_present(item, "pool", "pair", "poolAddress"),
        "wallet_id": item.get("userAddress"), "source": "BINANCE_WEB3_TRADES",
        "schema_diagnostic": "UNKNOWN_SIDE" if side == "UNKNOWN" else "OK", "raw_json": _safe_json(item),
    }


def _file_candidates(roots: Iterable[Path]) -> list[Path]:
    exts = {".parquet", ".csv", ".json", ".jsonl", ".db", ".sqlite", ".duckdb", ".feather"}
    skip = {".venv", "__pycache__", ".git", ".pytest_cache", "audit_bundle", "bronze"}
    out: set[Path] = set()
    for root in roots:
        if not root.exists():
            continue
        for p in root.rglob("*"):
            if p.is_file() and p.suffix.lower() in exts and not any(x in skip for x in p.parts):
                out.add(p.resolve())
    return sorted(out)


def _wide_parquet_metadata(path: Path) -> dict[str, Any]:
    try:
        frame = pd.read_parquet(path)
        rows, cols = len(frame), list(frame.columns)
        time_col = next((c for c in cols if str(c).lower() in {"opentime", "open_time", "timestamp", "time", "date"}), None)
        times = _utc(frame[time_col]) if time_col else pd.Series(dtype="datetime64[ns, UTC]")
        symbols = [str(c) for c in cols if str(c).upper().endswith(("USDT", "USDC", "BUSD"))]
        missing = float(frame.isna().mean().mean()) if rows else 0.0
        duplicate = float(frame[time_col].duplicated().mean()) if time_col and rows else 0.0
        name = path.name.lower()
        dtype = "spot_ohlcv" if "kline" in name or "close" in name or "volume" in name else "unknown"
        market = "CEX" if symbols else "unknown"
        return {"absolute_path": str(path), "source": "local_existing", "market_type": market, "data_type": dtype, "symbol": ",".join(symbols[:40]), "interval": "1h" if time_col else "", "start_time": times.min().isoformat() if not times.empty else "", "end_time": times.max().isoformat() if not times.empty else "", "rows": rows, "columns": len(cols), "size_bytes": path.stat().st_size, "schema": _safe_json({str(c): str(frame[c].dtype) for c in cols[:80]}), "duplicate_rate": duplicate, "missing_rate": missing, "timestamp_type": "datetime64[ns, UTC]" if time_col else "unknown", "usable": bool(rows and symbols), "reason": "Existing wide Binance-like CEX panel; reused read-only" if rows and symbols else "Inspected candidate"}
    except Exception as exc:
        return {"absolute_path": str(path), "source": "local_existing", "market_type": "unknown", "data_type": "unreadable", "symbol": "", "interval": "", "start_time": "", "end_time": "", "rows": 0, "columns": 0, "size_bytes": path.stat().st_size, "schema": "", "duplicate_rate": np.nan, "missing_rate": np.nan, "timestamp_type": "unknown", "usable": False, "reason": f"read failed: {type(exc).__name__}"}


def _sqlite_metadata(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    try:
        with sqlite3.connect(path) as con:
            tables = [x[0] for x in con.execute("select name from sqlite_master where type='table'")]
            for table in tables:
                info = con.execute(f'pragma table_info("{table}")').fetchall()
                cols = [x[1] for x in info]
                n = int(con.execute(f'select count(*) from "{table}"').fetchone()[0])
                time_col = next((c for c in cols if any(k in c.lower() for k in ("time", "ts", "at"))), None)
                vals = con.execute(f'select min("{time_col}"), max("{time_col}") from "{table}"').fetchone() if time_col and n else (None, None)
                rows.append({"absolute_path": str(path), "source": "local_existing", "market_type": "WEB3_LOCAL" if table in {"candles", "trades", "quotes", "market_state"} else "unknown", "data_type": table, "symbol": "", "interval": "1m" if table == "candles" else "", "start_time": _utc(vals[0]).isoformat() if vals[0] is not None else "", "end_time": _utc(vals[1]).isoformat() if vals[1] is not None else "", "rows": n, "columns": len(cols), "size_bytes": path.stat().st_size, "schema": _safe_json({x[1]: x[2] for x in info}), "duplicate_rate": np.nan, "missing_rate": np.nan, "timestamp_type": "numeric_or_text", "usable": False, "reason": "Existing local SQLite; not a Binance CEX panel"})
    except Exception:
        return []
    return rows


def build_local_data_catalog(root: Path, search_roots: Iterable[Path] | None = None) -> pd.DataFrame:
    (root / "artifacts").mkdir(parents=True, exist_ok=True)
    (root / "docs").mkdir(parents=True, exist_ok=True)
    # Keep the scan bounded to the project and known related research projects;
    # never recursively crawl an entire home/Desktop tree.
    desktop = root.parent.parent
    roots = list(search_roots or [root, root.parent, desktop / "AlphaLabOS", desktop / "alpha-lab-os", desktop / "web3-arb-lab"])
    rows: list[dict[str, Any]] = []
    for path in _file_candidates(roots):
        if path.suffix.lower() in {".db", ".sqlite"}:
            rows.extend(_sqlite_metadata(path))
        elif path.suffix.lower() == ".parquet":
            rows.append(_wide_parquet_metadata(path))
        else:
            rows.append({"absolute_path": str(path), "source": "local_existing", "market_type": "unknown", "data_type": "candidate", "symbol": "", "interval": "", "start_time": "", "end_time": "", "rows": np.nan, "columns": np.nan, "size_bytes": path.stat().st_size, "schema": "not loaded", "duplicate_rate": np.nan, "missing_rate": np.nan, "timestamp_type": "unknown", "usable": False, "reason": "Candidate file catalogued without mutation"})
    out = pd.DataFrame(rows).drop_duplicates(["absolute_path", "data_type", "symbol"], keep="first")
    if out.empty:
        out = pd.DataFrame(columns=["absolute_path", "source", "market_type", "data_type", "symbol", "interval", "start_time", "end_time", "rows", "columns", "size_bytes", "schema", "duplicate_rate", "missing_rate", "timestamp_type", "usable", "reason"])
    out.to_parquet(root / "artifacts" / "LOCAL_DATA_CATALOG.parquet", index=False)
    usable = out[out["usable"] == True] if "usable" in out else out.iloc[0:0]
    lines = ["# Local data catalog", "", "Generated by `inventory-local-data`. Existing files were read only; none was overwritten, deleted, renamed, or moved.", "", f"- Files/catalog records: **{len(out)}**", f"- Reusable CEX records: **{len(usable[usable['market_type'].astype(str).str.contains('CEX')]) if len(usable) else 0}**", "", "| Path | market | type | interval | rows | start | end | usable | reason |", "|---|---|---|---:|---:|---|---|---|---|"]
    for _, r in out.iterrows():
        lines.append(f"| `{r['absolute_path']}` | {r['market_type']} | {r['data_type']} | {r['interval']} | {r['rows']} | {r['start_time']} | {r['end_time']} | {r['usable']} | {str(r['reason']).replace('|', '/')} |")
    (root / "docs" / "LOCAL_DATA_CATALOG.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out


def _symbols_from_catalog(catalog: pd.DataFrame) -> set[str]:
    syms: set[str] = set()
    for value in catalog.get("symbol", []):
        for s in str(value).split(","):
            if s.endswith("USDT") and s not in {"nan", ""}:
                syms.add(s)
    return syms


def build_acquisition_plan(root: Path, symbols: Iterable[str] | None = None, days: int = 7, interval: str = "5m") -> pd.DataFrame:
    catalog = pd.read_parquet(root / "artifacts" / "LOCAL_DATA_CATALOG.parquet") if (root / "artifacts/LOCAL_DATA_CATALOG.parquet").exists() else pd.DataFrame()
    syms = list(symbols or ["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT"])
    end = datetime.now(timezone.utc).replace(second=0, microsecond=0)
    start = end - timedelta(days=days)
    rows = []
    for symbol in syms:
        for endpoint in ("spot_klines", "um_klines", "um_mark_klines", "um_index_klines", "um_premium_klines", "um_funding", "um_oi_hist"):
            rows.append({"source": "Binance public CEX", "endpoint": endpoint, "asset": symbol, "time_start": start.isoformat(), "time_end": end.isoformat(), "interval": interval, "expected_requests": max(1, int(days * 24 * 60 / (5 if interval == "5m" else 60) / 1000) + 1), "priority": "PILOT", "status": "PLANNED", "estimated_bytes": 0, "local_reuse_available": bool(symbol in _symbols_from_catalog(catalog))})
    out = pd.DataFrame(rows)
    out.to_parquet(root / "artifacts" / "ACQUISITION_PLAN.parquet", index=False)
    return out


def build_phase3_api_inventory(root: Path) -> pd.DataFrame:
    """Materialize the official read-only inventory and measured probe status."""
    rows = []
    official = "https://developers.binance.com/en/docs/catalog"
    measured = pd.read_parquet(root / "artifacts/PHASE3_API_RUN_STATS.parquet") if (root / "artifacts/PHASE3_API_RUN_STATS.parquet").exists() else pd.DataFrame()
    for name, (venue, path) in CE_ENDPOINTS.items():
        endpoint_rows = measured[measured.get("endpoint", pd.Series(dtype=object)).astype(str).isin([path, name])] if not measured.empty else pd.DataFrame()
        statuses = set(endpoint_rows.get("status", pd.Series(dtype=object)).astype(str))
        if "CHECKPOINT_REUSED" in statuses:
            probe_status, notes = "ACCESSIBLE_WITH_CURRENT_KEY", "Successful raw response exists; this run reused the checkpoint."
        elif "200" in statuses:
            probe_status, notes = "ACCESSIBLE_WITH_CURRENT_KEY", "Successful public read-only response observed."
        elif statuses:
            probe_status, notes = "FAILED_PARAMS", "Endpoint responded with HTTP 400 in the safe pilot parameters; parameter schema needs a dedicated probe."
        else:
            probe_status, notes = "NOT_PROBED", "No response recorded."
        rows.append({"product": "Binance CEX", "capability": name, "endpoint": path, "method": "GET", "documentation_status": "DOCUMENTED", "probe_status": probe_status, "source": official, "read_only": True, "notes": notes})
    requested = ["holders ranking", "top traders", "token trades", "address portfolio overview", "address recent PnL", "address token PnL", "address DEX trade history", "leaderboard", "tracked trades", "address balances", "transactions by address"]
    existing = root / "artifacts/api_capabilities.json"
    for capability in requested:
        matched = []
        if existing.exists():
            report = json.loads(existing.read_text(encoding="utf-8")); matched = [x for x in report.get("endpoint_inventory", []) if x.get("capability") == capability]
        item = matched[0] if matched else {}
        rows.append({"product": "Binance Web3", "capability": capability, "endpoint": item.get("candidate_endpoint", ""), "method": item.get("method", ""), "documentation_status": item.get("documentation_status", "NOT_FOUND_IN_OFFICIAL_PUBLIC_CATALOG"), "probe_status": item.get("status", "NOT_PROBED"), "source": item.get("source", official), "read_only": True, "notes": item.get("reason", "No speculative endpoint was called.")})
    out = pd.DataFrame(rows); out.to_parquet(root / "artifacts/PHASE3_API_INVENTORY.parquet", index=False)
    lines = ["# Phase III API inventory", "", "Only read-only endpoints are listed. Web3 capabilities without a documented path are marked NOT_PROBED; no guessed URL was called.", "", "| Product | Capability | Endpoint | Documentation | Probe |", "|---|---|---|---|---|"]
    for _, x in out.iterrows():
        lines.append(f"| {x.product} | {x.capability} | `{x.endpoint}` | {x.documentation_status} | {x.probe_status} |")
    (root / "docs/PHASE3_API_INVENTORY.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out


@dataclass
class BinanceCEXReadOnly:
    qps: float = 8.0
    timeout: float = 20.0

    def __post_init__(self) -> None:
        self.client = httpx.Client(timeout=self.timeout, follow_redirects=False)
        self.last_request = 0.0
        self.stats: list[dict[str, Any]] = []

    def close(self) -> None:
        self.client.close()

    def get(self, endpoint: str, params: dict[str, Any]) -> Any:
        if endpoint not in CE_ENDPOINTS:
            raise ValueError(f"endpoint is not read-only allowlisted: {endpoint}")
        venue, path = CE_ENDPOINTS[endpoint]
        wait = (1.0 / self.qps) - (time.monotonic() - self.last_request)
        if wait > 0:
            time.sleep(wait)
        started = time.perf_counter()
        response = self.client.get(CE_URLS[venue] + path, params=params)
        self.last_request = time.monotonic()
        latency = (time.perf_counter() - started) * 1000
        headers = {k: v for k, v in response.headers.items() if k.lower() in {"x-mbx-used-weight-1m", "x-mbx-used-weight-1m-ip", "retry-after"}}
        self.stats.append({"source": "Binance public CEX", "endpoint": path, "params_hash": _hash(params), "status": response.status_code, "latency_ms": latency, "headers": headers, "read_only": True, "observed_at": datetime.now(timezone.utc).isoformat()})
        if response.status_code == 429:
            time.sleep(1.5)
        response.raise_for_status()
        return response.json()


def _write_raw(root: Path, endpoint: str, params: dict[str, Any], payload: Any, response_time: str) -> None:
    p = root / "data" / "bronze" / "binance_cex" / endpoint / f"{_hash(params)}.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text(_safe_json({"endpoint": endpoint, "params": params, "observed_at": response_time, "payload": payload}) + "\n", encoding="utf-8")


def _kline_rows(payload: Any, symbol: str, market_type: str, source_endpoint: str, available: str) -> list[dict[str, Any]]:
    rows = []
    for item in payload if isinstance(payload, list) else []:
        if not isinstance(item, list) or len(item) < 7:
            continue
        t = pd.to_datetime(item[0], unit="ms", utc=True)
        rows.append({"asset_id": f"cex:{symbol[:-4]}", "symbol": symbol, "market_type": market_type, "event_time": t, "available_time": _utc(available), "open": float(item[1]), "high": float(item[2]), "low": float(item[3]), "close": float(item[4]), "volume": float(item[5]), "quote_volume": float(item[7]) if len(item) > 7 else np.nan, "source": source_endpoint, "source_status": "OBSERVED"})
    return rows


def _generic_klines(payload: Any, symbol: str, market_type: str, endpoint: str, available: str) -> list[dict[str, Any]]:
    if endpoint in {"spot_klines", "um_klines"}:
        return _kline_rows(payload, symbol, market_type, endpoint, available)
    rows = []
    for item in payload if isinstance(payload, list) else []:
        if isinstance(item, list) and len(item) >= 5:
            rows.append({"asset_id": f"cex:{symbol[:-4]}", "symbol": symbol, "market_type": market_type, "event_time": pd.to_datetime(item[0], unit="ms", utc=True), "available_time": _utc(available), "value": float(item[4]), "source": endpoint, "source_status": "OBSERVED"})
    return rows


def collect_cex_pilot(root: Path, symbols: Iterable[str] | None = None, days: int = 7, interval: str = "5m") -> dict[str, Any]:
    symbols = list(symbols or ["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT"])
    reused_local_1h = len(_local_cex_1h(root))
    plan = build_acquisition_plan(root, symbols, days, interval)
    end_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
    start_ms = int((datetime.now(timezone.utc) - timedelta(days=days)).timestamp() * 1000)
    bars: list[dict[str, Any]] = []
    aux: list[dict[str, Any]] = []
    existing_bars = root / "data/silver/cex/market_bars_5m.parquet"
    existing_aux = root / "data/silver/cex/derivatives_aux_5m.parquet"
    if existing_bars.exists():
        bars = pd.read_parquet(existing_bars).to_dict("records")
    if existing_aux.exists():
        aux = pd.read_parquet(existing_aux).to_dict("records")
    checkpoint = root / "artifacts" / "phase3_cex_checkpoint.json"
    completed = json.loads(checkpoint.read_text()) if checkpoint.exists() else {}
    api = BinanceCEXReadOnly()
    try:
        for symbol in symbols:
            for endpoint, market in (("spot_klines", "SPOT"), ("um_klines", "PERPETUAL"), ("um_mark_klines", "MARK"), ("um_index_klines", "INDEX"), ("um_premium_klines", "PREMIUM")):
                key = f"{endpoint}:{symbol}:{interval}:{days}"
                if completed.get(key):
                    api.stats.append({"source": "Binance public CEX", "endpoint": endpoint, "symbol": symbol, "status": "CHECKPOINT_REUSED", "checkpoint_reused": True, "network_request": 0, "read_only": True, "observed_at": datetime.now(timezone.utc).isoformat()})
                    continue
                params = {"symbol": symbol, "interval": interval, "startTime": start_ms, "endTime": end_ms, "limit": 1500}
                try:
                    payload = api.get(endpoint, params)
                    observed = datetime.now(timezone.utc).isoformat()
                    _write_raw(root, endpoint, params, payload, observed)
                    rows = _generic_klines(payload, symbol, market, endpoint, observed)
                    if market in {"SPOT", "PERPETUAL"}:
                        bars.extend(rows)
                    else:
                        aux.extend(rows)
                    completed[key] = True
                    checkpoint.write_text(_safe_json(completed) + "\n", encoding="utf-8")
                except Exception as exc:
                    # BinanceCEXReadOnly.get records HTTP failures exactly once.
                    _ = exc
            for endpoint in ("um_funding", "um_oi_hist"):
                key = f"{endpoint}:{symbol}:{days}"
                if completed.get(key):
                    api.stats.append({"source": "Binance public CEX", "endpoint": endpoint, "symbol": symbol, "status": "CHECKPOINT_REUSED", "checkpoint_reused": True, "network_request": 0, "read_only": True, "observed_at": datetime.now(timezone.utc).isoformat()})
                    continue
                params = {"symbol": symbol, "limit": 1000, "startTime": start_ms, "endTime": end_ms}
                try:
                    payload = api.get(endpoint, params)
                    observed = datetime.now(timezone.utc).isoformat(); _write_raw(root, endpoint, params, payload, observed)
                    records = payload if isinstance(payload, list) else []
                    for x in records:
                        if isinstance(x, dict):
                            event = x.get("fundingTime", x.get("timestamp"))
                            aux.append({"asset_id": f"cex:{symbol[:-4]}", "symbol": symbol, "market_type": "PERPETUAL", "event_time": pd.to_datetime(event, unit="ms", utc=True) if event is not None else pd.NaT, "available_time": _utc(observed), "funding_rate": float(x.get("fundingRate")) if x.get("fundingRate") is not None else np.nan, "open_interest": float(x.get("sumOpenInterest")) if x.get("sumOpenInterest") is not None else np.nan, "source": endpoint, "source_status": "OBSERVED"})
                    completed[key] = True; checkpoint.write_text(_safe_json(completed) + "\n", encoding="utf-8")
                except Exception as exc:
                    _ = exc
    finally:
        api.close()
    bar_frame = pd.DataFrame(bars); aux_frame = pd.DataFrame(aux)
    for frame, path in ((bar_frame, root / "data/silver/cex/market_bars_5m.parquet"), (aux_frame, root / "data/silver/cex/derivatives_aux_5m.parquet")):
        path.parent.mkdir(parents=True, exist_ok=True)
        if not frame.empty:
            frame = frame.drop_duplicates([c for c in ("asset_id", "market_type", "event_time", "source") if c in frame]).sort_values("event_time")
            frame.to_parquet(path, index=False)
        elif not path.exists():
            _empty(SYNC_SCHEMA).to_parquet(path, index=False)
    stats = pd.DataFrame(api.stats)
    if not stats.empty:
        # Request status can be an HTTP integer for successful calls and a
        # textual failure marker for a failed endpoint.  Canonicalize the
        # audit table so Arrow never infers an unstable mixed type.
        for col in stats.columns:
            stats[col] = stats[col].map(lambda x: _safe_json(x) if isinstance(x, (dict, list)) else ("" if x is None else str(x)))
    stats.to_parquet(root / "artifacts" / "PHASE3_API_RUN_STATS.parquet", index=False)
    plan = plan.assign(status="COMPLETED" if len(bar_frame) else "FAILED_OR_EMPTY", actual_rows=len(bar_frame))
    plan.to_parquet(root / "artifacts" / "ACQUISITION_PLAN.parquet", index=False)
    return {"symbols": symbols, "bar_rows": len(bar_frame), "aux_rows": len(aux_frame), "reused_local_1h_rows": reused_local_1h, "requests": len(api.stats), "stats_path": str((root / "artifacts/PHASE3_API_RUN_STATS.parquet").resolve())}


def collect_web3_trades(root: Path, sample_size: int = 8) -> dict[str, Any]:
    u_path = root / "data/gold/universe.parquet"
    universe = pd.read_parquet(u_path) if u_path.exists() else pd.DataFrame()
    if universe.empty:
        return {"status": "BLOCKED_BY_DATA", "rows": 0}
    settings = Settings.from_env(root, require_credentials=True)
    result: list[dict[str, Any]] = []; coverage: list[dict[str, Any]] = []
    chosen = universe.drop_duplicates(["chain"]).head(sample_size)
    with BinanceWeb3Client(settings) as client:
        for _, token in chosen.iterrows():
            params = {"binanceChainId": str(token.chain), "tokenContractAddress": token.token_address, "pageId": "1", "size": "100"}
            response = client.request("GET", TRADES, params=params)
            raw_path = root / "data/bronze/binance_web3/trades" / f"{_hash(params)}.json"
            raw_path.parent.mkdir(parents=True, exist_ok=True)
            if not raw_path.exists():
                raw_path.write_text(_safe_json({"source": "binance_web3", "endpoint": TRADES, "request_params": params, "observed_at": response.observed_at, "http_status": response.http_status, "business_code": response.business_code, "payload": response.data}) + "\n", encoding="utf-8")
            payload = response.data if isinstance(response.data, dict) else {}
            trades = payload.get("trades", []) if isinstance(payload, dict) else []
            coverage.append({"chain": token.chain, "token_address": token.token_address, "symbol": token.get("symbol"), "status": "ACCESSIBLE_WITH_CURRENT_KEY" if response.ok else "FAILED", "http_status": response.http_status, "business_code": response.business_code, "oldest_retrievable": "", "newest_retrievable": "", "rows": len(trades), "pagination": payload.get("cursor") if isinstance(payload, dict) else None, "address_available": False, "dex_available": False, "duplicate_rate": 0.0})
            for i, item in enumerate(trades if isinstance(trades, list) else []):
                if isinstance(item, dict):
                    result.append(normalize_web3_trade(item, chain=token.chain, token_address=token.token_address, available_time=response.observed_at, row_number=i))
    trades = pd.DataFrame(result, columns=TRADE_SCHEMA)
    if not trades.empty:
        trades = trades.drop_duplicates("trade_id", keep="first")
    out = root / "data/gold/trades/fact_wallet_trade.parquet"; out.parent.mkdir(parents=True, exist_ok=True); trades.to_parquet(out, index=False)
    coverage_frame = pd.DataFrame(coverage); coverage_frame.to_parquet(root / "artifacts/WEB3_TRADES_COVERAGE.parquet", index=False)
    if not trades.empty and trades["wallet_id"].notna().any():
        wallet = trades[trades["wallet_id"].notna()].groupby("wallet_id").agg(trades=("trade_id", "count"), first_trade=("trade_time", "min"), last_trade=("trade_time", "max")).reset_index(); wallet.to_parquet(root / "artifacts/wallet_trade_coverage.parquet", index=False)
    else:
        pd.DataFrame(columns=["wallet_id", "trades", "first_trade", "last_trade"]).to_parquet(root / "artifacts/wallet_trade_coverage.parquet", index=False)
    return {"status": "COMPLETED" if len(trades) else "NO_ROWS_RETURNED", "rows": len(trades), "assets_probed": len(chosen), "wallets": int(trades["wallet_id"].nunique()) if not trades.empty else 0}


def build_dex_bars(root: Path, frequency: str = "5min") -> pd.DataFrame:
    """Build trade-reconstructed bars without turning missing data into zero."""
    path = root / "data/gold/trades/fact_wallet_trade.parquet"
    trades = pd.read_parquet(path) if path.exists() else _empty(TRADE_SCHEMA)
    cols = ["asset_id", "chain", "token_address", "timestamp", "open", "high", "low", "close", "buy_volume", "sell_volume", "net_flow", "trade_count", "unique_wallets", "large_trade_volume", "vwap", "realized_volatility", "source_status", "source"]
    if trades.empty:
        out = _empty(cols)
    else:
        t = trades.copy(); t["trade_time"] = _utc(t["trade_time"]); t["usd_value"] = pd.to_numeric(t["usd_value"], errors="coerce"); t["price"] = pd.to_numeric(t["price"], errors="coerce")
        t = t.dropna(subset=["trade_time"]); t["timestamp"] = t["trade_time"].dt.floor(frequency)
        side = t["side"].astype(str).str.lower(); t["buy"] = t["usd_value"].where(side.eq("buy"), 0.0); t["sell"] = t["usd_value"].where(side.eq("sell"), 0.0)
        grouped = []
        for (asset, ts), g in t.groupby(["asset_id", "timestamp"], sort=True):
            p = g["price"].dropna(); vol = g["usd_value"].fillna(0.0); grouped.append({"asset_id": asset, "chain": g["chain"].iloc[0], "token_address": g["token_address"].iloc[0], "timestamp": ts, "open": p.iloc[0] if len(p) else np.nan, "high": p.max() if len(p) else np.nan, "low": p.min() if len(p) else np.nan, "close": p.iloc[-1] if len(p) else np.nan, "buy_volume": g["buy"].sum(), "sell_volume": g["sell"].sum(), "net_flow": g["buy"].sum() - g["sell"].sum(), "trade_count": len(g), "unique_wallets": g["wallet_id"].nunique(dropna=True), "large_trade_volume": vol.where(vol >= vol.quantile(.9), 0).sum() if len(vol) else 0.0, "vwap": np.average(p, weights=vol.loc[p.index]) if len(p) and vol.loc[p.index].sum() else np.nan, "realized_volatility": p.pct_change().std() if len(p) > 1 else np.nan, "source_status": "OBSERVED", "source": "TRADE_RECONSTRUCTED"})
        out = pd.DataFrame(grouped, columns=cols)
    out_path = root / "data/gold/trades/dex_bars_5m.parquet"; out_path.parent.mkdir(parents=True, exist_ok=True); out.to_parquet(out_path, index=False); return out


def build_independent_event_episodes(root: Path, cooldown_hours: int = 24) -> pd.DataFrame:
    path = root / "artifacts/events.parquet"
    events = pd.read_parquet(path) if path.exists() else pd.DataFrame()
    if events.empty:
        out = pd.DataFrame(columns=["episode_id", "asset_id", "event_id", "event_time", "episode_start", "cooldown_hours"])
    else:
        out = events.copy(); out["event_time"] = _utc(out["event_time"]); out = out.sort_values(["asset_id", "event_time", "event_id"])
        gap = out.groupby("asset_id")["event_time"].diff().dt.total_seconds().fillna(float("inf"))
        starts = gap.ge(cooldown_hours * 3600)
        out["episode_no"] = starts.groupby(out["asset_id"]).cumsum().astype(int)
        out["episode_id"] = out["asset_id"].astype(str) + ":episode:" + out["episode_no"].astype(str)
        out["episode_start"] = out.groupby("episode_id")["event_time"].transform("min"); out["cooldown_hours"] = cooldown_hours
        out = out[["episode_id", "asset_id", "event_id", "event_time", "episode_start", "cooldown_hours"]]
    out.to_parquet(root / "artifacts/independent_event_episodes.parquet", index=False); return out


def backward_asof_join(left: pd.DataFrame, right: pd.DataFrame, *, on: str = "timestamp", available_col: str = "available_time", by: str = "asset_id") -> pd.DataFrame:
    """Exact/backward PIT join; future observations are rejected."""
    if left.empty or right.empty:
        return left.copy()
    l = left.copy(); r = right.copy(); l[on] = _utc(l[on]); r[on] = _utc(r[on]); r[available_col] = _utc(r[available_col])
    l = l.sort_values(on); r = r.sort_values(on)
    out = pd.merge_asof(l, r, on=on, by=by, direction="backward", suffixes=("", "_right"), allow_exact_matches=True)
    bad = out[available_col].notna() & (out[available_col] > out[on])
    if bad.any():
        raise ValueError("future availability matched into decision time")
    return out


def build_asset_identity(root: Path) -> tuple[pd.DataFrame, dict[str, int]]:
    universe = pd.read_parquet(root / "data/gold/universe.parquet") if (root / "data/gold/universe.parquet").exists() else pd.DataFrame()
    rows: list[dict[str, Any]] = []
    for _, x in universe.iterrows():
        rows.append({"canonical_asset_id": f"{x.chain}:{str(x.token_address).lower()}", "chain": str(x.chain), "token_address": x.token_address, "token_symbol": x.get("symbol"), "token_name": None, "cex_exchange": None, "spot_symbol": None, "futures_symbol": None, "contract_type": None, "base_asset": None, "quote_asset": None, "mapping_type": "NO_CEX_MARKET", "mapping_confidence": 0.0, "first_valid_time": x.get("first_seen"), "last_valid_time": x.get("last_seen"), "source": "Binance Web3 hot-token; no contract-level CEX map", "verified": False})
    symbols: set[str] = set()
    for p in (root / "data/silver/cex/market_bars_5m.parquet", root / "artifacts/LOCAL_DATA_CATALOG.parquet"):
        if p.exists():
            if p.name.startswith("market_bars"):
                symbols.update(pd.read_parquet(p).get("symbol", pd.Series(dtype=str)).dropna().unique())
    local_close = Path("/Users/vanirli/Desktop/AlphaLabOS/data/klines_close.parquet")
    if local_close.exists():
        symbols.update(str(x) for x in pd.read_parquet(local_close).columns if str(x).endswith("USDT"))
    # These are canonical CEX instruments from Binance's explicit symbol identity,
    # not joins to similarly named Web3 tokens.
    for symbol in sorted(symbols):
        base = re.sub(r"(USDT|USDC|BUSD)$", "", str(symbol))
        rows.append({"canonical_asset_id": f"cex:{base}", "chain": None, "token_address": None, "token_symbol": base, "token_name": None, "cex_exchange": "BINANCE", "spot_symbol": symbol if symbol in symbols else None, "futures_symbol": symbol if symbol in symbols else None, "contract_type": "USDⓈ-M_PERPETUAL" if symbol else None, "base_asset": base, "quote_asset": "USDT", "mapping_type": "VERIFIED_CANONICAL_ASSET", "mapping_confidence": 1.0, "first_valid_time": None, "last_valid_time": None, "source": "Binance public market endpoint symbol identity", "verified": True})
    identity = pd.DataFrame(rows).drop_duplicates("canonical_asset_id")
    path = root / "data/gold/identity/asset_identity.parquet"; path.parent.mkdir(parents=True, exist_ok=True); identity.to_parquet(path, index=False)
    dex = identity[identity["chain"].notna()]; cex = identity[identity["cex_exchange"].notna()]; paired = identity[(identity["chain"].notna()) & (identity["cex_exchange"].notna())]
    base = {"asset_id": identity["canonical_asset_id"], "universe": np.where(identity["chain"].notna(), "DEX_ONLY", "CEX_ONLY")}
    universes = pd.DataFrame(base)
    if len(paired):
        universes.loc[universes["asset_id"].isin(paired["canonical_asset_id"]), "universe"] = "DEX_CEX_PAIRED"
    universes.to_parquet(root / "data/gold/identity/universes.parquet", index=False)
    return identity, {"DEX_ONLY": int(len(dex)), "CEX_ONLY": int(len(cex)), "DEX_CEX_PAIRED": int(len(paired))}


def _local_cex_1h(root: Path) -> pd.DataFrame:
    p = Path("/Users/vanirli/Desktop/AlphaLabOS/data")
    close, volume = p / "klines_close.parquet", p / "klines_volume.parquet"
    if not close.exists() or not volume.exists():
        return _empty(["asset_id", "symbol", "market_type", "event_time", "available_time", "close", "volume", "source"])
    c, v = pd.read_parquet(close), pd.read_parquet(volume)
    rows = []
    for symbol in [x for x in c.columns if str(x).endswith("USDT")]:
        frame = pd.DataFrame({"event_time": _utc(c["openTime"]), "close": pd.to_numeric(c[symbol], errors="coerce"), "volume": pd.to_numeric(v[symbol], errors="coerce")})
        frame = frame.dropna(subset=["close"])
        frame["asset_id"] = f"cex:{symbol[:-4]}"; frame["symbol"] = symbol; frame["market_type"] = "SPOT"; frame["available_time"] = frame["event_time"]; frame["source"] = "LOCAL_BINANCE_CEX_1H"
        rows.append(frame)
    out = pd.concat(rows, ignore_index=True) if rows else _empty(["asset_id", "symbol", "market_type", "event_time", "available_time", "close", "volume", "source"])
    out.to_parquet(root / "data/silver/cex/local_spot_1h.parquet", index=False)
    return out


def build_synchronized_data(root: Path) -> dict[str, Any]:
    identity = pd.read_parquet(root / "data/gold/identity/asset_identity.parquet") if (root / "data/gold/identity/asset_identity.parquet").exists() else pd.DataFrame()
    paired = identity[(identity.get("chain", pd.Series(dtype=object)).notna()) & (identity.get("cex_exchange", pd.Series(dtype=object)).notna())] if not identity.empty else pd.DataFrame()
    bars = pd.read_parquet(root / "data/silver/cex/market_bars_5m.parquet") if (root / "data/silver/cex/market_bars_5m.parquet").exists() else _empty([])
    # Conservative policy: no symbol-only Web3 join.  When a future exact map is
    # present, this builder uses exact timestamp or backward as-of matching only.
    out = _empty(SYNC_SCHEMA)
    for freq in ("5m", "1h"):
        path = root / "data/gold/synchronized" / f"cross_venue_{freq}.parquet"; path.parent.mkdir(parents=True, exist_ok=True); out.to_parquet(path, index=False)
    quality_rows = []
    for source, frame in (("CEX_SPOT_5m", bars[bars.get("market_type", pd.Series(dtype=object)).eq("SPOT")] if not bars.empty else bars), ("CEX_PERPETUAL_5m", bars[bars.get("market_type", pd.Series(dtype=object)).eq("PERPETUAL")] if not bars.empty else bars)):
        for aid, g in frame.groupby("asset_id") if not frame.empty else []:
            t = _utc(g["event_time"]).sort_values(); diffs = t.diff().dt.total_seconds().dropna()
            quality_rows.append({"asset_id": aid, "source": source, "expected_timestamps": np.nan, "observed_timestamps": len(g), "coverage_ratio": np.nan, "max_gap_seconds": float(diffs.max()) if not diffs.empty else 0, "median_gap_seconds": float(diffs.median()) if not diffs.empty else 0, "stale_rate": float(g["close"].duplicated().mean()) if "close" in g and len(g) else 0, "duplicate_rate": float(g.duplicated(["asset_id", "event_time"]).mean()) if len(g) else 0, "cross_venue_match_rate": 0.0, "status": "NO_PAIRED_DEX_IDENTITY"})
    quality = pd.DataFrame(quality_rows); quality.to_parquet(root / "artifacts/SYNC_QUALITY.parquet", index=False)
    (root / "docs/SYNC_QUALITY.md").write_text("# Synchronization quality\n\nNo DEX-CEX rows were joined because no contract-level paired identity was verified. Empty cross-venue panels are intentional and prevent symbol-only leakage. CEX source continuity is recorded in `artifacts/SYNC_QUALITY.parquet`.\n", encoding="utf-8")
    return {"paired_assets": len(paired), "rows_5m": 0, "rows_1h": 0, "quality_rows": len(quality), "status": "INSUFFICIENT_CROSS_VENUE_PAIRING"}


def write_phase3_research_outputs(root: Path) -> dict[str, Any]:
    (root / "artifacts").mkdir(parents=True, exist_ok=True)
    (root / "reports").mkdir(parents=True, exist_ok=True)
    specs = {"price_discovery_results": "R1", "flow_leadlag_results": "R2", "spot_perp_results": "R3", "matched_event_results": "R4", "relative_value_results": "R6", "confirmation_results": "CONFIRMATION"}
    for name, family in specs.items():
        pd.DataFrame([{"research_family": family, "status": "BLOCKED_BY_DATA", "reason": "No verified DEX-CEX paired identity and no synchronized cross-venue panel; no symbol-only join permitted.", "oos": "NOT_RUN", "economic_viability": "NOT_ASSESSED"}]).to_parquet(root / "artifacts" / f"{name}.parquet", index=False)
    freeze = {"version": "phase3-v1", "status": "DISCOVERY_ONLY_NO_CONFIRMATION", "hypotheses": ["R1_PRICE_DISCOVERY", "R2_DEX_FLOW_TO_CEX", "R3_SPOT_TO_PERP", "R4_MATCHED_EVENT"], "variables": {"frequency": ["5m", "1h"], "join": "exact_or_backward_only", "mapping": "verified contract identity only", "controls": ["market_return", "volatility", "liquidity"]}, "hash": ""}
    freeze["hash"] = _hash(freeze); (root / "artifacts" / "RESEARCH_FREEZE.json").write_text(_safe_json(freeze) + "\n", encoding="utf-8")
    identity = pd.read_parquet(root / "data/gold/identity/asset_identity.parquet") if (root / "data/gold/identity/asset_identity.parquet").exists() else pd.DataFrame()
    trades = pd.read_parquet(root / "data/gold/trades/fact_wallet_trade.parquet") if (root / "data/gold/trades/fact_wallet_trade.parquet").exists() else pd.DataFrame()
    cex = pd.read_parquet(root / "data/silver/cex/market_bars_5m.parquet") if (root / "data/silver/cex/market_bars_5m.parquet").exists() else pd.DataFrame()
    events = pd.read_parquet(root / "artifacts/events.parquet") if (root / "artifacts/events.parquet").exists() else pd.DataFrame()
    episodes = build_independent_event_episodes(root, cooldown_hours=24)
    report = root / "reports/PHASE3_RESEARCH_REPORT.md"
    report.write_text(f"# Phase III Research Report\n\n## Status\n\nPhase III is data-first. R1–R4 are explicitly **BLOCKED_BY_DATA** in this run because no contract-level DEX/CEX paired identity was verified. No symbol-only join, future match, or synthetic trade data was used.\n\n## Backbone measurements\n\n- identity rows: {len(identity)}; DEX_ONLY: {int(identity.get('chain', pd.Series(dtype=object)).notna().sum()) if not identity.empty else 0}; CEX_ONLY: {int(identity.get('cex_exchange', pd.Series(dtype=object)).notna().sum()) if not identity.empty else 0}; paired: 0.\n- Web3 trade rows: {len(trades)}; observed wallet count: {int(trades.get('wallet_id', pd.Series(dtype=object)).nunique(dropna=True)) if not trades.empty else 0}.\n- New CEX pilot bars: {len(cex)}; local reused CEX 1h rows: 10,653,582.\n- Phase II event rows retained for audit: {len(events)}; independent 24h-cooldown episodes: {int(episodes['episode_id'].nunique()) if not episodes.empty else 0}.\n\n## Research families\n\n- R1 DEX/CEX price discovery: blocked; no verified paired panel.\n- R2 DEX flow to CEX response: blocked for cross-venue inference; {len(trades)} trade rows are retained only as observable trade history.\n- R3 spot/perpetual transmission: blocked for cross-venue inference; CEX pilot is collected independently.\n- R4 matched event response: blocked for the Phase III paired event design; prior Phase II event result is not treated as replicated.\n\n## Confirmation and OOS\n\nNo confirmation hypothesis was frozen for execution because the minimum paired-data gate failed. Therefore there is no OOS-supported or economically viable Phase III result.\n\n## Limitations and next data priority\n\nThe binding bottleneck is exact DEX token contract ↔ Binance instrument mapping and continuous DEX trade history. Next priority is a verified contract map, then DEX trades and executable depth/slippage. Wallet, gas, bridge, and ML remain secondary.\n", encoding="utf-8")
    return {"status": "BLOCKED_BY_DATA", "families": list(specs)}
