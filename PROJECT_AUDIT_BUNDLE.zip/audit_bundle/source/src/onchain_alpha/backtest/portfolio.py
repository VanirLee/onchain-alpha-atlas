from __future__ import annotations

import numpy as np
import pandas as pd


def top_bottom_weights(group: pd.DataFrame, factor: str, long_quantile: float = 0.8, short: bool = False) -> pd.Series:
    scores = pd.to_numeric(group[factor], errors="coerce")
    weights = pd.Series(0.0, index=group.index)
    valid = scores.dropna()
    if len(valid) < 5:
        return weights
    q_hi, q_lo = valid.quantile(long_quantile), valid.quantile(1 - long_quantile)
    long_idx, short_idx = valid[valid >= q_hi].index, valid[valid <= q_lo].index
    if short:
        if len(long_idx): weights.loc[long_idx] = 0.5 / len(long_idx)
        if len(short_idx): weights.loc[short_idx] = -0.5 / len(short_idx)
    elif len(long_idx):
        weights.loc[long_idx] = 1.0 / len(long_idx)
    return weights
