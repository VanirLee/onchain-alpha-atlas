from __future__ import annotations


def round_trip_cost_bps(mode: str = "dex", fee_bps: float = 5.0, half_spread_bps: float = 2.5, slippage_bps: float = 2.5, gas_bps: float = 0.0) -> float:
    if mode == "cex":
        return fee_bps + half_spread_bps + slippage_bps
    return fee_bps + slippage_bps + gas_bps
