from __future__ import annotations

from datetime import timedelta

import numpy as np
import pandas as pd

from .portfolio import top_bottom_weights


def _stats(returns: pd.Series, weights: pd.DataFrame, horizon: int) -> dict[str, float | None]:
    """Statistics from a real non-overlapping account PnL series."""
    r = pd.to_numeric(returns, errors="coerce").dropna().sort_index()
    if r.empty:
        return {"annualized_return": None, "sharpe": None, "sortino": None, "max_drawdown": None, "turnover": None, "hit_rate": None}
    equity = (1 + r).cumprod()
    drawdown = equity / equity.cummax() - 1
    vol = r.std(ddof=1)
    downside = r[r < 0].std(ddof=1)
    turnover = weights.diff().abs().sum(axis=1).mean() if len(weights) > 1 else 0.0
    periods_per_year = 365.25 * 24 / max(1, int(horizon))
    span_years = max(1 / periods_per_year, (r.index.max() - r.index.min()).total_seconds() / (365.25 * 24 * 3600)) if isinstance(r.index, pd.DatetimeIndex) and len(r) > 1 else len(r) / periods_per_year
    annualized = float(equity.iloc[-1] ** (1 / span_years) - 1) if equity.iloc[-1] > 0 else None
    scale = np.sqrt(periods_per_year)
    return {"annualized_return": annualized, "sharpe": float(r.mean() / vol * scale) if vol and np.isfinite(vol) else None, "sortino": float(r.mean() / downside * scale) if downside and np.isfinite(downside) else None, "max_drawdown": float(drawdown.min()), "turnover": float(turnover), "hit_rate": float((r > 0).mean())}


def asset_key(frame: pd.DataFrame) -> pd.MultiIndex:
    """Canonical asset identity used by portfolio weights."""
    return pd.MultiIndex.from_frame(frame[["chain", "token_address"]].astype(str))


def _rebalance_times(times: pd.Series, horizon: int) -> list[pd.Timestamp]:
    available = sorted(pd.to_datetime(times, utc=True).dropna().unique())
    selected: list[pd.Timestamp] = []
    next_allowed = None
    for ts in available:
        ts = pd.Timestamp(ts)
        if next_allowed is None or ts >= next_allowed:
            selected.append(ts)
            next_allowed = ts + timedelta(hours=int(horizon))
    return selected


def run_backtest(panel: pd.DataFrame, labels: pd.DataFrame, factor: str = "momentum_1h", horizon: int = 24, costs_bps: tuple[float, ...] = (5, 10, 25, 50, 100), short: bool = False) -> pd.DataFrame:
    """Run a non-overlapping rebalance backtest using exact-horizon labels.

    Each selected entry timestamp creates one h-hour portfolio cohort.  The
    next selected entry is at least h hours later, so forward labels are not
    incorrectly compounded as hourly account returns.  Asset identity is the
    tuple (chain, token_address) throughout the weight matrix.
    """
    target = f"forward_return_{horizon}h"
    exit_col = f"exit_time_{horizon}h"
    keys = ["chain", "token_address", "feature_time"]
    df = panel.merge(labels, on=keys, how="inner")
    if df.empty or target not in df or exit_col not in df:
        return pd.DataFrame([{ "factor": factor, "horizon": horizon, "status": "insufficient evidence" }])
    df["feature_time"] = pd.to_datetime(df["feature_time"], utc=True, errors="coerce")
    df[exit_col] = pd.to_datetime(df[exit_col], utc=True, errors="coerce")
    df[target] = pd.to_numeric(df[target], errors="coerce")
    selected = _rebalance_times(df.loc[df[target].notna(), "feature_time"], horizon)
    cohorts: list[tuple[pd.Timestamp, pd.DataFrame, pd.DataFrame, float]] = []
    previous_weights: pd.Series | None = None
    for ts in selected:
        group = df[(df["feature_time"] == ts) & df[target].notna() & df[exit_col].notna()]
        if len(group) < 5:
            continue
        group = group.copy()
        group["weight"] = top_bottom_weights(group, factor, short=short)
        if group["weight"].abs().sum() == 0:
            continue
        weights = pd.Series(group["weight"].to_numpy(), index=asset_key(group), name="weight")
        turnover = 0.0 if previous_weights is None else float(weights.reindex(weights.index.union(previous_weights.index), fill_value=0).subtract(previous_weights.reindex(weights.index.union(previous_weights.index), fill_value=0)).abs().sum())
        gross = float((group["weight"] * group[target]).sum())
        cohorts.append((ts, group, weights, turnover))
        previous_weights = weights
    if not cohorts:
        return pd.DataFrame([{ "factor": factor, "horizon": horizon, "status": "insufficient evidence" }])
    rows = []
    for cost in costs_bps:
        pnl = pd.Series({ts: gross - turnover * float(cost) / 10000.0 for ts, group, weights, turnover in cohorts for gross in [float((group["weight"] * group[target]).sum())]})
        weight_rows = []
        for ts, group, weights, _ in cohorts:
            row = weights.rename("weight").to_frame().T
            row.index = pd.DatetimeIndex([ts])
            weight_rows.append(row)
        weight_matrix = pd.concat(weight_rows, axis=0).fillna(0).sort_index() if weight_rows else pd.DataFrame()
        stats = _stats(pnl, weight_matrix, horizon)
        gross_mean = float(np.mean([float((group["weight"] * group[target]).sum()) for _, group, _, _ in cohorts]))
        rows.append({
            "factor": factor, "horizon": horizon, "cost_bps": cost, "mode": "long_short" if short else "long_only",
            "gross_return": gross_mean, "net_return": float(pnl.mean()), "cost_model": "proxy; fee + slippage (+ gas for DEX if configured)",
            "accounting_method": "non_overlapping_rebalance", "pnl_frequency": f"{horizon}h", "capacity_status": "NOT_AVAILABLE_NO_EXECUTABLE_DEPTH",
            "n_rebalances": len(cohorts), **stats, "status": "computed",
        })
    return pd.DataFrame(rows)
