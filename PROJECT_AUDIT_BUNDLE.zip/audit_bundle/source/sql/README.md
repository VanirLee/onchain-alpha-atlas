# SQL snippets

DuckDB views are refreshed by `onchain_alpha.cli report`. Query the partitioned Gold Parquet directly, for example:

```sql
SELECT chain, COUNT(*) FROM read_parquet('data/gold/market_observations.parquet') GROUP BY chain;
```
