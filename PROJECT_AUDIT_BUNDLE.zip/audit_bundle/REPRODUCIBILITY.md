# Reproducibility

Run `.venv/bin/pytest -q`, then use `python -m onchain_alpha.cli phase5-semantics`, `collect-token-trades`, `probe-participant-endpoints`, `collect-participant-tags`, `collect-participant-snapshots`, `run-phase5-microstructure`, and `run-research-program`. `run-research-program` is the canonical no-network research path over persisted data. All network calls are read-only and use checkpointed raw Bronze storage.
