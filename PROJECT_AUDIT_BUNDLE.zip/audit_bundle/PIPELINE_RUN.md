# Pipeline run record

| Stage | Status | Evidence |
|---|---|---|
| semantic normalization | SUCCESS | `src/onchain_alpha/data/phase3.py::normalize_web3_trade`; volume=USD, changedTokenInfo=token quantity |
| historical cursor collection | COMPLETED/PARTIAL | 20 tokens, 111 pages, 9100 raw history rows; bounded pages retained with checkpoints |
| participant probes | SUCCESS | `artifacts/PARTICIPANT_ENDPOINT_PROBES.parquet`; read-only endpoint statuses retained |
| tag coverage | SUCCESS | `artifacts/participant_tag_coverage.parquet`; external labels only |
| participant/pool snapshots | SUCCESS/PARTIAL | append-only snapshots; pool state limited to top-liquidity snapshots |
| clock microstructure | EXPLORATORY | 1m/5m grids, fixed clock-time horizons, episode cluster bootstrap |
| wallet skill | BLOCKED_BY_SAMPLE | median wallet trade count remains 1; no skill alpha promoted |
| tests | SUCCESS | 65 passed, 0 failed |
| audit/report | SUCCESS | Phase V report and provenance refreshed from source outputs |

No write endpoint was called.
