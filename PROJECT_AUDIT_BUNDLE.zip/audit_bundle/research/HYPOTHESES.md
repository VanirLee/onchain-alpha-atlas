# Hypotheses

The executed run was exploratory, not preregistered. The following are transparent post-hoc research hypotheses corresponding to the implemented factor families:

- H1 (POST-HOC/EXPLORATORY): short-term reversal predicts next-horizon cross-sectional returns.
- H2 (POST-HOC/EXPLORATORY): volume momentum/surprise predicts future returns.
- H3 (POST-HOC/EXPLORATORY): liquidity/illiquidity proxies add predictive information beyond price movement.
- H4 (NOT TESTED): smart-money flow intensity and signal persistence predict returns; no confirmed signal endpoint was available.
- H5 (NOT TESTED): wallet persona features predict returns; no wallet holdings endpoint was confirmed.

All tested H1-H3 variants are multiple-tested in `results/multiple_testing.csv`; no q=0.05 or q=0.10 discovery survives in this run.
