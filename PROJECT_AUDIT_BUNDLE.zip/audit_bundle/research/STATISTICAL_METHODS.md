# Statistical methods actually used

- Spearman Rank IC: `scipy.stats.spearmanr`, computed cross-sectionally by feature timestamp.
- Factor inference: H0: E[IC_t]=0; one-sample t statistic and `statsmodels.OLS(IC_t ~ 1, cov_type='HAC')`. HAC lag is `min(horizon, n_periods-1)` and defaults to the forward-return horizon when enough periods exist. Per-cross-section Spearman p-values are descriptive only and are never averaged.
- Pearson IC: NOT USED.
- ICIR: mean IC / sample standard deviation × sqrt(number of periods).
- Fama-MacBeth: NOT fully implemented as a time-series of cross-sectional coefficients; current regression is exploratory pooled OLS.
- Clustered SE: NOT USED.
- Bootstrap/block bootstrap: NOT USED.
- Panel fixed effects: NOT USED.
- Benjamini-Hochberg FDR: USED across HAC factor-level p-values; outputs raw, adjusted, and q=0.05/q=0.10 flags.
- Bonferroni: NOT USED.
- White Reality Check: NOT USED.
- Deflated Sharpe Ratio: NOT USED.
- Probability of Backtest Overfitting/CSCV: NOT USED.

The small current sample and exploratory selection mean nominal p-values should not be treated as definitive evidence.
