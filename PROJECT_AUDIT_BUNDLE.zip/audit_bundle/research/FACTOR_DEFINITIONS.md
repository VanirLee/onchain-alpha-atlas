# Factor definitions

Implementation: `src/onchain_alpha/features/core.py::build_factor_panel`.

For each `(chain, token_address)` history, rows are sorted by `feature_time`; rolling and lagged values use only rows at or before the current row. `eps=1e-12` is used where the source code protects a denominator. `known_at` is the normalized observation time. Labels are future-only and are never factor inputs.

- `log_market_cap`: `see source implementation`
- `log_liquidity`: `see source implementation`
- `volatility`: `see source implementation`
- `momentum_1h`: `price(t) / price(t-1) - 1`
- `momentum_4h`: `price(t) / price(t-4) - 1`
- `momentum_24h`: `price(t) / price(t-24) - 1`
- `momentum_7d`: `price(t) / price(t-168) - 1`
- `reversal_1h`: `-momentum_1h`
- `realized_vol_24h`: `rolling_std(momentum_1h, 24)`
- `volume_momentum`: `volume(t) / volume(t-24) - 1`
- `volume_surprise`: `(volume(t) - rolling_mean(volume,24)) / (rolling_std(volume,24) + eps)`
- `liquidity_mcap`: `liquidity / market_cap`
- `turnover`: `volume / market_cap`
- `volume_liquidity`: `volume / liquidity`
- `amihud_illiquidity`: `abs(momentum_1h) / (volume + eps)`
- `liquidity_growth`: `liquidity(t) / liquidity(t-24) - 1`
- `liquidity_shock`: `(liquidity(t) - rolling_mean(liquidity,24)) / (abs(rolling_mean(liquidity,24)) + eps)`
- `buy_sell_imbalance`: `(buy_volume - sell_volume) / (buy_volume + sell_volume + eps)`
- `smart_money_flow_intensity`: `smart_money_flow / liquidity`
- `smart_money_crowding`: `smartMoneyHoldingPercent`
- `signal_count`: `NaN: no confirmed forward signal endpoint`
- `signal_breadth`: `NaN: no confirmed forward signal endpoint`
- `holder_growth`: `holders(t) / holders(t-24) - 1`
- `holder_acceleration`: `(holders(t)/holders(t-1h)-1) - (holders(t)/holders(t-24h)-1)`
- `holder_concentration`: `top10HoldingPercent`
- `holder_liquidity_interaction`: `top10HoldingPercent / (cross_sectional_rank(liquidity) + eps)`
- `rank_change`: `-pct_change(rank,1)`
- `rank_momentum`: `-pct_change(rank,24)`
- `attention_shock`: `NaN: no confirmed attention/event endpoint`
- `token_age_days`: `NaN: creation-time mapping not used in executed panel`
- `audit_score`: `audit_score source field when available, else NaN`
- `chain_volume_breadth`: `count of non-null volume rows within current (chain, feature_time) cross-section`
- `market_vol_regime`: `cross-sectional mean of rolling_vol_24h at current (chain, feature_time)`

`factor(t)` is joined to labels on the same `feature_time`. Lagged horizons use exact clock-time matches; trailing statistics use clock-time windows. `forward_return_h` uses exactly `t+h` when present and otherwise is NaN, with explicit `exit_time_h`. No winsorization was applied in the executed run. Cross-sectional percentile-rank variants are generated. Neutralized variants are per-timestamp OLS residuals on `log_market_cap`, `log_liquidity`, and `volatility`; they are NaN/NOT_AVAILABLE when the complete control set is unavailable.

Unsupported or unavailable dimensions (wallet holdings, signal outcome, events/meme lifecycle, token age mapping) remain NaN/unsupported; they are not filled from future information.
