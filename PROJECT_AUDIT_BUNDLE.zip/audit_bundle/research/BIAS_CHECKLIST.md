# Bias and leakage checklist

| Check | Status | Evidence / limitation |
|---|---|---|
| look-ahead bias | PASS/PARTIAL | Exact timestamp lags, current-time regime aggregates, OLS residual controls, purged OOS, and adversarial future-append tests are implemented; raw API field audit remains partial. |
| survivorship bias | PARTIAL | Current hot-token discovery is survivor-biased; historical all-token/delisted universe is not reconstructed. |
| universe selection bias | FAIL | Hot-token rank selection is not a neutral investable universe. |
| data snooping | PARTIAL | 30 factors are screened; hypotheses are explicitly post-hoc/exploratory. |
| multiple testing | PASS | Standard BH-FDR is applied to HAC factor-level p-values; no q=0.05/0.10 discovery. |
| timestamp leakage | PASS | Exact clock-time matching, exit timestamps, and future-data invariance tests are implemented. |
| future liquidity filtering | PARTIAL | Historical liquidity is missing for candle rows; controls become NaN when unavailable. |
| future market-cap filtering | PARTIAL | Current market cap fields are not backfilled into history; neutralization requires available controls. |
| future listing knowledge | PARTIAL | Dynamic universe is only observed at current discovery time; no full listing history. |
| delisted token exclusion | FAIL | No delisted-token reconstruction. |
| DEX token survivorship | FAIL | Ranked discovery favors active tokens. |
| stale quote bias | NOT APPLICABLE | Factor panel uses candles, not executable quotes. |
| duplicated transaction bias | PARTIAL | Raw payload hashes and deduplication are implemented; trades are not part of the factor panel. |
| wallet-label leakage | NOT APPLICABLE | Wallet study not run. |
| cross-chain duplicated asset | PASS | Backtest and storage identity use `(chain, token_address)`; symbol-level mapping is not performed. |
| execution assumption bias | PARTIAL | Backtest uses non-overlapping accounting and proxy costs but has no executable depth/latency/gas. |

Relevant code: `src/onchain_alpha/features/core.py`, `src/onchain_alpha/labels/forward_returns.py`, `src/onchain_alpha/stats/robustness.py`, `src/onchain_alpha/screening/ic.py`, `src/onchain_alpha/backtest/engine.py`.
